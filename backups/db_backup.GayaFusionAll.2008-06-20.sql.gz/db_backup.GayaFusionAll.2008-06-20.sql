# backupDB() v1.1.31 (http://www.silisoftware.com)
# mySQL backup (June 20, 2008 2:42 am)   Type = Complete

CREATE TABLE `GayaFusionAll`.`sampleceramic` (
  `sID` int(10) NULL auto_increment,
  `SampleCode` varchar(12) NULL,
  `Description` varchar(50) NULL,
  `ClientCode` varchar(20) NULL,
  `ClientDescription` varchar(50) NULL,
  `SampleDate` date NULL default '0000-00-00',
  `TechDraw` varchar(50) NULL,
  `Photo1` varchar(50) NULL,
  `Photo2` varchar(50) NULL,
  `Photo3` varchar(50) NULL,
  `Photo4` varchar(50) NULL,
  `Reference` varchar(20) NULL,
  `ReferenceNote` text NULL,
  `Clay` varchar(12) NULL,
  `ClayKG` decimal(10,0) NULL,
  `ClayNote` text NULL,
  `BuildTech` varchar(50) NULL,
  `BuildTechNote` text NULL,
  `Rim` varchar(30) NULL,
  `Feet` varchar(30) NULL,
  `Casting1` varchar(12) NULL,
  `Casting2` varchar(12) NULL,
  `Casting3` varchar(12) NULL,
  `Casting4` varchar(12) NULL,
  `CastingNote` text NULL,
  `Estruder1` varchar(12) NULL,
  `Estruder2` varchar(12) NULL,
  `Estruder3` varchar(12) NULL,
  `Estruder4` varchar(12) NULL,
  `EstruderNote` text NULL,
  `Texture1` varchar(12) NULL,
  `Texture2` varchar(12) NULL,
  `Texture3` varchar(12) NULL,
  `Texture4` varchar(12) NULL,
  `TextureNote` text NULL,
  `Tools1` varchar(12) NULL,
  `Tools2` varchar(12) NULL,
  `Tools3` varchar(12) NULL,
  `Tools4` varchar(12) NULL,
  `ToolsNote` text NULL,
  `Engobe1` varchar(12) NULL,
  `Engobe2` varchar(12) NULL,
  `Engobe3` varchar(12) NULL,
  `Engobe4` varchar(12) NULL,
  `EngobeNote` text NULL,
  `BisqueTemp` varchar(10) NULL,
  `StainOxide1` varchar(10) NULL,
  `StainOxide2` varchar(10) NULL,
  `StainOxide3` varchar(10) NULL,
  `StainOxide4` varchar(10) NULL,
  `StainOxideNote` text NULL,
  `Glaze1` varchar(12) NULL,
  `Glaze2` varchar(12) NULL,
  `Glaze3` varchar(12) NULL,
  `Glaze4` varchar(12) NULL,
  `GlazeDensity1` varchar(10) NULL,
  `GlazeDensity2` varchar(10) NULL,
  `GlazeDensity3` varchar(10) NULL,
  `GlazeDensity4` varchar(10) NULL,
  `GlazeNote` text NULL,
  `GlazeTemp` varchar(10) NULL,
  `Firing` varchar(10) NULL,
  `FiringNote` text NULL,
  `Width` decimal(10,2) NULL,
  `Height` decimal(10,2) NULL,
  `Length` decimal(10,2) NULL,
  `Diameter` decimal(10,2) NULL,
  `SampCeramicVolume` decimal(10,2) NULL default '0.00',
  `FinalSizeNote` text NULL,
  `DesignMat1` varchar(12) NULL,
  `DesignMat2` varchar(12) NULL,
  `DesignMat3` varchar(12) NULL,
  `DesignMat4` varchar(12) NULL,
  `DesignMatQty1` int(10) NULL,
  `DesignMatQty2` int(10) NULL,
  `DesignMatQty3` int(10) NULL,
  `DesignMatQty4` int(10) NULL,
  `DesignMatNote` text NULL,
  `History` text NULL,
  `ClayType` varchar(50) NULL,
  `ClayCost` double NULL,
  `ClayPreparationMinute` int(11) NULL,
  `ClayPreparationCost` double NULL,
  `WheelMinute` int(11) NULL,
  `WheelCost` double NULL,
  `SlabMinute` int(11) NULL,
  `SlabCost` double NULL,
  `CastingMinute` int(11) NULL,
  `CastingCost` int(11) NULL,
  `FinishingMinute` int(11) NULL,
  `FinishingCost` double NULL,
  `GlazingMinute` int(11) NULL,
  `GlazingCost` double NULL,
  `StandardBisqueLoading` int(11) NULL,
  `StandardBisqueCost` double NULL,
  `StandardGlazeLoading` int(11) NULL,
  `StandardGlazeCost` double NULL,
  `RakuBisqueLoading` int(11) NULL,
  `RakuBisqueCost` double NULL,
  `RakuGlazeLoading` int(11) NULL,
  `RakuGlazeCost` double NULL,
  `MovementMinute` int(11) NULL,
  `MovementCost` double NULL,
  `PackagingWorkMinute` int(11) NULL,
  `PackagingWorkCost` double NULL,
  `ClayPreparationPPH` int(11) NULL,
  `WheelPPH` int(11) NULL,
  `SlabPPH` int(11) NULL,
  `CastingPPH` int(11) NULL,
  `FinishingPPH` int(11) NULL,
  `GlazingPPH` int(11) NULL,
  `MovementPPH` int(11) NULL,
  `PackagingWorkPPH` int(11) NULL,
  `TotalAllCost` double NULL,
  `RiskPrice` double NULL,
  `HypoSellingPrice` double NULL,
  `RealSellingPrice` double NULL,
  PRIMARY KEY (`sID`),
  UNIQUE KEY `SampleCode` (`SampleCode`)
) TYPE=MyISAM AUTO_INCREMENT=16;

CREATE TABLE `GayaFusionAll`.`sampleother` (
  `ID` int(10) NULL auto_increment,
  `SampleCode` varchar(12) NULL,
  `Description` varchar(50) NULL,
  `SampleDate` date NULL default '0000-00-00',
  `TechDraw` varchar(50) NULL,
  `Photo1` varchar(50) NULL,
  `Photo2` varchar(50) NULL,
  `Photo3` varchar(50) NULL,
  `Photo4` varchar(50) NULL,
  `DesMat1` varchar(50) NULL,
  `DesMat2` varchar(50) NULL,
  `DesMat3` varchar(50) NULL,
  `DesMat4` varchar(50) NULL,
  `DesMat5` varchar(50) NULL,
  `QtyDesMat1` int(11) NULL,
  `QtyDesMat2` int(11) NULL,
  `QtyDesMat3` int(11) NULL,
  `QtyDesMat4` int(11) NULL,
  `QtyDesMat5` int(11) NULL,
  `TotalDesMat1` varchar(50) NULL,
  `TotalDesMat2` varchar(50) NULL,
  `TotalDesMat3` varchar(50) NULL,
  `TotalDesMat4` varchar(50) NULL,
  `TotalDesMat5` varchar(50) NULL,
  `Supplier1` varchar(50) NULL,
  `Supplier2` varchar(50) NULL,
  `Supplier3` varchar(50) NULL,
  `Supplier4` varchar(50) NULL,
  `Supplier5` varchar(50) NULL,
  `Material1` varchar(50) NULL,
  `Material2` varchar(50) NULL,
  `Material3` varchar(50) NULL,
  `Material4` varchar(50) NULL,
  `Material5` varchar(50) NULL,
  `Color1` varchar(50) NULL,
  `Color2` varchar(50) NULL,
  `Color3` varchar(50) NULL,
  `Color4` varchar(50) NULL,
  `Color5` varchar(50) NULL,
  `CostPrice1` double NULL,
  `CostPrice2` double NULL,
  `CostPrice3` double NULL,
  `CostPrice4` double NULL,
  `CostPrice5` double NULL,
  `TotalDesMat` double NULL,
  `TotalCostPrice` double NULL,
  `TotalCost` double NULL,
  `Width` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  `Diameter` decimal(10,0) NULL,
  `Volume` decimal(10,2) NULL,
  `Notes` text NULL,
  `PriceRisk` double NULL,
  `RealPrice` double NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SampleCode` (`SampleCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`samplepackaging` (
  `ID` int(10) NULL auto_increment,
  `SampleCode` varchar(12) NULL,
  `Description` varchar(50) NULL,
  `SampleDate` date NULL default '0000-00-00',
  `TechDraw` varchar(50) NULL,
  `Photo1` varchar(50) NULL,
  `Photo2` varchar(50) NULL,
  `Photo3` varchar(50) NULL,
  `Photo4` varchar(50) NULL,
  `DesMat1` varchar(50) NULL,
  `DesMat2` varchar(50) NULL,
  `DesMat3` varchar(50) NULL,
  `DesMat4` varchar(50) NULL,
  `DesMat5` varchar(50) NULL,
  `QtyDesMat1` int(11) NULL,
  `QtyDesMat2` int(11) NULL,
  `QtyDesMat3` int(11) NULL,
  `QtyDesMat4` int(11) NULL,
  `QtyDesMat5` int(11) NULL,
  `TotalDesMat1` double NULL,
  `TotalDesMat2` double NULL,
  `TotalDesMat3` double NULL,
  `TotalDesMat4` double NULL,
  `TotalDesMat5` double NULL,
  `Supplier1` varchar(50) NULL,
  `Supplier2` varchar(50) NULL,
  `Supplier3` varchar(50) NULL,
  `Supplier4` varchar(50) NULL,
  `Supplier5` varchar(50) NULL,
  `Material1` varchar(50) NULL,
  `Material2` varchar(50) NULL,
  `Material3` varchar(50) NULL,
  `Material4` varchar(50) NULL,
  `Material5` varchar(50) NULL,
  `Color1` varchar(50) NULL,
  `Color2` varchar(50) NULL,
  `Color3` varchar(50) NULL,
  `Color4` varchar(50) NULL,
  `Color5` varchar(50) NULL,
  `CostPrice1` double NULL,
  `CostPrice2` double NULL,
  `CostPrice3` double NULL,
  `CostPrice4` double NULL,
  `CostPrice5` double NULL,
  `TotalDesMat` double NULL,
  `TotalCostPrice` double NULL,
  `TotalCost` double NULL,
  `InnerQty` int(11) NULL,
  `Width` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  `Diameter` decimal(10,0) NULL,
  `Volume` decimal(10,2) NULL,
  `Weight` decimal(10,2) NULL,
  `Notes` text NULL,
  `PriceRisk` double NULL,
  `RealPrice` double NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SampleCode` (`SampleCode`)
) TYPE=MyISAM AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tbladmin` (
  `ID` int(2) NULL auto_increment,
  `UserName` varchar(15) NULL,
  `Passwd` varchar(10) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tbladminist_addressbook` (
  `ID` int(20) NULL auto_increment,
  `ClientID` int(20) NULL,
  `Address` varchar(255) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_administ_doc` (
  `ID` int(10) NULL auto_increment,
  `ClientID` int(11) NULL,
  `QuotationID` int(11) NULL,
  `ProformaID` int(11) NULL,
  `ProductionOrderListID` int(11) NULL,
  `InvoiceID` int(11) NULL,
  `PackingListID` int(11) NULL,
  PRIMARY KEY (`ID`),
  KEY `ClientID` (`ClientID`,`QuotationID`,`ProformaID`,`ProductionOrderListID`,`InvoiceID`,`PackingListID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_box_d` (
  `ID` int(20) NULL auto_increment,
  `ID_Box_H` int(11) NULL,
  `Qty` int(11) NULL,
  `Unit` varchar(15) NULL,
  `ClientCode` varchar(50) NULL,
  `ClientDescription` varchar(100) NULL,
  `Name` varchar(50) NULL,
  `Category` varchar(50) NULL,
  `InfoSize` varchar(50) NULL,
  `Texture` varchar(50) NULL,
  `Color` varchar(50) NULL,
  `Material` varchar(50) NULL,
  `Diameter` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Width` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  `Remarks` text NULL,
  PRIMARY KEY (`ID`),
  KEY `ID_Box_H` (`ID_Box_H`,`ClientCode`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_box_h` (
  `ID` int(10) NULL auto_increment,
  `NoBox` int(11) NULL,
  `Length` decimal(10,0) NULL,
  `Width` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Weight` decimal(10,0) NULL,
  PRIMARY KEY (`ID`),
  KEY `NoBox` (`NoBox`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_client` (
  `ID` int(20) NULL auto_increment,
  `ClientName` varchar(50) NULL,
  `ClientAttn` varchar(100) NULL,
  `ClientAddress` varchar(255) NULL,
  `ClientEmail` varchar(30) NULL,
  `ClientPhone` varchar(20) NULL,
  `ClientFaz` varchar(20) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_conversion` (
  `ID` int(11) NULL auto_increment,
  `Currency` int(11) NULL,
  `CurrencyValue` decimal(10,0) NULL,
  `CurrencyDefaultValue` decimal(10,0) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_currency` (
  `ID` int(11) NULL auto_increment,
  `Currency` varchar(3) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_currencydefault` (
  `CurrencyDefault` int(11) NULL
) TYPE=InnoDB;

CREATE TABLE `GayaFusionAll`.`tbladminist_deliveryterm` (
  `ID` int(11) NULL auto_increment,
  `DeliveryTerm` varchar(100) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_deliverytime` (
  `ID` int(20) NULL auto_increment,
  `DeliveryTime` varchar(100) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_invoice_d` (
  `ID` int(20) NULL auto_increment,
  `ID_Invoice_H` int(11) NULL,
  `Qty` int(11) NULL,
  `Unit` varchar(15) NULL,
  `ClientCode` varchar(50) NULL,
  `ClientDescription` varchar(100) NULL,
  `Photo` varchar(50) NULL,
  `Type` int(11) NULL,
  `Name` varchar(50) NULL,
  `Category` varchar(50) NULL,
  `InfoSize` varchar(50) NULL,
  `Texture` varchar(50) NULL,
  `Color` varchar(50) NULL,
  `Material` varchar(50) NULL,
  `GroupDescription` varchar(150) NULL,
  `Diameter` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Width` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Total` decimal(10,0) NULL,
  PRIMARY KEY (`ID`),
  KEY `ID_Invoice_H` (`ID_Invoice_H`,`ClientCode`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_invoice_h` (
  `ID` int(20) NULL auto_increment,
  `InvoiceNo` varchar(11) NULL,
  `InvoicePar` varchar(5) NULL,
  `InvoiceDate` date NULL default '0000-00-00',
  `ClientOrderRef` varchar(50) NULL,
  `GayaOrderRef` varchar(50) NULL,
  `ProformaNo` varchar(20) NULL,
  `DeliveryTerm` varchar(50) NULL,
  `PaymentTerm` varchar(50) NULL,
  `DueDate` date NULL default '0000-00-00',
  `InvoiceClientName` varchar(100) NULL,
  `InvoiceAddress` varchar(255) NULL,
  `InvoicePhone` varchar(20) NULL,
  `InvoiceFax` varchar(20) NULL,
  `DeliveryClientName` varchar(100) NULL,
  `DeliveryAddress` varchar(255) NULL,
  `DeliveryPhone` varchar(20) NULL,
  `DeliveryFax` varchar(20) NULL,
  `SubTotal` decimal(10,0) NULL,
  `Discount` decimal(10,0) NULL,
  `Packaging` decimal(10,0) NULL,
  `ShippingCost` decimal(10,0) NULL,
  `GrandTotal` decimal(10,0) NULL,
  `PaymentBankTransferred` decimal(10,0) NULL,
  `Balance` decimal(10,0) NULL,
  PRIMARY KEY (`ID`),
  KEY `InvoiceNo` (`InvoiceNo`),
  KEY `InvoicePar` (`InvoicePar`),
  KEY `ClientOrderRef` (`ClientOrderRef`),
  KEY `InvoiceDate` (`InvoiceDate`),
  KEY `GayaOrderRef` (`GayaOrderRef`),
  KEY `ProformaNo` (`ProformaNo`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_packinglist_d` (
  `ID` int(11) NULL auto_increment,
  `ID_PackingList_H` int(11) NULL,
  `ID_Box_H` int(11) NULL,
  PRIMARY KEY (`ID`),
  KEY `ID_PackingList_H` (`ID_PackingList_H`,`ID_Box_H`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_packinglist_h` (
  `ID` int(11) NULL auto_increment,
  `PackListNo` varchar(15) NULL,
  `PackListDate` date NULL default '0000-00-00',
  `InvoiceClientName` varchar(50) NULL,
  `InvoiceAddress` varchar(255) NULL,
  `InvoicePhone` varchar(20) NULL,
  `InvoiceFax` varchar(20) NULL,
  `DeliveryClientName` varchar(20) NULL,
  `DeliveryAddress` varchar(255) NULL,
  `DeliveryPhone` varchar(20) NULL,
  `DeliveryFax` varchar(20) NULL,
  `OrderRef` varchar(20) NULL,
  PRIMARY KEY (`ID`),
  KEY `PackListNo` (`PackListNo`,`OrderRef`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_paymentterm` (
  `ID` int(8) NULL auto_increment,
  `PaymentTerm` varchar(100) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_percentage` (
  `ID` int(11) NULL auto_increment,
  `Percentage` decimal(10,0) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_prodorderlist_d` (
  `ID` int(11) NULL auto_increment,
  `Photo` varchar(50) NULL,
  `Name` varchar(50) NULL,
  `Category` varchar(50) NULL,
  `InfoSize` varchar(50) NULL,
  `Texture` varchar(50) NULL,
  `Color` varchar(50) NULL,
  `Material` varchar(50) NULL,
  `Qty` int(11) NULL,
  `Raw` varchar(50) NULL,
  `Bisc` varchar(50) NULL,
  `Glaze` varchar(50) NULL,
  `Os` varchar(50) NULL,
  `SetIn` int(11) NULL,
  `PcsIn` int(11) NULL,
  `Out` int(11) NULL,
  `TotalSet` int(11) NULL,
  `TotalPcs` int(11) NULL,
  `ID_ProdOrderList_h` int(11) NULL,
  PRIMARY KEY (`ID`),
  KEY `ID_ProdOrderList_h` (`ID_ProdOrderList_h`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_prodorderlist_h` (
  `ID` int(11) NULL auto_increment,
  `ClientName` varchar(50) NULL,
  `ClientOrderRef` varchar(50) NULL,
  `GayaProforma` varchar(11) NULL,
  `ProdOrderListDate` date NULL,
  `DeliveryTime` varchar(50) NULL,
  PRIMARY KEY (`ID`),
  KEY `ClientName` (`ClientName`,`ClientOrderRef`,`GayaProforma`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_prodorderlist_proforma` (
  `ID` int(11) NULL auto_increment,
  `ProformaID` int(11) NULL,
  `ProdOrderListID` int(11) NULL,
  PRIMARY KEY (`ID`),
  KEY `ProformaID` (`ProformaID`,`ProdOrderListID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_proforma_d` (
  `ID` int(20) NULL auto_increment,
  `ID_Proforma_H` int(11) NULL,
  `Qty` int(11) NULL,
  `Unit` varchar(15) NULL,
  `ClientCode` varchar(50) NULL,
  `ClientDescription` varchar(100) NULL,
  `Photo` varchar(50) NULL,
  `Type` int(11) NULL,
  `Name` varchar(50) NULL,
  `Category` varchar(50) NULL,
  `InfoSize` varchar(50) NULL,
  `Texture` varchar(50) NULL,
  `Color` varchar(50) NULL,
  `Material` varchar(50) NULL,
  `GroupDescription` varchar(150) NULL,
  `Diameter` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Width` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Total` decimal(10,0) NULL,
  PRIMARY KEY (`ID`),
  KEY `ID_Proforma_H` (`ID_Proforma_H`,`ClientCode`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_proforma_h` (
  `ID` int(20) NULL auto_increment,
  `ProformaNo` varchar(11) NULL,
  `Validity` varchar(15) NULL,
  `ProformaDate` date NULL,
  `ClientOrderRef` varchar(50) NULL,
  `ClientName` varchar(100) NULL,
  `Attn` varchar(100) NULL,
  `Email` varchar(30) NULL,
  `Address` varchar(255) NULL,
  `Phone` varchar(15) NULL,
  `Fax` varchar(15) NULL,
  `PackagingCost` decimal(10,0) NULL,
  `DeliveryTerm` varchar(50) NULL,
  `DeliveryTime` varchar(100) NULL,
  `PaymentTerm` varchar(100) NULL,
  `SpecialInstruction` text NULL,
  `SubTotal` decimal(10,0) NULL,
  `Discount` decimal(10,0) NULL,
  `Packaging` decimal(10,0) NULL,
  `GrandTotal` decimal(10,0) NULL,
  `Deposit` decimal(10,0) NULL,
  `Balance` decimal(10,0) NULL,
  PRIMARY KEY (`ID`),
  KEY `ProformaNo` (`ProformaNo`,`ClientOrderRef`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_proformarev_d` (
  `ID` int(20) NULL auto_increment,
  `ID_ProformaRev_H` int(11) NULL,
  `Qty` int(11) NULL,
  `Unit` varchar(15) NULL,
  `ClientCode` varchar(50) NULL,
  `ClientDescription` varchar(100) NULL,
  `Photo` varchar(50) NULL,
  `Type` int(11) NULL,
  `Name` varchar(50) NULL,
  `Category` varchar(50) NULL,
  `InfoSize` varchar(50) NULL,
  `Texture` varchar(50) NULL,
  `Color` varchar(50) NULL,
  `Material` varchar(50) NULL,
  `GroupDescription` varchar(150) NULL,
  `Diameter` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Width` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Total` decimal(10,0) NULL,
  PRIMARY KEY (`ID`),
  KEY `ID_ProformaRev_H` (`ID_ProformaRev_H`,`ClientCode`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_proformarev_h` (
  `ID` int(20) NULL auto_increment,
  `ProformaNo` varchar(11) NULL,
  `RevNo` varchar(5) NULL,
  `Validity` varchar(15) NULL,
  `ProformaDate` date NULL,
  `ClientOrderRef` varchar(50) NULL,
  `ClientName` varchar(100) NULL,
  `Attn` varchar(100) NULL,
  `Email` varchar(30) NULL,
  `Address` varchar(255) NULL,
  `Phone` varchar(15) NULL,
  `Fax` varchar(15) NULL,
  `PackagingCost` decimal(10,0) NULL,
  `DeliveryTerm` varchar(50) NULL,
  `DeliveryTime` varchar(100) NULL,
  `PaymentTerm` varchar(100) NULL,
  `SpecialInstruction` text NULL,
  `SubTotal` decimal(10,0) NULL,
  `Discount` decimal(10,0) NULL,
  `Packaging` decimal(10,0) NULL,
  `GrandTotal` decimal(10,0) NULL,
  `Deposit` decimal(10,0) NULL,
  `Balance` decimal(10,0) NULL,
  PRIMARY KEY (`ID`),
  KEY `ProformaNo` (`ProformaNo`,`ClientOrderRef`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotation_d` (
  `ID` int(20) NULL auto_increment,
  `ID_Quotation_H` int(11) NULL,
  `RndCode` varchar(12) NULL,
  `Photo` varchar(50) NULL,
  `Description` varchar(100) NULL,
  `Diameter` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Width` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Remark` text NULL,
  PRIMARY KEY (`ID`),
  KEY `ID_Quotation_H` (`ID_Quotation_H`,`RndCode`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotation_h` (
  `ID` int(20) NULL auto_increment,
  `QuotationNo` varchar(11) NULL,
  `Validity` varchar(15) NULL,
  `QuotationDate` date NULL,
  `ClientOrderRef` varchar(50) NULL,
  `ClientName` varchar(100) NULL,
  `Attn` varchar(100) NULL,
  `Email` varchar(30) NULL,
  `Address` varchar(255) NULL,
  `Phone` varchar(15) NULL,
  `Fax` varchar(15) NULL,
  `PackagingCost` decimal(10,0) NULL,
  `DeliveryTerm` varchar(50) NULL,
  `DeliveryTime` varchar(100) NULL,
  `PaymentTerm` varchar(100) NULL,
  `SpecialInstruction` text NULL,
  PRIMARY KEY (`ID`),
  KEY `QuotationNo` (`QuotationNo`,`ClientOrderRef`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotation_proforma` (
  `ID` int(11) NULL auto_increment,
  `QuotationID` int(11) NULL,
  `ProformaID` int(11) NULL,
  PRIMARY KEY (`ID`),
  KEY `ProformaID` (`ProformaID`,`QuotationID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotationrev_d` (
  `ID` int(20) NULL auto_increment,
  `ID_QuotationRev_H` int(11) NULL,
  `RndCode` varchar(12) NULL,
  `Photo` varchar(50) NULL,
  `Description` varchar(100) NULL,
  `Diameter` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Width` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Remark` text NULL,
  PRIMARY KEY (`ID`),
  KEY `ID_QuotationRev_H` (`ID_QuotationRev_H`,`RndCode`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotationrev_h` (
  `ID` int(20) NULL auto_increment,
  `QuotationID` int(11) NULL,
  `RevNo` varchar(5) NULL,
  `Validity` varchar(15) NULL,
  `QuotationDate` date NULL,
  `ClientOrderRef` varchar(50) NULL,
  `ClientName` varchar(100) NULL,
  `Attn` varchar(100) NULL,
  `Email` varchar(30) NULL,
  `Address` varchar(255) NULL,
  `Phone` varchar(15) NULL,
  `Fax` varchar(15) NULL,
  `PackagingCost` decimal(10,0) NULL,
  `DeliveryTerm` varchar(50) NULL,
  `DeliveryTime` varchar(100) NULL,
  `PaymentTerm` varchar(100) NULL,
  `SpecialInstruction` text NULL,
  PRIMARY KEY (`ID`),
  KEY `QuotationID` (`QuotationID`,`ClientOrderRef`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tblcasting` (
  `ID` int(11) NULL auto_increment,
  `CastingCode` varchar(10) NULL,
  `CastingDescription` varchar(100) NULL,
  `CastingDate` date NULL default '0000-00-00',
  `CastingTechDraw` varchar(50) NULL,
  `CastingPhoto1` varchar(50) NULL,
  `CastingPhoto2` varchar(50) NULL,
  `CastingPhoto3` varchar(50) NULL,
  `CastingPhoto4` varchar(50) NULL,
  `CastingNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `CastingCode` (`CastingCode`)
) TYPE=MyISAM AUTO_INCREMENT=4;

CREATE TABLE `GayaFusionAll`.`tblclay` (
  `ID` int(11) NULL auto_increment,
  `ClayCode` varchar(10) NULL,
  `ClayDescription` varchar(100) NULL,
  `ClayDate` date NULL default '0000-00-00',
  `ClayTechDraw` varchar(50) NULL,
  `ClayPhoto1` varchar(50) NULL,
  `ClayPhoto2` varchar(50) NULL,
  `ClayPhoto3` varchar(50) NULL,
  `ClayPhoto4` varchar(50) NULL,
  `ClayNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ClayCode` (`ClayCode`)
) TYPE=MyISAM AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tblcollect_category` (
  `CategoryID` int(5) NULL auto_increment,
  `CategoryCode` varchar(2) NULL,
  `CategoryName` varchar(50) NULL,
  PRIMARY KEY (`CategoryID`)
) TYPE=InnoDB AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tblcollect_color` (
  `ColorID` int(11) NULL auto_increment,
  `ColorCode` varchar(2) NULL,
  `ColorName` varchar(100) NULL,
  PRIMARY KEY (`ColorID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcollect_design` (
  `DesignID` int(5) NULL auto_increment,
  `DesignCode` varchar(2) NULL,
  `DesignName` varchar(100) NULL,
  PRIMARY KEY (`DesignID`)
) TYPE=InnoDB AUTO_INCREMENT=6;

CREATE TABLE `GayaFusionAll`.`tblcollect_group_det` (
  `ID` int(11) NULL auto_increment,
  `Group_H_ID` int(11) NULL,
  `Collect_Master_Code` varchar(15) NULL,
  `Qty` int(11) NULL,
  PRIMARY KEY (`ID`),
  KEY `Group_H_ID` (`Group_H_ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tblcollect_group_h` (
  `Group_H_ID` int(11) NULL,
  `GroupCode` varchar(12) NULL,
  `GroupDate` date NULL default '0000-00-00',
  `Design` varchar(2) NULL,
  `GroupDescription` varchar(255) NULL,
  `ClientCode` varchar(50) NULL,
  `ClientDesc` varchar(255) NULL,
  `GroupPhoto` varchar(50) NULL,
  `Diameter` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Weight` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  PRIMARY KEY (`Group_H_ID`),
  UNIQUE KEY `Code` (`GroupCode`)
) TYPE=InnoDB;

CREATE TABLE `GayaFusionAll`.`tblcollect_infosize` (
  `SizeID` int(5) NULL auto_increment,
  `SizeCode` varchar(2) NULL,
  `SizeName` varchar(50) NULL,
  PRIMARY KEY (`SizeID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcollect_master` (
  `ID` int(10) NULL auto_increment,
  `CollectCode` varchar(15) NULL,
  `DesignCode` varchar(2) NULL,
  `NameCode` varchar(2) NULL,
  `CategoryCode` varchar(2) NULL,
  `SizeCode` varchar(2) NULL,
  `TextureCode` varchar(2) NULL,
  `ColorCode` varchar(2) NULL,
  `MaterialCode` varchar(2) NULL,
  `ClientCode` varchar(20) NULL,
  `ClientDescription` varchar(50) NULL,
  `CollectDate` date NULL default '0000-00-00',
  `TechDraw` varchar(50) NULL,
  `Photo1` varchar(50) NULL,
  `Photo2` varchar(50) NULL,
  `Photo3` varchar(50) NULL,
  `Reference` varchar(20) NULL,
  `ReferenceNote` text NULL,
  `Clay` varchar(12) NULL,
  `ClayKG` decimal(10,0) NULL,
  `ClayNote` text NULL,
  `BuildTech` varchar(50) NULL,
  `BuildTechNote` text NULL,
  `Rim` varchar(30) NULL,
  `Feet` varchar(30) NULL,
  `Casting1` varchar(12) NULL,
  `Casting2` varchar(12) NULL,
  `Casting3` varchar(12) NULL,
  `Casting4` varchar(12) NULL,
  `CastingNote` text NULL,
  `Estruder1` varchar(12) NULL,
  `Estruder2` varchar(12) NULL,
  `Estruder3` varchar(12) NULL,
  `Estruder4` varchar(12) NULL,
  `EstruderNote` text NULL,
  `Texture1` varchar(12) NULL,
  `Texture2` varchar(12) NULL,
  `Texture3` varchar(12) NULL,
  `Texture4` varchar(12) NULL,
  `TextureNote` text NULL,
  `Tools1` varchar(12) NULL,
  `Tools2` varchar(12) NULL,
  `Tools3` varchar(12) NULL,
  `Tools4` varchar(12) NULL,
  `ToolsNote` text NULL,
  `Engobe1` varchar(12) NULL,
  `Engobe2` varchar(12) NULL,
  `Engobe3` varchar(12) NULL,
  `Engobe4` varchar(12) NULL,
  `EngobeNote` text NULL,
  `BisqueTemp` varchar(10) NULL,
  `StainOxide1` varchar(12) NULL,
  `StainOxide2` varchar(12) NULL,
  `StainOxide3` varchar(12) NULL,
  `StainOxide4` varchar(12) NULL,
  `StainOxideNote` text NULL,
  `Glaze1` varchar(12) NULL,
  `Glaze2` varchar(12) NULL,
  `Glaze3` varchar(12) NULL,
  `Glaze4` varchar(12) NULL,
  `GlazeDensity1` varchar(10) NULL,
  `GlazeDensity2` varchar(10) NULL,
  `GlazeDensity3` varchar(10) NULL,
  `GlazeDensity4` varchar(10) NULL,
  `GlazeNote` text NULL,
  `GlazeTemp` varchar(10) NULL,
  `Firing` varchar(10) NULL,
  `FiringNote` text NULL,
  `Width` decimal(10,2) NULL,
  `Height` decimal(10,2) NULL,
  `Length` decimal(10,2) NULL,
  `Diameter` decimal(10,2) NULL,
  `SampCeramicVolume` decimal(10,2) NULL default '0.00',
  `FinalSizeNote` text NULL,
  `DesignMat1` varchar(12) NULL,
  `DesignMat2` varchar(12) NULL,
  `DesignMat3` varchar(12) NULL,
  `DesignMat4` varchar(12) NULL,
  `DesignMatQty1` int(10) NULL,
  `DesignMatQty2` int(10) NULL,
  `DesignMatQty3` int(10) NULL,
  `DesignMatQty4` int(10) NULL,
  `DesignMatNote` text NULL,
  `History` text NULL,
  `ClayType` varchar(50) NULL,
  `ClayCost` double NULL,
  `ClayPreparationMinute` int(11) NULL,
  `ClayPreparationCost` double NULL,
  `WheelMinute` int(11) NULL,
  `WheelCost` double NULL,
  `SlabMinute` int(11) NULL,
  `SlabCost` double NULL,
  `CastingMinute` int(11) NULL,
  `CastingCost` int(11) NULL,
  `FinishingMinute` int(11) NULL,
  `FinishingCost` double NULL,
  `GlazingMinute` int(11) NULL,
  `GlazingCost` double NULL,
  `StandardBisqueLoading` int(11) NULL,
  `StandardBisqueCost` double NULL,
  `StandardGlazeLoading` int(11) NULL,
  `StandardGlazeCost` double NULL,
  `RakuBisqueLoading` int(11) NULL,
  `RakuBisqueCost` double NULL,
  `RakuGlazeLoading` int(11) NULL,
  `RakuGlazeCost` double NULL,
  `MovementMinute` int(11) NULL,
  `MovementCost` double NULL,
  `PackagingWorkMinute` int(11) NULL,
  `PackagingWorkCost` double NULL,
  `TotalAllCost` double NULL,
  `RiskPrice` double NULL,
  `HypoSellingPrice` double NULL,
  `RealSellingPrice` double NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `CollectCode` (`CollectCode`)
) TYPE=MyISAM AUTO_INCREMENT=24;

CREATE TABLE `GayaFusionAll`.`tblcollect_material` (
  `MaterialID` int(5) NULL auto_increment,
  `MaterialCode` varchar(2) NULL,
  `MaterialName` varchar(50) NULL,
  PRIMARY KEY (`MaterialID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcollect_name` (
  `NameID` int(5) NULL auto_increment,
  `NameCode` varchar(2) NULL,
  `NameDesc` varchar(50) NULL,
  PRIMARY KEY (`NameID`)
) TYPE=InnoDB AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tblcollect_size` (
  `SizeID` int(5) NULL auto_increment,
  `SizeCode` varchar(2) NULL,
  `SizeName` varchar(50) NULL,
  PRIMARY KEY (`SizeID`)
) TYPE=InnoDB AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tblcollect_texture` (
  `TextureID` int(5) NULL auto_increment,
  `TextureCode` varchar(2) NULL,
  `TextureName` varchar(50) NULL,
  PRIMARY KEY (`TextureID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_casting` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  `PiecesPerHour` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_clay` (
  `ID` int(11) NULL auto_increment,
  `ClayType` varchar(50) NULL,
  `PricePerKG` double NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ClayType` (`ClayType`)
) TYPE=InnoDB AUTO_INCREMENT=7;

CREATE TABLE `GayaFusionAll`.`tblcosting_claypreparation` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  `PiecesPerHour` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_costbudgetpreview` (
  `ID` int(11) NULL auto_increment,
  `BudgetYear` int(11) NULL,
  `CostBudgetAmmount` double NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_finishing` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  `PiecesPerHour` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_glazing` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  `PiecesPerHour` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_master` (
  `ID` int(1) NULL,
  `ClayPreparationCPM` int(11) NULL,
  `ClayPreparationPPH` int(11) NULL,
  `WheelCPM` int(11) NULL,
  `WheelPPH` int(11) NULL,
  `SlabCPM` int(11) NULL,
  `SlabPPH` int(11) NULL,
  `CastingCPM` int(11) NULL,
  `CastingPPH` int(11) NULL,
  `FinishingCPM` int(11) NULL,
  `FinishingPPH` int(11) NULL,
  `GlazingCPM` int(11) NULL,
  `GlazingPPH` int(11) NULL,
  `MovementCPM` int(11) NULL,
  `MovementPPH` int(11) NULL,
  `PackagingWorkCPM` int(11) NULL,
  `PackagingWorkPPH` int(11) NULL,
  `StandardBisqueCPM` int(11) NULL,
  `StandardBisquePPH` int(11) NULL,
  `StandardGlazeCPM` int(11) NULL,
  `StandardGlazePPH` int(11) NULL,
  `RakuBisqueCPM` int(11) NULL,
  `RakuBisquePPH` int(11) NULL,
  `RakuGlazeCPM` int(11) NULL,
  `RakuGlazePPH` int(11) NULL,
  `ProductiveHourDay` decimal(10,2) NULL default '0.00',
  `ProductiveHourMonth` int(11) NULL,
  `ProductiveHourYear` int(11) NULL,
  `TrowWorker` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcosting_movement` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  `PiecesPerHour` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_packagingwork` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  `PiecesPerHour` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_productivehours` (
  `ID` int(11) NULL auto_increment,
  `Day` decimal(10,2) NULL default '0.00',
  `Month` int(11) NULL,
  `Year` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_rakubisque` (
  `ID` int(11) NULL auto_increment,
  `PricePerFiring` double NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_rakuglaze` (
  `ID` int(11) NULL auto_increment,
  `PricePerFiring` double NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_slab` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  `PiecesPerHour` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_standardbisque` (
  `ID` int(11) NULL auto_increment,
  `PricePerFiring` double NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_standardglaze` (
  `ID` int(1) NULL auto_increment,
  `PricePerFiring` double NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_trowworker` (
  `ID` int(11) NULL auto_increment,
  `TrowWorker` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_wheel` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  `PiecesPerHour` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tbldepartment` (
  `ID` int(3) NULL auto_increment,
  `DepartmentName` varchar(100) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbldesmaterial` (
  `DmID` int(11) NULL auto_increment,
  `DmCode` varchar(10) NULL,
  `DmDescription` varchar(100) NULL,
  `DmTechDraw` varchar(50) NULL,
  `DmPhoto1` varchar(50) NULL,
  `DmPhoto2` varchar(50) NULL,
  `DmPhoto3` varchar(50) NULL,
  `DmPhoto4` varchar(50) NULL,
  `DmSupplier` varchar(10) NULL,
  `DmUnit` varchar(2) NULL,
  `DmUnitPrice` decimal(10,0) NULL,
  `DmNotes` text NULL,
  `DmDate` date NULL default '0000-00-00',
  PRIMARY KEY (`DmID`),
  UNIQUE KEY `DmCode` (`DmCode`)
) TYPE=InnoDB AUTO_INCREMENT=4;

CREATE TABLE `GayaFusionAll`.`tblengobe` (
  `ID` int(11) NULL auto_increment,
  `EngobeCode` varchar(10) NULL,
  `EngobeDescription` varchar(100) NULL,
  `EngobeDate` date NULL default '0000-00-00',
  `EngobeTechDraw` varchar(50) NULL,
  `EngobePhoto1` varchar(50) NULL,
  `EngobePhoto2` varchar(50) NULL,
  `EngobePhoto3` varchar(50) NULL,
  `EngobePhoto4` varchar(50) NULL,
  `EngobeNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `EngobeCode` (`EngobeCode`)
) TYPE=MyISAM AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tblestruder` (
  `ID` int(11) NULL auto_increment,
  `EstruderCode` varchar(10) NULL,
  `EstruderDescription` varchar(100) NULL,
  `EstruderDate` date NULL default '0000-00-00',
  `EstruderTechDraw` varchar(50) NULL,
  `EstruderPhoto1` varchar(50) NULL,
  `EstruderPhoto2` varchar(50) NULL,
  `EstruderPhoto3` varchar(50) NULL,
  `EstruderPhoto4` varchar(50) NULL,
  `EstruderNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `EstruderCode` (`EstruderCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblfiringplan` (
  `ID` int(11) NULL auto_increment,
  `FiringPlanCode` varchar(10) NULL,
  `FiringPlanDescription` varchar(100) NULL,
  `FiringPlanDate` date NULL default '0000-00-00',
  `FiringPlanTechDraw` varchar(50) NULL,
  `FiringPlanPhoto1` varchar(50) NULL,
  `FiringPlanPhoto2` varchar(50) NULL,
  `FiringPlanPhoto3` varchar(50) NULL,
  `FiringPlanPhoto4` varchar(50) NULL,
  `FiringPlanNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `FiringPlanCode` (`FiringPlanCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblglaze` (
  `ID` int(11) NULL auto_increment,
  `GlazeCode` varchar(10) NULL,
  `GlazeDescription` varchar(100) NULL,
  `GlazeDate` date NULL default '0000-00-00',
  `GlazeTechDraw` varchar(50) NULL,
  `GlazePhoto1` varchar(50) NULL,
  `GlazePhoto2` varchar(50) NULL,
  `GlazePhoto3` varchar(50) NULL,
  `GlazePhoto4` varchar(50) NULL,
  `GlazeNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `GlazeCode` (`GlazeCode`)
) TYPE=MyISAM AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tblreference` (
  `ID` int(11) NULL auto_increment,
  `RefCode` varchar(20) NULL,
  `SampCeramicCode` varchar(20) NULL,
  `CollectionCode` varchar(20) NULL,
  PRIMARY KEY (`ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tblstainoxid` (
  `ID` int(11) NULL auto_increment,
  `StainOxideCode` varchar(10) NULL,
  `StainOxideDescription` varchar(100) NULL,
  `StainOxideDate` date NULL default '0000-00-00',
  `StainOxideTechDraw` varchar(50) NULL,
  `StainOxidePhoto1` varchar(50) NULL,
  `StainOxidePhoto2` varchar(50) NULL,
  `StainOxidePhoto3` varchar(50) NULL,
  `StainOxidePhoto4` varchar(50) NULL,
  `StainOxideNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `StainOxidCode` (`StainOxideCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblstainoxide` (
  `ID` int(11) NULL auto_increment,
  `StainOxideCode` varchar(10) NULL,
  `StainOxideDescription` varchar(100) NULL,
  `StainOxideDate` date NULL default '0000-00-00',
  `StainOxideTechDraw` varchar(50) NULL,
  `StainOxidePhoto1` varchar(50) NULL,
  `StainOxidePhoto2` varchar(50) NULL,
  `StainOxidePhoto3` varchar(50) NULL,
  `StainOxidePhoto4` varchar(50) NULL,
  `StainOxideNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `stainoxideCode` (`StainOxideCode`)
) TYPE=MyISAM AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tblsupplier` (
  `ID` int(11) NULL auto_increment,
  `SupCode` varchar(15) NULL,
  `SupCompany` varchar(100) NULL,
  `SupContact` varchar(100) NULL,
  `SupAddress` varchar(200) NULL,
  `SupHP` varchar(15) NULL,
  `SupOffice` varchar(100) NULL,
  `SupFax` varchar(20) NULL,
  `SupEmail` varchar(50) NULL,
  `SupItems` varchar(100) NULL,
  `SupOtherInfo` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SupCode` (`SupCode`)
) TYPE=MyISAM AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tbltexture` (
  `ID` int(11) NULL auto_increment,
  `TextureCode` varchar(10) NULL,
  `TextureDescription` varchar(100) NULL,
  `TextureDate` date NULL default '0000-00-00',
  `TextureTechDraw` varchar(50) NULL,
  `TexturePhoto1` varchar(50) NULL,
  `TexturePhoto2` varchar(50) NULL,
  `TexturePhoto3` varchar(50) NULL,
  `TexturePhoto4` varchar(50) NULL,
  `TextureNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `TextureCode` (`TextureCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tbltools` (
  `ID` int(11) NULL auto_increment,
  `ToolsCode` varchar(10) NULL,
  `ToolsDescription` varchar(100) NULL,
  `ToolsDate` date NULL default '0000-00-00',
  `ToolsTechDraw` varchar(50) NULL,
  `ToolsPhoto1` varchar(50) NULL,
  `ToolsPhoto2` varchar(50) NULL,
  `ToolsPhoto3` varchar(50) NULL,
  `ToolsPhoto4` varchar(50) NULL,
  `ToolsNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ToolsCode` (`ToolsCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblunit` (
  `UnitID` varchar(2) NULL,
  `UnitValue` varchar(30) NULL,
  PRIMARY KEY (`UnitID`)
) TYPE=InnoDB;

CREATE TABLE `GayaFusionAll`.`tbluser` (
  `id` int(11) NULL auto_increment,
  `UserName` varchar(15) NULL,
  `LastName` varchar(50) NULL,
  `FirstName` varchar(30) NULL,
  `Password` varchar(50) NULL,
  `Type` varchar(15) NULL,
  PRIMARY KEY (`id`)
) TYPE=InnoDB AUTO_INCREMENT=15;


# dumping data for GayaFusionAll.sampleceramic
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `Description`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (1, 'code', 'asd', 'kuadalbosok', '', '0000-00-00', '', '20080316202742-BPM jadul.jpg', '', '', NULL, '', '', 'CL01', 0, '', '', '', '', '', 'CS08-003', 'CS02', 'CS01', 'CS08-003', '', 'ES01', 'ES01', '', '', '', 'tx001', 'tx001', '', '', '', 'TL01', 'TL01', '', '', '', 'EN08-002', 'en1', '', '', '', '', 'SX01', 'SX01', '', '', '', 'Gl001', 'GL002', '', '', '', '', '', '', '', '', '', '', 0.00, 0.00, 0.00, 0.00, 0.00, '', 'DM08-003', 'DM02', '', '', 3, 0, 0, 0, '', '', '5', 0, 7, 3600, 4, 3750, 1, 30000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 15, 60, 0, 0, 0, 0, 0, 37350, 41085, 123255, 5000);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `Description`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (2, 'tes', 'tester', '', '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `Description`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (3, 'ctess', 'gaga', '', '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `Description`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (4, 'cod', 'codenya', 'kode kadal', 'ini deskripsi si klien ya', '2008-03-17', '', '20080316202648-100_5176.jpg', '', '', '20080424043033-BPM jadul.jpg', '', '', 'CL01', 5, '', '', 'ldflajfdsf\r\nclay notes\r\nkok ga\r\nkliatan', '40', '0.5', 'CS02', 'CS08-003', '', '', '', 'ES01', 'ES01', '', '', '', 'tx001', '', '', '', '', 'TL01', 'TL01', '', '', '', 'EN08-002', '', '', '', '', '960�', 'SX01', 'SX08-002', '', '', '', 'GL002', '', '', '', '443', '3453', '3535', '3453', '', '500', '', '', 5.00, 5.00, 5.00, 0.00, 0.00, '', 'DM08-003', 'DM02', '', '', 5, 3, 0, 0, '', 'coba deh tes history-nya..\r\nini juga test pake enter', '1', 4000, 0, 0, 10, 1500, 8, 4000, 5, 9600, 30, 600, 6, 4500, 100, 5000, 5, 15000, 0, 0, 0, 0, 7, 2700, 3, 9000, 0, 6, 8, 12, 2, 10, 9, 20, 55900, 61490, 184470, 300000);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `Description`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (5, 'lima', 'lima tes', '', '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `Description`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (6, 'nam', 'enam', '', '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `Description`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (7, 'tuju', 'tuju', '', '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `Description`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (8, 'lapan', 'delapan test', '', '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `Description`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (9, 'so9', 'sembilan tes', 'code9', 'apa aja deh', '2008-03-13', '', '', '', '', NULL, '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '', '', '', 0, 0, 0, 0, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `Description`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (10, 'tes10', 'kesepuluh', '', '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'cuma tes', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `Description`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (11, 'ini11', 'kesebelas', '', '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `Description`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (12, 'code12', 'tes ke12', 'cek n ricek', 'huehehehe', '2008-03-25', NULL, '20080316202755-100_5174.JPG', NULL, NULL, NULL, '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '', '', '', 0, 0, 0, 0, '', '', '', 0, 35, 800, 12, 1250, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 5, 0, 0, 0, 0, 0, 0, 2050, 2255, 6765, 3000);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `Description`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (13, 'code13', 'tes ke 13 ni', 'client13code', '', '0000-00-00', '', '', '', '', NULL, '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '', '', '', 0, 0, 0, 0, '', '', NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `Description`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (14, 'code14', 'code ke 14', '', '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL);


# dumping data for GayaFusionAll.sampleother
INSERT INTO `sampleother` (`ID`, `SampleCode`, `Description`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `DesMat1`, `DesMat2`, `DesMat3`, `DesMat4`, `DesMat5`, `QtyDesMat1`, `QtyDesMat2`, `QtyDesMat3`, `QtyDesMat4`, `QtyDesMat5`, `TotalDesMat1`, `TotalDesMat2`, `TotalDesMat3`, `TotalDesMat4`, `TotalDesMat5`, `Supplier1`, `Supplier2`, `Supplier3`, `Supplier4`, `Supplier5`, `Material1`, `Material2`, `Material3`, `Material4`, `Material5`, `Color1`, `Color2`, `Color3`, `Color4`, `Color5`, `CostPrice1`, `CostPrice2`, `CostPrice3`, `CostPrice4`, `CostPrice5`, `TotalDesMat`, `TotalCostPrice`, `TotalCost`, `Width`, `Height`, `Length`, `Diameter`, `Volume`, `Notes`, `PriceRisk`, `RealPrice`) VALUES (1, 'SO001', 'SAMP other pertama', '0000-00-00', '20080318203957-graduation.JPG', '20080318203957-tazmania_baby.JPG', NULL, NULL, NULL, 'DM02', 'DM01', 'DM08-003', 'DM02', 'DM02', 1, 1, 2, 3, 5, '5000', '4500', '10000', '15000', '25000', 'sup02', 'sup02', '', '', '', 'mas', 'kuning', '', '', '', 'kuning', 'kuning', '', '', '', 5000, 4500, 0, 0, 0, 59500, 9500, 69000, 5, 4, 5, 0, 100.00, '', NULL, NULL);


# dumping data for GayaFusionAll.samplepackaging
INSERT INTO `samplepackaging` (`ID`, `SampleCode`, `Description`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `DesMat1`, `DesMat2`, `DesMat3`, `DesMat4`, `DesMat5`, `QtyDesMat1`, `QtyDesMat2`, `QtyDesMat3`, `QtyDesMat4`, `QtyDesMat5`, `TotalDesMat1`, `TotalDesMat2`, `TotalDesMat3`, `TotalDesMat4`, `TotalDesMat5`, `Supplier1`, `Supplier2`, `Supplier3`, `Supplier4`, `Supplier5`, `Material1`, `Material2`, `Material3`, `Material4`, `Material5`, `Color1`, `Color2`, `Color3`, `Color4`, `Color5`, `CostPrice1`, `CostPrice2`, `CostPrice3`, `CostPrice4`, `CostPrice5`, `TotalDesMat`, `TotalCostPrice`, `TotalCost`, `InnerQty`, `Width`, `Height`, `Length`, `Diameter`, `Volume`, `Weight`, `Notes`, `PriceRisk`, `RealPrice`) VALUES (1, 'SP-001', 'SampPack yg pertama', '0000-00-00', '20080318194616-with noz.jpg', '', NULL, NULL, '20080424042544-invent.JPG', 'DM02', 'DM01', 'DM08-003', 'DM02', 'DM01', 4, 1, 2, 7, 1, 20000, 4500, 10000, 35000, 4500, 'sup02', 'sup02', 'sup02', 'sup01', 'sup02', 'ijo ijo', '', 'tembaga', 'balbal', 'karat', 'ijo', '', 'putih', 'ijo', 'coklat', 5000, 0, 550, 450, 4000, 74000, 10000, 84000, 6, 5, 5, 5, 0, 125.00, 0.00, '', NULL, NULL);
INSERT INTO `samplepackaging` (`ID`, `SampleCode`, `Description`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `DesMat1`, `DesMat2`, `DesMat3`, `DesMat4`, `DesMat5`, `QtyDesMat1`, `QtyDesMat2`, `QtyDesMat3`, `QtyDesMat4`, `QtyDesMat5`, `TotalDesMat1`, `TotalDesMat2`, `TotalDesMat3`, `TotalDesMat4`, `TotalDesMat5`, `Supplier1`, `Supplier2`, `Supplier3`, `Supplier4`, `Supplier5`, `Material1`, `Material2`, `Material3`, `Material4`, `Material5`, `Color1`, `Color2`, `Color3`, `Color4`, `Color5`, `CostPrice1`, `CostPrice2`, `CostPrice3`, `CostPrice4`, `CostPrice5`, `TotalDesMat`, `TotalCostPrice`, `TotalCost`, `InnerQty`, `Width`, `Height`, `Length`, `Diameter`, `Volume`, `Weight`, `Notes`, `PriceRisk`, `RealPrice`) VALUES (2, 'sp-002', 'CONTOH YANG KE DIA', '0000-00-00', NULL, NULL, NULL, NULL, NULL, 'DM08-003', '', '', '', '', 5, 0, 0, 0, 0, 25000, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 25000, 0, 25000, 0, 0, 0, 0, 0, 0.00, 0.00, '', NULL, NULL);


# dumping data for GayaFusionAll.tbladmin
INSERT INTO `tbladmin` (`ID`, `UserName`, `Passwd`) VALUES (1, 'ADMIN', 'ADMIN');


























































# dumping data for GayaFusionAll.tblcasting
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (1, 'CS01', 'Casting 1 bok', '2008-03-11', '', '', '', '', '', 'Tes');
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (2, 'CS02', 'No 2 yaaa', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (3, 'CS08-003', 'CASTING taun 08 nomor 3', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblclay
INSERT INTO `tblclay` (`ID`, `ClayCode`, `ClayDescription`, `ClayDate`, `ClayTechDraw`, `ClayPhoto1`, `ClayPhoto2`, `ClayPhoto3`, `ClayPhoto4`, `ClayNotes`) VALUES (1, 'CL01', 'tess', '2008-03-05', '', '20080322155553-logo.jpg', '', '', '', 'tess\r\nkgkkgkg\r\nijijji\r\nokokkok\r\nljljl');
INSERT INTO `tblclay` (`ID`, `ClayCode`, `ClayDescription`, `ClayDate`, `ClayTechDraw`, `ClayPhoto1`, `ClayPhoto2`, `ClayPhoto3`, `ClayPhoto4`, `ClayNotes`) VALUES (2, 'CL02', 'no 2 yaa', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblcollect_category
INSERT INTO `tblcollect_category` (`CategoryID`, `CategoryCode`, `CategoryName`) VALUES (1, 'TS', 'Tea Cup With Silver');
INSERT INTO `tblcollect_category` (`CategoryID`, `CategoryCode`, `CategoryName`) VALUES (2, 'TG', 'Tea cup with gold');


# dumping data for GayaFusionAll.tblcollect_color
INSERT INTO `tblcollect_color` (`ColorID`, `ColorCode`, `ColorName`) VALUES (1, 'SM', 'Smooth Black');


# dumping data for GayaFusionAll.tblcollect_design
INSERT INTO `tblcollect_design` (`DesignID`, `DesignCode`, `DesignName`) VALUES (1, 'AC', 'Armani Cassa');
INSERT INTO `tblcollect_design` (`DesignID`, `DesignCode`, `DesignName`) VALUES (2, 'GG', 'Gudang Garam');
INSERT INTO `tblcollect_design` (`DesignID`, `DesignCode`, `DesignName`) VALUES (3, 'BT', 'Bayi Tabung');
INSERT INTO `tblcollect_design` (`DesignID`, `DesignCode`, `DesignName`) VALUES (4, 'FE', 'FEFEFEFEFE');
INSERT INTO `tblcollect_design` (`DesignID`, `DesignCode`, `DesignName`) VALUES (5, 'DN', 'Daniel');






# dumping data for GayaFusionAll.tblcollect_infosize
INSERT INTO `tblcollect_infosize` (`SizeID`, `SizeCode`, `SizeName`) VALUES (1, 'te', 'afadas');


# dumping data for GayaFusionAll.tblcollect_master
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (19, 'DNSETSSMSHSMC', 'DN', 'SE', 'TS', 'SM', 'SH', 'SM', 'C', NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (21, 'BTSETSSMSHSMC', 'BT', 'SE', 'TS', 'SM', 'SH', 'SM', 'C', NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (22, 'ACBETSSBSHSMC', 'AC', 'BE', 'TS', 'SB', 'SH', 'SM', 'C', NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Reference`, `ReferenceNote`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (23, 'BTBETSSMSHSMC', 'BT', 'BE', 'TS', 'SM', 'SH', 'SM', 'C', NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL);


# dumping data for GayaFusionAll.tblcollect_material
INSERT INTO `tblcollect_material` (`MaterialID`, `MaterialCode`, `MaterialName`) VALUES (1, 'C', 'Ceramic Porcelainer');


# dumping data for GayaFusionAll.tblcollect_name
INSERT INTO `tblcollect_name` (`NameID`, `NameCode`, `NameDesc`) VALUES (1, 'SE', 'Seia');
INSERT INTO `tblcollect_name` (`NameID`, `NameCode`, `NameDesc`) VALUES (2, 'BE', 'Beia');


# dumping data for GayaFusionAll.tblcollect_size
INSERT INTO `tblcollect_size` (`SizeID`, `SizeCode`, `SizeName`) VALUES (1, 'SM', 'Small kecil');
INSERT INTO `tblcollect_size` (`SizeID`, `SizeCode`, `SizeName`) VALUES (2, 'SB', 'Super Besar');


# dumping data for GayaFusionAll.tblcollect_texture
INSERT INTO `tblcollect_texture` (`TextureID`, `TextureCode`, `TextureName`) VALUES (1, 'SH', 'Smooth item');


# dumping data for GayaFusionAll.tblcosting_casting
INSERT INTO `tblcosting_casting` (`ID`, `CostPerMinute`, `PiecesPerHour`) VALUES (1, 800, 90);


# dumping data for GayaFusionAll.tblcosting_clay
INSERT INTO `tblcosting_clay` (`ID`, `ClayType`, `PricePerKG`) VALUES (1, 'blablabla', 800);
INSERT INTO `tblcosting_clay` (`ID`, `ClayType`, `PricePerKG`) VALUES (5, 'Porcelain', 450);
INSERT INTO `tblcosting_clay` (`ID`, `ClayType`, `PricePerKG`) VALUES (6, 'Beling', 1000);


# dumping data for GayaFusionAll.tblcosting_claypreparation
INSERT INTO `tblcosting_claypreparation` (`ID`, `CostPerMinute`, `PiecesPerHour`) VALUES (1, 400, 3);


# dumping data for GayaFusionAll.tblcosting_costbudgetpreview
INSERT INTO `tblcosting_costbudgetpreview` (`ID`, `BudgetYear`, `CostBudgetAmmount`) VALUES (1, 2008, 1500000000);


# dumping data for GayaFusionAll.tblcosting_finishing
INSERT INTO `tblcosting_finishing` (`ID`, `CostPerMinute`, `PiecesPerHour`) VALUES (1, 300, 70);


# dumping data for GayaFusionAll.tblcosting_glazing
INSERT INTO `tblcosting_glazing` (`ID`, `CostPerMinute`, `PiecesPerHour`) VALUES (1, 450, 8);


# dumping data for GayaFusionAll.tblcosting_master
INSERT INTO `tblcosting_master` (`ID`, `ClayPreparationCPM`, `ClayPreparationPPH`, `WheelCPM`, `WheelPPH`, `SlabCPM`, `SlabPPH`, `CastingCPM`, `CastingPPH`, `FinishingCPM`, `FinishingPPH`, `GlazingCPM`, `GlazingPPH`, `MovementCPM`, `MovementPPH`, `PackagingWorkCPM`, `PackagingWorkPPH`, `StandardBisqueCPM`, `StandardBisquePPH`, `StandardGlazeCPM`, `StandardGlazePPH`, `RakuBisqueCPM`, `RakuBisquePPH`, `RakuGlazeCPM`, `RakuGlazePPH`, `ProductiveHourDay`, `ProductiveHourMonth`, `ProductiveHourYear`, `TrowWorker`) VALUES (0, 0, 0, 0, 0, 0, 0, 0, 0, 500, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 0, 0, 0);


# dumping data for GayaFusionAll.tblcosting_movement
INSERT INTO `tblcosting_movement` (`ID`, `CostPerMinute`, `PiecesPerHour`) VALUES (1, 300, 5);


# dumping data for GayaFusionAll.tblcosting_packagingwork
INSERT INTO `tblcosting_packagingwork` (`ID`, `CostPerMinute`, `PiecesPerHour`) VALUES (1, 450, 5);


# dumping data for GayaFusionAll.tblcosting_productivehours
INSERT INTO `tblcosting_productivehours` (`ID`, `Day`, `Month`, `Year`) VALUES (1, 5.50, 25, 12);


# dumping data for GayaFusionAll.tblcosting_rakubisque
INSERT INTO `tblcosting_rakubisque` (`ID`, `PricePerFiring`) VALUES (1, 1250);


# dumping data for GayaFusionAll.tblcosting_rakuglaze
INSERT INTO `tblcosting_rakuglaze` (`ID`, `PricePerFiring`) VALUES (1, 1500);


# dumping data for GayaFusionAll.tblcosting_slab
INSERT INTO `tblcosting_slab` (`ID`, `CostPerMinute`, `PiecesPerHour`) VALUES (1, 500, 10);


# dumping data for GayaFusionAll.tblcosting_standardbisque
INSERT INTO `tblcosting_standardbisque` (`ID`, `PricePerFiring`) VALUES (1, 1000);


# dumping data for GayaFusionAll.tblcosting_standardglaze
INSERT INTO `tblcosting_standardglaze` (`ID`, `PricePerFiring`) VALUES (1, 3000);


# dumping data for GayaFusionAll.tblcosting_trowworker
INSERT INTO `tblcosting_trowworker` (`ID`, `TrowWorker`) VALUES (1, 3);


# dumping data for GayaFusionAll.tblcosting_wheel
INSERT INTO `tblcosting_wheel` (`ID`, `CostPerMinute`, `PiecesPerHour`) VALUES (1, 250, 6);




# dumping data for GayaFusionAll.tbldesmaterial
INSERT INTO `tbldesmaterial` (`DmID`, `DmCode`, `DmDescription`, `DmTechDraw`, `DmPhoto1`, `DmPhoto2`, `DmPhoto3`, `DmPhoto4`, `DmSupplier`, `DmUnit`, `DmUnitPrice`, `DmNotes`, `DmDate`) VALUES (1, 'DM01', 'desin no 1', '20080316061239-BITS logo.jpg', '20080316061239-SIGNATURE-515.jpg', NULL, NULL, NULL, 'sup02', 'B', 4500, 'aku\r\ncoba\r\ntes\r\naja\r\nya', '2008-03-16');
INSERT INTO `tbldesmaterial` (`DmID`, `DmCode`, `DmDescription`, `DmTechDraw`, `DmPhoto1`, `DmPhoto2`, `DmPhoto3`, `DmPhoto4`, `DmSupplier`, `DmUnit`, `DmUnitPrice`, `DmNotes`, `DmDate`) VALUES (2, 'DM02', 'Design Material dari perak kualitas no 1 di dunia', NULL, NULL, NULL, NULL, NULL, 'sup01', 'A', 5000, '', '0000-00-00');
INSERT INTO `tbldesmaterial` (`DmID`, `DmCode`, `DmDescription`, `DmTechDraw`, `DmPhoto1`, `DmPhoto2`, `DmPhoto3`, `DmPhoto4`, `DmSupplier`, `DmUnit`, `DmUnitPrice`, `DmNotes`, `DmDate`) VALUES (3, 'DM08-003', 'Test DM dengan 8 digit code', NULL, NULL, NULL, NULL, NULL, 'sup02', 'C', 5000, '', '0000-00-00');


# dumping data for GayaFusionAll.tblengobe
INSERT INTO `tblengobe` (`ID`, `EngobeCode`, `EngobeDescription`, `EngobeDate`, `EngobeTechDraw`, `EngobePhoto1`, `EngobePhoto2`, `EngobePhoto3`, `EngobePhoto4`, `EngobeNotes`) VALUES (1, 'en1', 'tes engobe', '2008-03-06', '', '', '', '', '', '');
INSERT INTO `tblengobe` (`ID`, `EngobeCode`, `EngobeDescription`, `EngobeDate`, `EngobeTechDraw`, `EngobePhoto1`, `EngobePhoto2`, `EngobePhoto3`, `EngobePhoto4`, `EngobeNotes`) VALUES (2, 'EN08-002', 'Engobe Nomor 2', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblestruder
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (1, 'ES01', 'Estruder1', '0000-00-00', '', '20080331064805-login2.jpg', '', '', '', 'Testing\r\nhaha');


# dumping data for GayaFusionAll.tblfiringplan
INSERT INTO `tblfiringplan` (`ID`, `FiringPlanCode`, `FiringPlanDescription`, `FiringPlanDate`, `FiringPlanTechDraw`, `FiringPlanPhoto1`, `FiringPlanPhoto2`, `FiringPlanPhoto3`, `FiringPlanPhoto4`, `FiringPlanNotes`) VALUES (1, 'FP01', 'piring plan no 1', '2008-03-09', '', '20080316053015-jazz.jpg', '', '', '', '');


# dumping data for GayaFusionAll.tblglaze
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (1, 'Gl001', 'Glaze nomor 1', '2008-03-09', '20080322203858-vase.jpg', '20080322203858-heliconia vase_200.jpg', '', '', '', 'Ini isinya notesnya..\r\nbisa pake enter ga ya??');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (2, 'GL002', 'tes glaze nomor 2', '2008-03-15', '', '', '', '', '', 'tes dulu yak :D');




# dumping data for GayaFusionAll.tblstainoxid
INSERT INTO `tblstainoxid` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (1, 'SX01', 'stain no 1', '2008-03-10', '20080316053050-BITS logo.jpg', '20080316053050-jazz.jpg', '', '', '', 'hahaha');


# dumping data for GayaFusionAll.tblstainoxide
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (1, 'SX01', 'stain no 1', '2008-03-10', '20080316053050-BITS logo.jpg', '20080316053050-jazz.jpg', '', '', '', 'hahaha');
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (2, 'SX08-002', 'Coba stain ke dua', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblsupplier
INSERT INTO `tblsupplier` (`ID`, `SupCode`, `SupCompany`, `SupContact`, `SupAddress`, `SupHP`, `SupOffice`, `SupFax`, `SupEmail`, `SupItems`, `SupOtherInfo`) VALUES (1, 'sup01', 'supplier no 1', 'Mr. John Doe', 'Jl.Kaliurang GG v/35\r\nDenpasar\r\n80225', '0818098765432', 'kantoras', '7896987', 'testing@testya.com', 'Silvers', 'testing ya');
INSERT INTO `tblsupplier` (`ID`, `SupCode`, `SupCompany`, `SupContact`, `SupAddress`, `SupHP`, `SupOffice`, `SupFax`, `SupEmail`, `SupItems`, `SupOtherInfo`) VALUES (2, 'sup02', 'Sumpe loo', 'Mr Sumpe', 'blablabla no 54', '098589345', 'blukutuk', '978798', 'adj@jkjd.com', 'Golds', 'there\'s no info');


# dumping data for GayaFusionAll.tbltexture
INSERT INTO `tbltexture` (`ID`, `TextureCode`, `TextureDescription`, `TextureDate`, `TextureTechDraw`, `TexturePhoto1`, `TexturePhoto2`, `TexturePhoto3`, `TexturePhoto4`, `TextureNotes`) VALUES (1, 'tx001', 'ini texture kesatu', '0000-00-00', '', '', '', '', '', 'tes');


# dumping data for GayaFusionAll.tbltools
INSERT INTO `tbltools` (`ID`, `ToolsCode`, `ToolsDescription`, `ToolsDate`, `ToolsTechDraw`, `ToolsPhoto1`, `ToolsPhoto2`, `ToolsPhoto3`, `ToolsPhoto4`, `ToolsNotes`) VALUES (1, 'TL01', 'testing no 1', '0000-00-00', '', '20080416040106-P5010011.JPG', '20080416035802-P5010009.JPG', '20080416035802-P5100099.JPG', '20080416035802-PC170116.JPG', 'hahaha\r\ngda');


# dumping data for GayaFusionAll.tblunit
INSERT INTO `tblunit` (`UnitID`, `UnitValue`) VALUES ('A', 'Unit Of A');
INSERT INTO `tblunit` (`UnitID`, `UnitValue`) VALUES ('B', 'Unit of B');
INSERT INTO `tblunit` (`UnitID`, `UnitValue`) VALUES ('C', 'Unit of C');


# dumping data for GayaFusionAll.tbluser
INSERT INTO `tbluser` (`id`, `UserName`, `LastName`, `FirstName`, `Password`, `Type`) VALUES (12, 'costing', 'costingan', 'costing', '80ae4cae7c034951fd3194bfffed7d4f', 'Costing');
INSERT INTO `tbluser` (`id`, `UserName`, `LastName`, `FirstName`, `Password`, `Type`) VALUES (13, 'admin', 'boongan', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin');
INSERT INTO `tbluser` (`id`, `UserName`, `LastName`, `FirstName`, `Password`, `Type`) VALUES (14, 'Rnd', 'Rnd', 'Orang', '577c2406e417ed786986e6a6cfd55317', 'RnD');


