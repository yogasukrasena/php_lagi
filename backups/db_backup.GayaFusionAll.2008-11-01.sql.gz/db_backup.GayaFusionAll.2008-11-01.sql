# backupDB() v1.1.31 (http://www.silisoftware.com)
# mySQL backup (November 1, 2008 3:12 am)   Type = Complete

CREATE TABLE `GayaFusionAll`.`ar_invoice` (
  `ar_invoice_id` int(11) NULL auto_increment,
  `proforma_h_id` int(11) NULL,
  `invoice_h_id` int(11) NULL,
  `ClientID` int(11) NULL,
  `due_date` date NULL default '0000-00-00',
  `SubTotal` decimal(10,2) NULL default '0.00',
  `Discount` decimal(10,2) NULL default '0.00',
  `Packaging` decimal(10,2) NULL default '0.00',
  `Fumigation` decimal(10,2) NULL default '0.00',
  `GrandTotal` decimal(10,2) NULL default '0.00',
  `Currency` int(11) NULL,
  `Rate` decimal(10,2) NULL,
  `Paid` tinyint(1) NULL,
  PRIMARY KEY (`ar_invoice_id`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`ar_proforma` (
  `ar_proforma_id` int(11) NULL auto_increment,
  `client_id` int(11) NULL,
  `proforma_h_id` int(11) NULL,
  `pre_date` date NULL,
  `SubTotal` decimal(10,2) NULL default '0.00',
  `Discount` decimal(10,2) NULL default '0.00',
  `Packaging` decimal(10,2) NULL default '0.00',
  `Fumigation` decimal(10,2) NULL default '0.00',
  `GrandTotal` decimal(10,2) NULL default '0.00',
  `Currency` int(11) NULL,
  `Rate` decimal(10,2) NULL,
  `Paid` tinyint(1) NULL,
  PRIMARY KEY (`ar_proforma_id`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`pay_invoice` (
  `pay_invoice_id` int(11) NULL auto_increment,
  `ar_invoice_id` int(11) NULL,
  `paid_date` date NULL,
  `amount_paid` decimal(10,2) NULL,
  `currency_id` int(11) NULL,
  `Rate` decimal(10,2) NULL,
  `receiver` int(11) NULL,
  PRIMARY KEY (`pay_invoice_id`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`pay_proforma` (
  `pay_proforma_id` int(11) NULL auto_increment,
  `ar_proforma_id` int(11) NULL,
  `paid_date` date NULL,
  `amount_paid` decimal(10,2) NULL,
  `currency_id` int(11) NULL,
  `Rate` decimal(10,2) NULL,
  `receiver` int(11) NULL,
  PRIMARY KEY (`pay_proforma_id`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`sampleceramic` (
  `sID` int(10) NULL auto_increment,
  `SampleCode` varchar(12) NULL,
  `SampleDescription` varchar(100) NULL,
  `ClientCode` varchar(20) NULL,
  `ClientDescription` varchar(50) NULL,
  `SampleDate` date NULL,
  `TechDraw` varchar(50) NULL,
  `Photo1` varchar(50) NULL,
  `Photo2` varchar(50) NULL,
  `Photo3` varchar(50) NULL,
  `Photo4` varchar(50) NULL,
  `RefID` int(11) NULL,
  `Clay` int(11) NULL,
  `ClayKG` decimal(10,0) NULL,
  `ClayNote` text NULL,
  `BuildTech` varchar(50) NULL,
  `BuildTechNote` text NULL,
  `Rim` varchar(30) NULL,
  `Feet` varchar(30) NULL,
  `Casting1` int(11) NULL,
  `Casting2` int(11) NULL,
  `Casting3` int(11) NULL,
  `Casting4` int(11) NULL,
  `CastingNote` text NULL,
  `Estruder1` int(11) NULL,
  `Estruder2` int(11) NULL,
  `Estruder3` int(11) NULL,
  `Estruder4` int(11) NULL,
  `EstruderNote` text NULL,
  `Texture1` int(11) NULL,
  `Texture2` int(11) NULL,
  `Texture3` int(11) NULL,
  `Texture4` int(11) NULL,
  `TextureNote` text NULL,
  `Tools1` int(11) NULL,
  `Tools2` int(11) NULL,
  `Tools3` int(11) NULL,
  `Tools4` int(11) NULL,
  `ToolsNote` text NULL,
  `Engobe1` int(11) NULL,
  `Engobe2` int(11) NULL,
  `Engobe3` int(11) NULL,
  `Engobe4` int(11) NULL,
  `EngobeNote` text NULL,
  `BisqueTemp` varchar(10) NULL,
  `StainOxide1` int(11) NULL,
  `StainOxide2` int(11) NULL,
  `StainOxide3` int(11) NULL,
  `StainOxide4` int(11) NULL,
  `StainOxideNote` text NULL,
  `Glaze1` int(11) NULL,
  `Glaze2` int(11) NULL,
  `Glaze3` int(11) NULL,
  `Glaze4` int(11) NULL,
  `GlazeDensity1` varchar(10) NULL,
  `GlazeDensity2` varchar(10) NULL,
  `GlazeDensity3` varchar(10) NULL,
  `GlazeDensity4` varchar(10) NULL,
  `GlazeNote` text NULL,
  `GlazeTemp` varchar(10) NULL,
  `Firing` varchar(10) NULL default 'Oxidation',
  `FiringNote` text NULL,
  `Width` decimal(10,2) NULL,
  `Height` decimal(10,2) NULL,
  `Length` decimal(10,2) NULL,
  `Diameter` decimal(10,2) NULL,
  `FinalSizeNote` text NULL,
  `DesignMat1` int(11) NULL,
  `DesignMat2` int(11) NULL,
  `DesignMat3` int(11) NULL,
  `DesignMat4` int(11) NULL,
  `DesignMatQty1` int(10) NULL,
  `DesignMatQty2` int(10) NULL,
  `DesignMatQty3` int(10) NULL,
  `DesignMatQty4` int(10) NULL,
  `DesignMatNote` text NULL,
  `History` text NULL,
  `ClayType` int(11) NULL,
  `ClayPreparationMinute` int(11) NULL,
  `WheelMinute` int(11) NULL,
  `SlabMinute` int(11) NULL,
  `CastingMinute` int(11) NULL,
  `FinishingMinute` int(11) NULL,
  `GlazingMinute` int(11) NULL,
  `StandardBisqueLoading` int(11) NULL,
  `StandardGlazeLoading` int(11) NULL,
  `RakuBisqueLoading` int(11) NULL,
  `RakuGlazeLoading` int(11) NULL,
  `MovementMinute` int(11) NULL,
  `PackagingWorkMinute` int(11) NULL,
  `ClayPreparationPPH` int(11) NULL,
  `WheelPPH` int(11) NULL,
  `SlabPPH` int(11) NULL,
  `CastingPPH` int(11) NULL,
  `FinishingPPH` int(11) NULL,
  `GlazingPPH` int(11) NULL,
  `MovementPPH` int(11) NULL,
  `PackagingWorkPPH` int(11) NULL,
  `RealSellingPrice` decimal(10,2) NULL default '0.00',
  `PriceDollar` decimal(10,2) NULL default '0.00',
  `PriceEuro` decimal(10,2) NULL default '0.00',
  `LastUpdate` date NULL default '0000-00-00',
  PRIMARY KEY (`sID`),
  UNIQUE KEY `SampleCode` (`SampleCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`sampleother` (
  `ID` int(10) NULL auto_increment,
  `SampleCode` varchar(12) NULL,
  `Description` varchar(50) NULL,
  `SampleDate` date NULL default '0000-00-00',
  `TechDraw` varchar(50) NULL,
  `Photo1` varchar(50) NULL,
  `Photo2` varchar(50) NULL,
  `Photo3` varchar(50) NULL,
  `Photo4` varchar(50) NULL,
  `DesMat1` int(11) NULL,
  `DesMat2` int(11) NULL,
  `DesMat3` int(11) NULL,
  `DesMat4` int(11) NULL,
  `DesMat5` int(11) NULL,
  `QtyDesMat1` int(11) NULL,
  `QtyDesMat2` int(11) NULL,
  `QtyDesMat3` int(11) NULL,
  `QtyDesMat4` int(11) NULL,
  `QtyDesMat5` int(11) NULL,
  `TotalDesMat1` decimal(10,0) NULL,
  `TotalDesMat2` decimal(10,0) NULL,
  `TotalDesMat3` decimal(10,0) NULL,
  `TotalDesMat4` decimal(10,0) NULL,
  `TotalDesMat5` decimal(10,0) NULL,
  `Supplier1` int(11) NULL,
  `Supplier2` int(11) NULL,
  `Supplier3` int(11) NULL,
  `Supplier4` int(11) NULL,
  `Supplier5` int(11) NULL,
  `Material1` varchar(50) NULL,
  `Material2` varchar(50) NULL,
  `Material3` varchar(50) NULL,
  `Material4` varchar(50) NULL,
  `Material5` varchar(50) NULL,
  `Color1` varchar(50) NULL,
  `Color2` varchar(50) NULL,
  `Color3` varchar(50) NULL,
  `Color4` varchar(50) NULL,
  `Color5` varchar(50) NULL,
  `CostPrice1` decimal(10,0) NULL,
  `CostPrice2` decimal(10,0) NULL,
  `CostPrice3` decimal(10,0) NULL,
  `CostPrice4` decimal(10,0) NULL,
  `CostPrice5` decimal(10,0) NULL,
  `TotalDesMat` double NULL,
  `TotalCostPrice` double NULL,
  `TotalCost` double NULL,
  `Width` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  `Diameter` decimal(10,0) NULL,
  `Volume` decimal(10,2) NULL,
  `Notes` text NULL,
  `PriceRisk` double NULL,
  `RealPrice` double NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SampleCode` (`SampleCode`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`samplepackaging` (
  `ID` int(10) NULL auto_increment,
  `SampleCode` varchar(12) NULL,
  `Description` varchar(50) NULL,
  `SampleDate` date NULL default '0000-00-00',
  `TechDraw` varchar(50) NULL,
  `Photo1` varchar(50) NULL,
  `Photo2` varchar(50) NULL,
  `Photo3` varchar(50) NULL,
  `Photo4` varchar(50) NULL,
  `DesMat1` int(11) NULL,
  `DesMat2` int(11) NULL,
  `DesMat3` int(11) NULL,
  `DesMat4` int(11) NULL,
  `DesMat5` int(11) NULL,
  `QtyDesMat1` int(11) NULL,
  `QtyDesMat2` int(11) NULL,
  `QtyDesMat3` int(11) NULL,
  `QtyDesMat4` int(11) NULL,
  `QtyDesMat5` int(11) NULL,
  `TotalDesMat1` double NULL,
  `TotalDesMat2` double NULL,
  `TotalDesMat3` double NULL,
  `TotalDesMat4` double NULL,
  `TotalDesMat5` double NULL,
  `Supplier1` int(11) NULL,
  `Supplier2` int(11) NULL,
  `Supplier3` int(11) NULL,
  `Supplier4` int(11) NULL,
  `Supplier5` int(11) NULL,
  `Material1` varchar(50) NULL,
  `Material2` varchar(50) NULL,
  `Material3` varchar(50) NULL,
  `Material4` varchar(50) NULL,
  `Material5` varchar(50) NULL,
  `Color1` varchar(50) NULL,
  `Color2` varchar(50) NULL,
  `Color3` varchar(50) NULL,
  `Color4` varchar(50) NULL,
  `Color5` varchar(50) NULL,
  `CostPrice1` decimal(10,0) NULL,
  `CostPrice2` decimal(10,0) NULL,
  `CostPrice3` decimal(10,0) NULL,
  `CostPrice4` decimal(10,0) NULL,
  `CostPrice5` decimal(10,0) NULL,
  `TotalDesMat` double NULL,
  `TotalCostPrice` double NULL,
  `TotalCost` double NULL,
  `InnerQty` int(11) NULL,
  `Width` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  `Diameter` decimal(10,0) NULL,
  `Volume` decimal(10,2) NULL,
  `Weight` decimal(10,2) NULL,
  `Notes` text NULL,
  `PriceRisk` double NULL,
  `RealPrice` double NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SampleCode` (`SampleCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tbladmin` (
  `ID` int(2) NULL auto_increment,
  `UserName` varchar(15) NULL,
  `Passwd` varchar(10) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tbladminist_addressbook` (
  `AddressID` int(11) NULL auto_increment,
  `Company` varchar(100) NULL,
  PRIMARY KEY (`AddressID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_addressbook_contact` (
  `ContactId` int(11) NULL auto_increment,
  `AddressID` int(11) NULL,
  `ContactName` varchar(100) NULL,
  `Email` varchar(50) NULL,
  `Address` text NULL,
  `Phone` varchar(20) NULL,
  `Fax` varchar(20) NULL,
  PRIMARY KEY (`ContactId`),
  KEY `AddressID` (`AddressID`,`ContactName`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_ar_h` (
  `AR_ID` int(11) NULL auto_increment,
  `ClientID` int(11) NULL,
  `CurrencyID` int(11) NULL,
  `DocCode` varchar(11) NULL,
  `SubTotal` decimal(20,2) NULL,
  `Discount` decimal(10,2) NULL default '0.00',
  `PackagingCost` decimal(10,2) NULL,
  `GrandTotal` decimal(20,2) NULL,
  `Deposit` decimal(10,2) NULL,
  `Balance` decimal(10,2) NULL,
  PRIMARY KEY (`AR_ID`),
  KEY `ClientID` (`ClientID`,`DocCode`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_box_d` (
  `Box_D_ID` int(20) NULL auto_increment,
  `Box_H_ID` int(11) NULL,
  `Qty` int(11) NULL,
  `Unit` varchar(15) NULL,
  `CollectID` int(11) NULL,
  `Remarks` text NULL,
  PRIMARY KEY (`Box_D_ID`),
  KEY `ID_Box_H` (`Box_H_ID`,`CollectID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_box_h` (
  `Box_H_ID` int(10) NULL auto_increment,
  `BoxNumber` varchar(30) NULL,
  `PL_H_ID` int(11) NULL,
  `Length` decimal(10,0) NULL,
  `Width` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Weight` decimal(10,0) NULL,
  PRIMARY KEY (`Box_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_client` (
  `ClientID` int(11) NULL auto_increment,
  `ClientCompany` varchar(100) NULL,
  PRIMARY KEY (`ClientID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_currency` (
  `CurrencyID` int(11) NULL auto_increment,
  `CurrencyCode` varchar(3) NULL,
  `Currency` varchar(50) NULL,
  `Rate` decimal(10,2) NULL default '0.00',
  PRIMARY KEY (`CurrencyID`),
  UNIQUE KEY `CurrencyCode` (`CurrencyCode`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_deliveryterm` (
  `DeliveryTermID` int(11) NULL auto_increment,
  `DeliveryTerm` varchar(100) NULL,
  PRIMARY KEY (`DeliveryTermID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_deliverytime` (
  `DeliveryTimeID` int(20) NULL auto_increment,
  `DeliveryTime` varchar(100) NULL,
  PRIMARY KEY (`DeliveryTimeID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_invoice_d` (
  `Invoice_D_ID` int(20) NULL auto_increment,
  `Invoice_H_ID` int(11) NULL,
  `Qty` int(11) NULL,
  `Unit` varchar(15) NULL,
  `CollectID` int(11) NULL,
  `CollectCode` varchar(13) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Total` decimal(10,0) NULL,
  PRIMARY KEY (`Invoice_D_ID`),
  KEY `ID_Invoice_H` (`Invoice_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_invoice_h` (
  `Invoice_H_ID` int(20) NULL auto_increment,
  `InvoiceNo` varchar(100) NULL,
  `InvoiceDate` date NULL default '0000-00-00',
  `ClientOrderRef` varchar(50) NULL,
  `GayaOrderRef` varchar(50) NULL,
  `DeliveryTermID` int(11) NULL,
  `PaymentTermID` int(50) NULL,
  `DueDate` date NULL default '0000-00-00',
  `ClientID` int(11) NULL,
  `Quotation_H_ID` int(11) NULL,
  `Proforma_H_ID` int(11) NULL,
  `AddressID` int(11) NULL,
  `CurrencyID` int(11) NULL,
  `PackagingCost` int(11) NULL,
  `InvoiceContactID` int(11) NULL,
  `DeliveryContactID` int(11) NULL,
  `SubTotal` decimal(10,2) NULL default '0.00',
  `Discount` decimal(10,2) NULL default '0.00',
  `Packaging` decimal(10,2) NULL default '0.00',
  `Fumigation` decimal(10,2) NULL default '0.00',
  `GrandTotal` decimal(10,2) NULL default '0.00',
  `PaymentBankTransferred` decimal(10,0) NULL,
  `Balance` decimal(10,0) NULL,
  `DocMaker` int(11) NULL,
  PRIMARY KEY (`Invoice_H_ID`),
  UNIQUE KEY `InvoiceNo_2` (`InvoiceNo`),
  KEY `ClientOrderRef` (`ClientOrderRef`),
  KEY `GayaOrderRef` (`GayaOrderRef`),
  KEY `InvoiceNo` (`InvoiceNo`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_invoice_sh` (
  `Invoice_SH_ID` int(11) NULL auto_increment,
  `InvoiceNo` varchar(16) NULL,
  `ClientID` int(11) NULL,
  `Quotation_H_ID` int(11) NULL,
  `Proforma_H_ID` int(11) NULL,
  `AddressID` int(11) NULL,
  PRIMARY KEY (`Invoice_SH_ID`),
  KEY `InvoiceNo` (`InvoiceNo`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_packinglist_d` (
  `PL_D_ID` int(11) NULL auto_increment,
  `PL_H_ID` int(11) NULL,
  `Box_H_ID` int(11) NULL,
  PRIMARY KEY (`PL_D_ID`),
  KEY `ID_PackingList_H` (`PL_H_ID`,`Box_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_packinglist_h` (
  `PL_H_ID` int(11) NULL auto_increment,
  `PLNo` varchar(15) NULL,
  `PLDate` date NULL default '0000-00-00',
  `Invoice_H_ID` int(11) NULL,
  `AddressID` int(11) NULL,
  `InvoiceContactID` int(11) NULL,
  `DeliveryContactID` int(11) NULL,
  `OrderRef` varchar(200) NULL,
  PRIMARY KEY (`PL_H_ID`),
  KEY `PackListNo` (`PLNo`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_payment` (
  `PaymentId` int(11) NULL,
  `AR_ID` int(11) NULL,
  `DocCode` varchar(12) NULL,
  `PaymentType` int(11) NULL,
  `DatePaid` date NULL default '0000-00-00',
  `CurencyConversion` decimal(10,2) NULL,
  `AmountPaid` decimal(10,2) NULL,
  PRIMARY KEY (`PaymentId`),
  KEY `AR_ID` (`AR_ID`,`DocCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tbladminist_paymentterm` (
  `PaymentTermID` int(8) NULL auto_increment,
  `PaymentTerm` varchar(100) NULL,
  PRIMARY KEY (`PaymentTermID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_paymenttype` (
  `PaymentTypeID` tinyint(4) NULL auto_increment,
  `PaymentType` varchar(15) NULL,
  PRIMARY KEY (`PaymentTypeID`),
  KEY `PaymentType` (`PaymentType`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_pol_d` (
  `POL_D_ID` int(11) NULL auto_increment,
  `POL_H_ID` int(11) NULL,
  `CollectID` int(11) NULL,
  `Qty` int(11) NULL,
  PRIMARY KEY (`POL_D_ID`),
  KEY `POL_H_ID` (`POL_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_pol_h` (
  `POL_H_ID` int(11) NULL auto_increment,
  `POLNo` varchar(11) NULL,
  `Proforma_H_ID` int(11) NULL,
  `ClientID` int(11) NULL,
  `ClientOrderRef` varchar(30) NULL,
  `POLDate` date NULL default '0000-00-00',
  `DeliveryTimeID` int(11) NULL,
  PRIMARY KEY (`POL_H_ID`),
  KEY `Proforma_H_ID` (`Proforma_H_ID`),
  KEY `POLNo` (`POLNo`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_prodorderlist_proforma` (
  `Prof_Pol_ID` int(11) NULL auto_increment,
  `ProformaID` int(11) NULL,
  `ProdOrderListID` int(11) NULL,
  PRIMARY KEY (`Prof_Pol_ID`),
  KEY `ProformaID` (`ProformaID`,`ProdOrderListID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_proforma_d` (
  `Proforma_D_ID` int(20) NULL auto_increment,
  `Proforma_H_ID` int(11) NULL,
  `CollectID` int(11) NULL,
  `CollectCode` varchar(13) NULL,
  `Qty` int(11) NULL,
  `Unit` varchar(15) NULL,
  `Type` int(11) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Total` decimal(10,0) NULL,
  PRIMARY KEY (`Proforma_D_ID`),
  KEY `Proforma_H_ID` (`Proforma_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_proforma_h` (
  `Proforma_H_ID` int(11) NULL auto_increment,
  `ProformaNo` varchar(11) NULL,
  `Rev` varchar(10) NULL,
  `Validity` varchar(15) NULL,
  `ProformaDate` date NULL,
  `ClientOrderRef` varchar(50) NULL,
  `ClientID` int(11) NULL,
  `AddressID` int(11) NULL,
  `ContactID` int(11) NULL,
  `PackagingCost` int(11) NULL,
  `DeliveryTermID` int(11) NULL,
  `DeliveryTimeID` int(11) NULL,
  `PaymentTermID` int(11) NULL,
  `SpecialInstruction` text NULL,
  `PreviewDPDate` date NULL default '0000-00-00',
  `Quotation_H_ID` int(11) NULL,
  `SubTotal` decimal(10,2) NULL default '0.00',
  `Discount` decimal(10,2) NULL default '0.00',
  `Packaging` decimal(10,2) NULL default '0.00',
  `Fumigation` decimal(10,2) NULL default '0.00',
  `GrandTotal` decimal(10,2) NULL default '0.00',
  `Currency` int(11) NULL,
  `DocMaker` int(11) NULL,
  PRIMARY KEY (`Proforma_H_ID`),
  KEY `ProformaNo` (`ProformaNo`,`ClientOrderRef`),
  KEY `Quotation_H_ID` (`Quotation_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_proformarev_d` (
  `ProformaRev_D_ID` int(11) NULL auto_increment,
  `Proforma_D_ID` int(20) NULL,
  `Proforma_H_ID` int(11) NULL,
  `CollectID` int(11) NULL,
  `CollectCode` varchar(13) NULL,
  `Qty` int(11) NULL,
  `Unit` varchar(15) NULL,
  `Type` int(11) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Total` decimal(10,0) NULL,
  PRIMARY KEY (`ProformaRev_D_ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_proformarev_h` (
  `ProformaRev_H_ID` int(11) NULL auto_increment,
  `Proforma_H_ID` int(11) NULL,
  `ProformaNo` varchar(11) NULL,
  `Rev` varchar(10) NULL,
  `Validity` varchar(15) NULL,
  `ProformaDate` date NULL,
  `ClientOrderRef` varchar(50) NULL,
  `ClientID` int(11) NULL,
  `AddressID` int(11) NULL,
  `ContactID` int(11) NULL,
  `PackagingCost` decimal(10,0) NULL,
  `DeliveryTermID` int(11) NULL,
  `DeliveryTimeID` int(11) NULL,
  `PaymentTermID` int(11) NULL,
  `SpecialInstruction` text NULL,
  `PreviewDPDate` date NULL default '0000-00-00',
  `Quotation_H_ID` int(11) NULL,
  PRIMARY KEY (`ProformaRev_H_ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotation_d` (
  `Quotation_D_ID` int(20) NULL auto_increment,
  `Quotation_H_ID` int(11) NULL,
  `RndCode` varchar(12) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Remark` text NULL,
  PRIMARY KEY (`Quotation_D_ID`),
  KEY `ID_Quotation_H` (`Quotation_H_ID`,`RndCode`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotation_h` (
  `Quotation_H_ID` int(20) NULL auto_increment,
  `QuotationNo` varchar(11) NULL,
  `Rev` varchar(10) NULL,
  `Validity` varchar(15) NULL,
  `QuotationDate` date NULL default '0000-00-00',
  `ClientOrderRef` varchar(50) NULL,
  `ClientID` int(11) NULL,
  `AddressID` int(11) NULL,
  `ContactID` int(11) NULL,
  `PackagingCost` float(10,0) NULL,
  `DeliveryTermID` int(11) NULL,
  `DeliveryTimeID` int(11) NULL,
  `PaymentTermID` int(11) NULL,
  `SpecialInstruction` text NULL,
  `Currency` int(11) NULL,
  `DocMaker` int(11) NULL,
  PRIMARY KEY (`Quotation_H_ID`),
  KEY `QuotationNo` (`QuotationNo`,`ClientOrderRef`),
  KEY `ClientID` (`ClientID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotation_proforma` (
  `ID` int(11) NULL auto_increment,
  `QuotationID` int(11) NULL,
  `ProformaID` int(11) NULL,
  PRIMARY KEY (`ID`),
  KEY `ProformaID` (`ProformaID`,`QuotationID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotationrev_d` (
  `QuotationRev_D_ID` int(11) NULL auto_increment,
  `QuotationRev_H_ID` int(11) NULL,
  `Quotation_D_ID` int(20) NULL,
  `Quotation_H_ID` int(11) NULL,
  `RndCode` varchar(12) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Remark` text NULL,
  PRIMARY KEY (`QuotationRev_D_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotationrev_h` (
  `QuotationRev_H_ID` int(11) NULL auto_increment,
  `Quotation_H_ID` int(20) NULL,
  `QuotationNo` varchar(11) NULL,
  `Rev` varchar(10) NULL,
  `Validity` varchar(15) NULL,
  `QuotationDate` date NULL default '0000-00-00',
  `ClientOrderRef` varchar(50) NULL,
  `ClientID` int(11) NULL,
  `AddressID` int(11) NULL,
  `ContactID` int(11) NULL,
  `PackagingCost` float(10,0) NULL,
  `DeliveryTermID` int(11) NULL,
  `DeliveryTimeID` int(11) NULL,
  `PaymentTermID` int(11) NULL,
  `SpecialInstruction` text NULL,
  PRIMARY KEY (`QuotationRev_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tblcasting` (
  `ID` int(11) NULL auto_increment,
  `CastingCode` varchar(10) NULL,
  `CastingDescription` varchar(100) NULL,
  `CastingDate` date NULL default '0000-00-00',
  `CastingTechDraw` varchar(50) NULL,
  `CastingPhoto1` varchar(50) NULL,
  `CastingPhoto2` varchar(50) NULL,
  `CastingPhoto3` varchar(50) NULL,
  `CastingPhoto4` varchar(50) NULL,
  `CastingNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `CastingCode` (`CastingCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblclay` (
  `ID` int(11) NULL auto_increment,
  `ClayCode` varchar(10) NULL,
  `ClayDescription` varchar(100) NULL,
  `ClayDate` date NULL default '0000-00-00',
  `ClayTechDraw` varchar(50) NULL,
  `ClayPhoto1` varchar(50) NULL,
  `ClayPhoto2` varchar(50) NULL,
  `ClayPhoto3` varchar(50) NULL,
  `ClayPhoto4` varchar(50) NULL,
  `ClayNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ClayCode` (`ClayCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcollect_category` (
  `CategoryCode` varchar(2) NULL,
  `CategoryName` varchar(50) NULL,
  PRIMARY KEY (`CategoryCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_color` (
  `ColorCode` varchar(2) NULL,
  `ColorName` varchar(100) NULL,
  PRIMARY KEY (`ColorCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_design` (
  `DesignCode` varchar(2) NULL,
  `DesignName` varchar(100) NULL,
  PRIMARY KEY (`DesignCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_group_det` (
  `ID` int(11) NULL auto_increment,
  `Group_H_ID` int(11) NULL,
  `CollectCode` varchar(15) NULL,
  `Qty` int(11) NULL,
  PRIMARY KEY (`ID`),
  KEY `Group_H_ID` (`Group_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tblcollect_group_h` (
  `Group_H_ID` int(11) NULL auto_increment,
  `GroupCode` varchar(12) NULL,
  `GroupDate` date NULL default '0000-00-00',
  `DesignCode` varchar(2) NULL,
  `GroupDescription` varchar(255) NULL,
  `ClientCode` varchar(50) NULL,
  `ClientDesc` varchar(255) NULL,
  `GroupPhoto` varchar(50) NULL,
  `Diameter` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Weight` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  PRIMARY KEY (`Group_H_ID`),
  UNIQUE KEY `Code` (`GroupCode`)
) TYPE=MyISAM AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tblcollect_master` (
  `ID` int(11) NULL auto_increment,
  `CollectCode` varchar(15) NULL,
  `DesignCode` varchar(2) NULL,
  `NameCode` varchar(2) NULL,
  `CategoryCode` varchar(2) NULL,
  `SizeCode` varchar(2) NULL,
  `TextureCode` varchar(2) NULL,
  `ColorCode` varchar(2) NULL,
  `MaterialCode` varchar(2) NULL,
  `ClientCode` varchar(20) NULL,
  `ClientDescription` varchar(50) NULL,
  `CollectDate` date NULL default '0000-00-00',
  `TechDraw` varchar(50) NULL,
  `Photo1` varchar(50) NULL,
  `Photo2` varchar(50) NULL,
  `Photo3` varchar(50) NULL,
  `Photo4` varchar(50) NULL,
  `RefID` int(11) NULL,
  `Clay` int(11) NULL,
  `ClayKG` decimal(10,0) NULL,
  `ClayNote` text NULL,
  `BuildTech` varchar(50) NULL,
  `BuildTechNote` text NULL,
  `Rim` varchar(30) NULL,
  `Feet` varchar(30) NULL,
  `Casting1` int(11) NULL,
  `Casting2` int(11) NULL,
  `Casting3` int(11) NULL,
  `Casting4` int(11) NULL,
  `CastingNote` text NULL,
  `Estruder1` int(11) NULL,
  `Estruder2` int(11) NULL,
  `Estruder3` int(11) NULL,
  `Estruder4` int(11) NULL,
  `EstruderNote` text NULL,
  `Texture1` int(11) NULL,
  `Texture2` int(11) NULL,
  `Texture3` int(11) NULL,
  `Texture4` int(11) NULL,
  `TextureNote` text NULL,
  `Tools1` int(11) NULL,
  `Tools2` int(11) NULL,
  `Tools3` int(11) NULL,
  `Tools4` int(11) NULL,
  `ToolsNote` text NULL,
  `Engobe1` int(11) NULL,
  `Engobe2` int(11) NULL,
  `Engobe3` int(11) NULL,
  `Engobe4` int(11) NULL,
  `EngobeNote` text NULL,
  `BisqueTemp` varchar(10) NULL,
  `StainOxide1` int(11) NULL,
  `StainOxide2` int(11) NULL,
  `StainOxide3` int(11) NULL,
  `StainOxide4` int(11) NULL,
  `StainOxideNote` text NULL,
  `Glaze1` int(11) NULL,
  `Glaze2` int(11) NULL,
  `Glaze3` int(11) NULL,
  `Glaze4` int(11) NULL,
  `GlazeDensity1` varchar(10) NULL,
  `GlazeDensity2` varchar(10) NULL,
  `GlazeDensity3` varchar(10) NULL,
  `GlazeDensity4` varchar(10) NULL,
  `GlazeNote` text NULL,
  `GlazeTemp` varchar(10) NULL,
  `Firing` varchar(10) NULL,
  `FiringNote` text NULL,
  `Width` decimal(10,2) NULL,
  `Height` decimal(10,2) NULL,
  `Length` decimal(10,2) NULL,
  `Diameter` decimal(10,2) NULL,
  `SampCeramicVolume` decimal(10,2) NULL default '0.00',
  `FinalSizeNote` text NULL,
  `DesignMat1` int(11) NULL,
  `DesignMat2` int(11) NULL,
  `DesignMat3` int(11) NULL,
  `DesignMat4` int(11) NULL,
  `DesignMatQty1` int(10) NULL,
  `DesignMatQty2` int(10) NULL,
  `DesignMatQty3` int(10) NULL,
  `DesignMatQty4` int(10) NULL,
  `DesignMatNote` text NULL,
  `History` text NULL,
  `ClayType` varchar(50) NULL,
  `ClayPreparationMinute` int(11) NULL,
  `WheelMinute` int(11) NULL,
  `SlabMinute` int(11) NULL,
  `CastingMinute` int(11) NULL,
  `FinishingMinute` int(11) NULL,
  `GlazingMinute` int(11) NULL,
  `StandardBisqueLoading` int(11) NULL,
  `StandardGlazeLoading` int(11) NULL,
  `RakuBisqueLoading` int(11) NULL,
  `RakuGlazeLoading` int(11) NULL,
  `MovementMinute` int(11) NULL,
  `PackagingWorkMinute` int(11) NULL,
  `ClayPreparationPPH` int(11) NULL,
  `WheelPPH` int(11) NULL,
  `SlabPPH` int(11) NULL,
  `CastingPPH` int(11) NULL,
  `FinishingPPH` int(11) NULL,
  `GlazingPPH` int(11) NULL,
  `MovementPPH` int(11) NULL,
  `PackagingWorkPPH` int(11) NULL,
  `RealSellingPrice` double NULL,
  `LastUpdate` date NULL default '0000-00-00',
  `PriceDollar` decimal(10,2) NULL default '0.00',
  `PriceEuro` decimal(10,2) NULL default '0.00',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `CollectCode` (`CollectCode`)
) TYPE=MyISAM AUTO_INCREMENT=5;

CREATE TABLE `GayaFusionAll`.`tblcollect_material` (
  `MaterialCode` varchar(2) NULL,
  `MaterialName` varchar(50) NULL,
  PRIMARY KEY (`MaterialCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_name` (
  `NameCode` varchar(2) NULL,
  `NameDesc` varchar(50) NULL,
  PRIMARY KEY (`NameCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_size` (
  `SizeCode` varchar(2) NULL,
  `SizeName` varchar(50) NULL,
  PRIMARY KEY (`SizeCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_texture` (
  `TextureCode` varchar(2) NULL,
  `TextureName` varchar(50) NULL,
  PRIMARY KEY (`TextureCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcosting_casting` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_clay` (
  `ID` int(11) NULL auto_increment,
  `ClayType` varchar(50) NULL,
  `PricePerKG` double NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ClayType` (`ClayType`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tblcosting_claypreparation` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_costbudgetpreview` (
  `ID` int(11) NULL auto_increment,
  `BudgetYear` int(11) NULL,
  `CostBudgetAmmount` double NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_finishing` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_glazing` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_master` (
  `ID` int(1) NULL,
  `ClayPreparationCPM` int(11) NULL,
  `ClayPreparationPPH` int(11) NULL,
  `WheelCPM` int(11) NULL,
  `WheelPPH` int(11) NULL,
  `SlabCPM` int(11) NULL,
  `SlabPPH` int(11) NULL,
  `CastingCPM` int(11) NULL,
  `CastingPPH` int(11) NULL,
  `FinishingCPM` int(11) NULL,
  `FinishingPPH` int(11) NULL,
  `GlazingCPM` int(11) NULL,
  `GlazingPPH` int(11) NULL,
  `MovementCPM` int(11) NULL,
  `MovementPPH` int(11) NULL,
  `PackagingWorkCPM` int(11) NULL,
  `PackagingWorkPPH` int(11) NULL,
  `StandardBisqueCPM` int(11) NULL,
  `StandardBisquePPH` int(11) NULL,
  `StandardGlazeCPM` int(11) NULL,
  `StandardGlazePPH` int(11) NULL,
  `RakuBisqueCPM` int(11) NULL,
  `RakuBisquePPH` int(11) NULL,
  `RakuGlazeCPM` int(11) NULL,
  `RakuGlazePPH` int(11) NULL,
  `ProductiveHourDay` decimal(10,2) NULL default '0.00',
  `ProductiveHourMonth` int(11) NULL,
  `ProductiveHourYear` int(11) NULL,
  `TrowWorker` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcosting_movement` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_packagingwork` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_productivehours` (
  `ID` int(11) NULL auto_increment,
  `Day` decimal(10,2) NULL default '0.00',
  `Month` int(11) NULL,
  `Year` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_rakubisque` (
  `ID` int(11) NULL auto_increment,
  `PricePerFiring` decimal(10,2) NULL default '0.00',
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tblcosting_rakuglaze` (
  `ID` int(11) NULL auto_increment,
  `PricePerFiring` decimal(10,2) NULL default '0.00',
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_slab` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_standardbisque` (
  `ID` int(11) NULL auto_increment,
  `PricePerFiring` decimal(10,2) NULL default '0.00',
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_standardglaze` (
  `ID` int(1) NULL auto_increment,
  `PricePerFiring` decimal(10,2) NULL default '0.00',
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_trowworker` (
  `ID` int(11) NULL auto_increment,
  `TrowWorker` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_wheel` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tbldesignmat` (
  `DesignMatID` int(11) NULL auto_increment,
  `DesignMatCode` varchar(10) NULL,
  `DesignMatDescription` varchar(100) NULL,
  `DesignMatTechDraw` varchar(50) NULL,
  `DesignMatPhoto1` varchar(50) NULL,
  `DesignMatPhoto2` varchar(50) NULL,
  `DesignMatPhoto3` varchar(50) NULL,
  `DesignMatPhoto4` varchar(50) NULL,
  `DesignMatSupplier` int(11) NULL,
  `DesignMatUnit` varchar(2) NULL,
  `DesignMatUnitPrice` decimal(10,0) NULL,
  `DesignMatNotes` text NULL,
  `DesignMatDate` date NULL default '0000-00-00',
  PRIMARY KEY (`DesignMatID`),
  UNIQUE KEY `DesignMatCode` (`DesignMatCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblengobe` (
  `ID` int(11) NULL auto_increment,
  `EngobeCode` varchar(10) NULL,
  `EngobeDescription` varchar(100) NULL,
  `EngobeDate` date NULL default '0000-00-00',
  `EngobeTechDraw` varchar(50) NULL,
  `EngobePhoto1` varchar(50) NULL,
  `EngobePhoto2` varchar(50) NULL,
  `EngobePhoto3` varchar(50) NULL,
  `EngobePhoto4` varchar(50) NULL,
  `EngobeNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `EngobeCode` (`EngobeCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblestruder` (
  `ID` int(11) NULL auto_increment,
  `EstruderCode` varchar(10) NULL,
  `EstruderDescription` varchar(100) NULL,
  `EstruderDate` date NULL default '0000-00-00',
  `EstruderTechDraw` varchar(50) NULL,
  `EstruderPhoto1` varchar(50) NULL,
  `EstruderPhoto2` varchar(50) NULL,
  `EstruderPhoto3` varchar(50) NULL,
  `EstruderPhoto4` varchar(50) NULL,
  `EstruderNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `EstruderCode` (`EstruderCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblfiringplan` (
  `ID` int(11) NULL auto_increment,
  `FiringPlanCode` varchar(10) NULL,
  `FiringPlanDescription` varchar(100) NULL,
  `FiringPlanDate` date NULL default '0000-00-00',
  `FiringPlanTechDraw` varchar(50) NULL,
  `FiringPlanPhoto1` varchar(50) NULL,
  `FiringPlanPhoto2` varchar(50) NULL,
  `FiringPlanPhoto3` varchar(50) NULL,
  `FiringPlanPhoto4` varchar(50) NULL,
  `FiringPlanNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `FiringPlanCode` (`FiringPlanCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblglaze` (
  `ID` int(11) NULL auto_increment,
  `GlazeCode` varchar(10) NULL,
  `GlazeDescription` varchar(100) NULL,
  `GlazeDate` date NULL default '0000-00-00',
  `GlazeTechDraw` varchar(50) NULL,
  `GlazePhoto1` varchar(50) NULL,
  `GlazePhoto2` varchar(50) NULL,
  `GlazePhoto3` varchar(50) NULL,
  `GlazePhoto4` varchar(50) NULL,
  `GlazeNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `GlazeCode` (`GlazeCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblreference` (
  `ID` int(11) NULL auto_increment,
  `RefCode` varchar(20) NULL,
  `sID` int(11) NULL,
  `CollectID` int(11) NULL,
  `RefNote` text NULL,
  PRIMARY KEY (`ID`),
  KEY `sID` (`sID`),
  KEY `CollectID` (`CollectID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tblstainoxide` (
  `ID` int(11) NULL auto_increment,
  `StainOxideCode` varchar(10) NULL,
  `StainOxideDescription` varchar(100) NULL,
  `StainOxideDate` date NULL default '0000-00-00',
  `StainOxideTechDraw` varchar(50) NULL,
  `StainOxidePhoto1` varchar(50) NULL,
  `StainOxidePhoto2` varchar(50) NULL,
  `StainOxidePhoto3` varchar(50) NULL,
  `StainOxidePhoto4` varchar(50) NULL,
  `StainOxideNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `stainoxideCode` (`StainOxideCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblsupplier` (
  `ID` int(11) NULL auto_increment,
  `SupCode` varchar(15) NULL,
  `SupCompany` varchar(100) NULL,
  `SupContact` varchar(100) NULL,
  `SupAddress` varchar(200) NULL,
  `SupHP` varchar(15) NULL,
  `SupOffice` varchar(100) NULL,
  `SupFax` varchar(20) NULL,
  `SupEmail` varchar(50) NULL,
  `SupItems` varchar(100) NULL,
  `SupOtherInfo` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SupCode` (`SupCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tbltexture` (
  `ID` int(11) NULL auto_increment,
  `TextureCode` varchar(10) NULL,
  `TextureDescription` varchar(100) NULL,
  `TextureDate` date NULL default '0000-00-00',
  `TextureTechDraw` varchar(50) NULL,
  `TexturePhoto1` varchar(50) NULL,
  `TexturePhoto2` varchar(50) NULL,
  `TexturePhoto3` varchar(50) NULL,
  `TexturePhoto4` varchar(50) NULL,
  `TextureNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `TextureCode` (`TextureCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tbltools` (
  `ID` int(11) NULL auto_increment,
  `ToolsCode` varchar(10) NULL,
  `ToolsDescription` varchar(100) NULL,
  `ToolsDate` date NULL default '0000-00-00',
  `ToolsTechDraw` varchar(50) NULL,
  `ToolsPhoto1` varchar(50) NULL,
  `ToolsPhoto2` varchar(50) NULL,
  `ToolsPhoto3` varchar(50) NULL,
  `ToolsPhoto4` varchar(50) NULL,
  `ToolsNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ToolsCode` (`ToolsCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblunit` (
  `UnitID` varchar(2) NULL,
  `UnitValue` varchar(30) NULL,
  PRIMARY KEY (`UnitID`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tbluser` (
  `id` int(11) NULL auto_increment,
  `UserName` varchar(15) NULL,
  `LastName` varchar(50) NULL,
  `FirstName` varchar(30) NULL,
  `Password` varchar(50) NULL,
  `Type` varchar(15) NULL,
  PRIMARY KEY (`id`)
) TYPE=MyISAM AUTO_INCREMENT=15;










# dumping data for GayaFusionAll.sampleceramic
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (1, 'SC08-001', 'Armani Casa Summer 2009 - Bowl A', NULL, NULL, NULL, '200810310115220.wp.jpg', '200810310115220.PHO 01.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Oxidation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 0.00, 0.00, '0000-00-00');




# dumping data for GayaFusionAll.samplepackaging
INSERT INTO `samplepackaging` (`ID`, `SampleCode`, `Description`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `DesMat1`, `DesMat2`, `DesMat3`, `DesMat4`, `DesMat5`, `QtyDesMat1`, `QtyDesMat2`, `QtyDesMat3`, `QtyDesMat4`, `QtyDesMat5`, `TotalDesMat1`, `TotalDesMat2`, `TotalDesMat3`, `TotalDesMat4`, `TotalDesMat5`, `Supplier1`, `Supplier2`, `Supplier3`, `Supplier4`, `Supplier5`, `Material1`, `Material2`, `Material3`, `Material4`, `Material5`, `Color1`, `Color2`, `Color3`, `Color4`, `Color5`, `CostPrice1`, `CostPrice2`, `CostPrice3`, `CostPrice4`, `CostPrice5`, `TotalDesMat`, `TotalCostPrice`, `TotalCost`, `InnerQty`, `Width`, `Height`, `Length`, `Diameter`, `Volume`, `Weight`, `Notes`, `PriceRisk`, `RealPrice`) VALUES (1, 'SP08-001', 'Packaging for Lilypad Exhibition', '2008-10-08', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tbladmin
INSERT INTO `tbladmin` (`ID`, `UserName`, `Passwd`) VALUES (1, 'ADMIN', 'ADMIN');




























































# dumping data for GayaFusionAll.tblcasting
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (1, 'CA08-001', 'BOX', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblclay
INSERT INTO `tblclay` (`ID`, `ClayCode`, `ClayDescription`, `ClayDate`, `ClayTechDraw`, `ClayPhoto1`, `ClayPhoto2`, `ClayPhoto3`, `ClayPhoto4`, `ClayNotes`) VALUES (1, 'CL08-001', 'PORCELAIN', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblcollect_category
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('DB', 'DOG BOWL');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('DU', 'DOG UNDER BOWL');


# dumping data for GayaFusionAll.tblcollect_color
INSERT INTO `tblcollect_color` (`ColorCode`, `ColorName`) VALUES ('01', 'SHINY WHITE + BLACK DEC.');


# dumping data for GayaFusionAll.tblcollect_design
INSERT INTO `tblcollect_design` (`DesignCode`, `DesignName`) VALUES ('MM', 'MUNGO AND MAUD');


# dumping data for GayaFusionAll.tblcollect_group_det
INSERT INTO `tblcollect_group_det` (`ID`, `Group_H_ID`, `CollectCode`, `Qty`) VALUES (1, 1, '1', 1);
INSERT INTO `tblcollect_group_det` (`ID`, `Group_H_ID`, `CollectCode`, `Qty`) VALUES (2, 1, '3', 1);


# dumping data for GayaFusionAll.tblcollect_group_h
INSERT INTO `tblcollect_group_h` (`Group_H_ID`, `GroupCode`, `GroupDate`, `DesignCode`, `GroupDescription`, `ClientCode`, `ClientDesc`, `GroupPhoto`, `Diameter`, `Height`, `Weight`, `Length`) VALUES (1, 'MMGR08-001', '0000-01-01', 'MM', 'SET GRAFITTI BOWL SMALL', NULL, NULL, '200810310117090.TEA 05.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblcollect_group_h` (`Group_H_ID`, `GroupCode`, `GroupDate`, `DesignCode`, `GroupDescription`, `ClientCode`, `ClientDesc`, `GroupPhoto`, `Diameter`, `Height`, `Weight`, `Length`) VALUES (2, 'MMGR08-002', '0000-01-01', 'MM', 'SET GRAFITTI BOWL LARGE', NULL, NULL, '200810310117210.TEA SAU 05.jpg', NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblcollect_master
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (1, 'MMGFDBSMSM01PR', 'MM', 'GF', 'DB', 'SM', 'SM', '01', 'PR', NULL, NULL, '0000-01-01', '200810310115530.wp.jpg', '200810310115530.TEA 01.jpg', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-10-08', 0.00, 10.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (2, 'MMGFDBLASM01PR', 'MM', 'GF', 'DB', 'LA', 'SM', '01', 'PR', NULL, NULL, '0000-01-01', '200810310116090.wp.jpg', '200810310116090.TEA 02.jpg', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-10-08', 0.00, 15.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (3, 'MMGFDUSMSM01PR', 'MM', 'GF', 'DU', 'SM', 'SM', '01', 'PR', NULL, NULL, '0000-01-01', '200810310116250.wp.jpg', '200810310116250.TEA 03.jpg', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-10-08', 0.00, 10.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (4, 'MMGFDULASM01PR', 'MM', 'GF', 'DU', 'LA', 'SM', '01', 'PR', NULL, NULL, '0000-01-01', '200810310116370.wp.jpg', '200810310116370.TEA 04.jpg', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-10-08', 0.00, 15.00);


# dumping data for GayaFusionAll.tblcollect_material
INSERT INTO `tblcollect_material` (`MaterialCode`, `MaterialName`) VALUES ('PR', 'PORCELAIN');


# dumping data for GayaFusionAll.tblcollect_name
INSERT INTO `tblcollect_name` (`NameCode`, `NameDesc`) VALUES ('GF', 'GRAFITTI');


# dumping data for GayaFusionAll.tblcollect_size
INSERT INTO `tblcollect_size` (`SizeCode`, `SizeName`) VALUES ('SM', 'SMALL');
INSERT INTO `tblcollect_size` (`SizeCode`, `SizeName`) VALUES ('LA', 'LARGE');


# dumping data for GayaFusionAll.tblcollect_texture
INSERT INTO `tblcollect_texture` (`TextureCode`, `TextureName`) VALUES ('SM', 'SMALL LINE');


# dumping data for GayaFusionAll.tblcosting_casting
INSERT INTO `tblcosting_casting` (`ID`, `CostPerMinute`) VALUES (1, 500);




# dumping data for GayaFusionAll.tblcosting_claypreparation
INSERT INTO `tblcosting_claypreparation` (`ID`, `CostPerMinute`) VALUES (1, 500);


# dumping data for GayaFusionAll.tblcosting_costbudgetpreview
INSERT INTO `tblcosting_costbudgetpreview` (`ID`, `BudgetYear`, `CostBudgetAmmount`) VALUES (1, 2008, 10000000);


# dumping data for GayaFusionAll.tblcosting_finishing
INSERT INTO `tblcosting_finishing` (`ID`, `CostPerMinute`) VALUES (1, 500);


# dumping data for GayaFusionAll.tblcosting_glazing
INSERT INTO `tblcosting_glazing` (`ID`, `CostPerMinute`) VALUES (1, 500);




# dumping data for GayaFusionAll.tblcosting_movement
INSERT INTO `tblcosting_movement` (`ID`, `CostPerMinute`) VALUES (1, 500);


# dumping data for GayaFusionAll.tblcosting_packagingwork
INSERT INTO `tblcosting_packagingwork` (`ID`, `CostPerMinute`) VALUES (1, 500);


# dumping data for GayaFusionAll.tblcosting_productivehours
INSERT INTO `tblcosting_productivehours` (`ID`, `Day`, `Month`, `Year`) VALUES (1, 6.00, 25, 12);


# dumping data for GayaFusionAll.tblcosting_rakubisque
INSERT INTO `tblcosting_rakubisque` (`ID`, `PricePerFiring`) VALUES (1, 5000.00);
INSERT INTO `tblcosting_rakubisque` (`ID`, `PricePerFiring`) VALUES (2, 5000.00);


# dumping data for GayaFusionAll.tblcosting_rakuglaze
INSERT INTO `tblcosting_rakuglaze` (`ID`, `PricePerFiring`) VALUES (1, 5000.00);


# dumping data for GayaFusionAll.tblcosting_slab
INSERT INTO `tblcosting_slab` (`ID`, `CostPerMinute`) VALUES (1, 500);


# dumping data for GayaFusionAll.tblcosting_standardbisque
INSERT INTO `tblcosting_standardbisque` (`ID`, `PricePerFiring`) VALUES (1, 5000.00);


# dumping data for GayaFusionAll.tblcosting_standardglaze
INSERT INTO `tblcosting_standardglaze` (`ID`, `PricePerFiring`) VALUES (1, 5000.00);


# dumping data for GayaFusionAll.tblcosting_trowworker
INSERT INTO `tblcosting_trowworker` (`ID`, `TrowWorker`) VALUES (1, 5);


# dumping data for GayaFusionAll.tblcosting_wheel
INSERT INTO `tblcosting_wheel` (`ID`, `CostPerMinute`) VALUES (1, 500);


# dumping data for GayaFusionAll.tbldesignmat
INSERT INTO `tbldesignmat` (`DesignMatID`, `DesignMatCode`, `DesignMatDescription`, `DesignMatTechDraw`, `DesignMatPhoto1`, `DesignMatPhoto2`, `DesignMatPhoto3`, `DesignMatPhoto4`, `DesignMatSupplier`, `DesignMatUnit`, `DesignMatUnitPrice`, `DesignMatNotes`, `DesignMatDate`) VALUES (1, 'DM08-001', 'SILVER', NULL, NULL, NULL, NULL, NULL, 1, '01', 12000, NULL, '0000-01-01');


# dumping data for GayaFusionAll.tblengobe
INSERT INTO `tblengobe` (`ID`, `EngobeCode`, `EngobeDescription`, `EngobeDate`, `EngobeTechDraw`, `EngobePhoto1`, `EngobePhoto2`, `EngobePhoto3`, `EngobePhoto4`, `EngobeNotes`) VALUES (1, 'EN08-001', 'SAND + PORCELAIN', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblestruder
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (1, 'ES08-001', 'PIPE', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblfiringplan
INSERT INTO `tblfiringplan` (`ID`, `FiringPlanCode`, `FiringPlanDescription`, `FiringPlanDate`, `FiringPlanTechDraw`, `FiringPlanPhoto1`, `FiringPlanPhoto2`, `FiringPlanPhoto3`, `FiringPlanPhoto4`, `FiringPlanNotes`) VALUES (1, 'FP08-001', 'OXIDATION', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblglaze
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (1, 'GL08-001', 'WHITE TRANSPARENT', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);




# dumping data for GayaFusionAll.tblstainoxide
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (1, 'SX08-001', 'BLACK STAIN', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblsupplier
INSERT INTO `tblsupplier` (`ID`, `SupCode`, `SupCompany`, `SupContact`, `SupAddress`, `SupHP`, `SupOffice`, `SupFax`, `SupEmail`, `SupItems`, `SupOtherInfo`) VALUES (1, 'SU08-001', 'ARTHA SILVER', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tbltexture
INSERT INTO `tbltexture` (`ID`, `TextureCode`, `TextureDescription`, `TextureDate`, `TextureTechDraw`, `TexturePhoto1`, `TexturePhoto2`, `TexturePhoto3`, `TexturePhoto4`, `TextureNotes`) VALUES (1, 'TX08-001', 'SMOOTH', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tbltools
INSERT INTO `tbltools` (`ID`, `ToolsCode`, `ToolsDescription`, `ToolsDate`, `ToolsTechDraw`, `ToolsPhoto1`, `ToolsPhoto2`, `ToolsPhoto3`, `ToolsPhoto4`, `ToolsNotes`) VALUES (1, 'TL08-001', 'KNIFE', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblunit
INSERT INTO `tblunit` (`UnitID`, `UnitValue`) VALUES ('01', 'GR');


# dumping data for GayaFusionAll.tbluser
INSERT INTO `tbluser` (`id`, `UserName`, `LastName`, `FirstName`, `Password`, `Type`) VALUES (12, 'costing', 'costingan', 'costing', '80ae4cae7c034951fd3194bfffed7d4f', 'Costing');
INSERT INTO `tbluser` (`id`, `UserName`, `LastName`, `FirstName`, `Password`, `Type`) VALUES (13, 'admin', 'boongan', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin');
INSERT INTO `tbluser` (`id`, `UserName`, `LastName`, `FirstName`, `Password`, `Type`) VALUES (14, 'Rnd', 'Rnd', 'Orang', '577c2406e417ed786986e6a6cfd55317', 'RnD');


