# backupDB() v1.1.31 (http://www.silisoftware.com)
# mySQL backup (January 13, 2009 7:04 am)   Type = Complete

CREATE TABLE `GayaFusionAll`.`ar_invoice` (
  `ar_invoice_id` int(11) NULL auto_increment,
  `proforma_h_id` int(11) NULL,
  `invoice_h_id` int(11) NULL,
  `ClientID` int(11) NULL,
  `due_date` date NULL default '0000-00-00',
  `SubTotal` decimal(10,2) NULL default '0.00',
  `Discount` decimal(10,2) NULL default '0.00',
  `Packaging` decimal(10,2) NULL default '0.00',
  `Fumigation` decimal(10,2) NULL default '0.00',
  `GrandTotal` decimal(10,2) NULL default '0.00',
  `Currency` int(11) NULL,
  `Rate` decimal(10,2) NULL,
  `Paid` tinyint(1) NULL,
  PRIMARY KEY (`ar_invoice_id`)
) TYPE=MyISAM AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`ar_proforma` (
  `ar_proforma_id` int(11) NULL auto_increment,
  `client_id` int(11) NULL,
  `proforma_h_id` int(11) NULL,
  `pre_date` date NULL,
  `SubTotal` decimal(10,2) NULL default '0.00',
  `Discount` decimal(10,2) NULL default '0.00',
  `Packaging` decimal(10,2) NULL default '0.00',
  `Fumigation` decimal(10,2) NULL default '0.00',
  `GrandTotal` decimal(10,2) NULL default '0.00',
  `Currency` int(11) NULL,
  `Rate` decimal(10,2) NULL,
  `Paid` tinyint(1) NULL,
  PRIMARY KEY (`ar_proforma_id`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`pay_invoice` (
  `pay_invoice_id` int(11) NULL auto_increment,
  `ar_invoice_id` int(11) NULL,
  `paid_date` date NULL,
  `amount_paid` decimal(10,2) NULL,
  `currency_id` int(11) NULL,
  `Rate` decimal(10,2) NULL,
  `receiver` int(11) NULL,
  PRIMARY KEY (`pay_invoice_id`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`pay_proforma` (
  `pay_proforma_id` int(11) NULL auto_increment,
  `ar_proforma_id` int(11) NULL,
  `paid_date` date NULL,
  `amount_paid` decimal(10,2) NULL,
  `currency_id` int(11) NULL,
  `Rate` decimal(10,2) NULL,
  `receiver` int(11) NULL,
  PRIMARY KEY (`pay_proforma_id`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`sampleceramic` (
  `sID` int(10) NULL auto_increment,
  `SampleCode` varchar(12) NULL,
  `SampleDescription` varchar(100) NULL,
  `ClientCode` varchar(20) NULL,
  `ClientDescription` varchar(50) NULL,
  `SampleDate` date NULL,
  `TechDraw` varchar(50) NULL,
  `Photo1` varchar(50) NULL,
  `Photo2` varchar(50) NULL,
  `Photo3` varchar(50) NULL,
  `Photo4` varchar(50) NULL,
  `RefID` int(11) NULL,
  `Clay` int(11) NULL,
  `ClayKG` decimal(10,2) NULL default '0.00',
  `ClayNote` text NULL,
  `BuildTech` varchar(50) NULL,
  `BuildTechNote` text NULL,
  `Rim` varchar(30) NULL,
  `Feet` varchar(30) NULL,
  `Casting1` int(11) NULL,
  `Casting2` int(11) NULL,
  `Casting3` int(11) NULL,
  `Casting4` int(11) NULL,
  `CastingNote` text NULL,
  `Estruder1` int(11) NULL,
  `Estruder2` int(11) NULL,
  `Estruder3` int(11) NULL,
  `Estruder4` int(11) NULL,
  `EstruderNote` text NULL,
  `Texture1` int(11) NULL,
  `Texture2` int(11) NULL,
  `Texture3` int(11) NULL,
  `Texture4` int(11) NULL,
  `TextureNote` text NULL,
  `Tools1` int(11) NULL,
  `Tools2` int(11) NULL,
  `Tools3` int(11) NULL,
  `Tools4` int(11) NULL,
  `ToolsNote` text NULL,
  `Engobe1` int(11) NULL,
  `Engobe2` int(11) NULL,
  `Engobe3` int(11) NULL,
  `Engobe4` int(11) NULL,
  `EngobeNote` text NULL,
  `BisqueTemp` varchar(10) NULL default '960',
  `StainOxide1` int(11) NULL,
  `StainOxide2` int(11) NULL,
  `StainOxide3` int(11) NULL,
  `StainOxide4` int(11) NULL,
  `StainOxideNote` text NULL,
  `Glaze1` int(11) NULL,
  `Glaze2` int(11) NULL,
  `Glaze3` int(11) NULL,
  `Glaze4` int(11) NULL,
  `GlazeDensity1` varchar(10) NULL,
  `GlazeDensity2` varchar(10) NULL,
  `GlazeDensity3` varchar(10) NULL,
  `GlazeDensity4` varchar(10) NULL,
  `GlazeNote` text NULL,
  `GlazeTemp` varchar(10) NULL,
  `Firing` varchar(10) NULL default 'Oxidation',
  `FiringNote` text NULL,
  `Width` decimal(10,2) NULL,
  `Height` decimal(10,2) NULL,
  `Length` decimal(10,2) NULL,
  `Diameter` decimal(10,2) NULL,
  `FinalSizeNote` text NULL,
  `DesignMat1` int(11) NULL,
  `DesignMat2` int(11) NULL,
  `DesignMat3` int(11) NULL,
  `DesignMat4` int(11) NULL,
  `DesignMatQty1` int(10) NULL,
  `DesignMatQty2` int(10) NULL,
  `DesignMatQty3` int(10) NULL,
  `DesignMatQty4` int(10) NULL,
  `DesignMatNote` text NULL,
  `History` text NULL,
  `ClayType` int(11) NULL,
  `ClayPreparationMinute` int(11) NULL,
  `WheelMinute` int(11) NULL,
  `SlabMinute` int(11) NULL,
  `CastingMinute` int(11) NULL,
  `FinishingMinute` int(11) NULL,
  `GlazingMinute` int(11) NULL,
  `StandardBisqueLoading` int(11) NULL,
  `StandardGlazeLoading` int(11) NULL,
  `RakuBisqueLoading` int(11) NULL,
  `RakuGlazeLoading` int(11) NULL,
  `MovementMinute` int(11) NULL,
  `PackagingWorkMinute` int(11) NULL,
  `ClayPreparationPPH` int(11) NULL,
  `WheelPPH` int(11) NULL,
  `SlabPPH` int(11) NULL,
  `CastingPPH` int(11) NULL,
  `FinishingPPH` int(11) NULL,
  `GlazingPPH` int(11) NULL,
  `MovementPPH` int(11) NULL,
  `PackagingWorkPPH` int(11) NULL,
  `RealSellingPrice` decimal(10,2) NULL default '0.00',
  `PriceDollar` decimal(10,2) NULL default '0.00',
  `PriceEuro` decimal(10,2) NULL default '0.00',
  `LastUpdate` date NULL default '0000-00-00',
  PRIMARY KEY (`sID`),
  UNIQUE KEY `SampleCode` (`SampleCode`)
) TYPE=MyISAM AUTO_INCREMENT=18;

CREATE TABLE `GayaFusionAll`.`sampleother` (
  `ID` int(10) NULL auto_increment,
  `SampleCode` varchar(12) NULL,
  `Description` varchar(50) NULL,
  `SampleDate` date NULL default '0000-00-00',
  `TechDraw` varchar(50) NULL,
  `Photo1` varchar(50) NULL,
  `Photo2` varchar(50) NULL,
  `Photo3` varchar(50) NULL,
  `Photo4` varchar(50) NULL,
  `DesMat1` int(11) NULL,
  `DesMat2` int(11) NULL,
  `DesMat3` int(11) NULL,
  `DesMat4` int(11) NULL,
  `DesMat5` int(11) NULL,
  `QtyDesMat1` int(11) NULL,
  `QtyDesMat2` int(11) NULL,
  `QtyDesMat3` int(11) NULL,
  `QtyDesMat4` int(11) NULL,
  `QtyDesMat5` int(11) NULL,
  `TotalDesMat1` decimal(10,0) NULL,
  `TotalDesMat2` decimal(10,0) NULL,
  `TotalDesMat3` decimal(10,0) NULL,
  `TotalDesMat4` decimal(10,0) NULL,
  `TotalDesMat5` decimal(10,0) NULL,
  `Supplier1` int(11) NULL,
  `Supplier2` int(11) NULL,
  `Supplier3` int(11) NULL,
  `Supplier4` int(11) NULL,
  `Supplier5` int(11) NULL,
  `Material1` varchar(50) NULL,
  `Material2` varchar(50) NULL,
  `Material3` varchar(50) NULL,
  `Material4` varchar(50) NULL,
  `Material5` varchar(50) NULL,
  `Color1` varchar(50) NULL,
  `Color2` varchar(50) NULL,
  `Color3` varchar(50) NULL,
  `Color4` varchar(50) NULL,
  `Color5` varchar(50) NULL,
  `CostPrice1` decimal(10,0) NULL,
  `CostPrice2` decimal(10,0) NULL,
  `CostPrice3` decimal(10,0) NULL,
  `CostPrice4` decimal(10,0) NULL,
  `CostPrice5` decimal(10,0) NULL,
  `TotalDesMat` double NULL,
  `TotalCostPrice` double NULL,
  `TotalCost` double NULL,
  `Width` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  `Diameter` decimal(10,0) NULL,
  `Volume` decimal(10,2) NULL,
  `Notes` text NULL,
  `PriceRisk` double NULL,
  `RealPrice` double NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SampleCode` (`SampleCode`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`samplepackaging` (
  `ID` int(10) NULL auto_increment,
  `SampleCode` varchar(12) NULL,
  `Description` varchar(50) NULL,
  `SampleDate` date NULL default '0000-00-00',
  `TechDraw` varchar(50) NULL,
  `Photo1` varchar(50) NULL,
  `Photo2` varchar(50) NULL,
  `Photo3` varchar(50) NULL,
  `Photo4` varchar(50) NULL,
  `DesMat1` int(11) NULL,
  `DesMat2` int(11) NULL,
  `DesMat3` int(11) NULL,
  `DesMat4` int(11) NULL,
  `DesMat5` int(11) NULL,
  `QtyDesMat1` int(11) NULL,
  `QtyDesMat2` int(11) NULL,
  `QtyDesMat3` int(11) NULL,
  `QtyDesMat4` int(11) NULL,
  `QtyDesMat5` int(11) NULL,
  `TotalDesMat1` double NULL,
  `TotalDesMat2` double NULL,
  `TotalDesMat3` double NULL,
  `TotalDesMat4` double NULL,
  `TotalDesMat5` double NULL,
  `Supplier1` int(11) NULL,
  `Supplier2` int(11) NULL,
  `Supplier3` int(11) NULL,
  `Supplier4` int(11) NULL,
  `Supplier5` int(11) NULL,
  `Material1` varchar(50) NULL,
  `Material2` varchar(50) NULL,
  `Material3` varchar(50) NULL,
  `Material4` varchar(50) NULL,
  `Material5` varchar(50) NULL,
  `Color1` varchar(50) NULL,
  `Color2` varchar(50) NULL,
  `Color3` varchar(50) NULL,
  `Color4` varchar(50) NULL,
  `Color5` varchar(50) NULL,
  `CostPrice1` decimal(10,0) NULL,
  `CostPrice2` decimal(10,0) NULL,
  `CostPrice3` decimal(10,0) NULL,
  `CostPrice4` decimal(10,0) NULL,
  `CostPrice5` decimal(10,0) NULL,
  `TotalDesMat` double NULL,
  `TotalCostPrice` double NULL,
  `TotalCost` double NULL,
  `InnerQty` int(11) NULL,
  `Width` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  `Diameter` decimal(10,0) NULL,
  `Volume` decimal(10,2) NULL,
  `Weight` decimal(10,2) NULL,
  `Notes` text NULL,
  `PriceRisk` double NULL,
  `RealPrice` double NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SampleCode` (`SampleCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tbladmin` (
  `ID` int(2) NULL auto_increment,
  `UserName` varchar(15) NULL,
  `Passwd` varchar(10) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tbladminist_addressbook` (
  `AddressID` int(11) NULL auto_increment,
  `Company` varchar(100) NULL,
  PRIMARY KEY (`AddressID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_addressbook_contact` (
  `ContactId` int(11) NULL auto_increment,
  `AddressID` int(11) NULL,
  `ContactName` varchar(100) NULL,
  `Email` varchar(50) NULL,
  `Address` text NULL,
  `Phone` varchar(20) NULL,
  `Fax` varchar(20) NULL,
  PRIMARY KEY (`ContactId`),
  KEY `AddressID` (`AddressID`,`ContactName`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_ar_h` (
  `AR_ID` int(11) NULL auto_increment,
  `ClientID` int(11) NULL,
  `CurrencyID` int(11) NULL,
  `DocCode` varchar(11) NULL,
  `SubTotal` decimal(20,2) NULL,
  `Discount` decimal(10,2) NULL default '0.00',
  `PackagingCost` decimal(10,2) NULL,
  `GrandTotal` decimal(20,2) NULL,
  `Deposit` decimal(10,2) NULL,
  `Balance` decimal(10,2) NULL,
  PRIMARY KEY (`AR_ID`),
  KEY `ClientID` (`ClientID`,`DocCode`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_box_d` (
  `Box_D_ID` int(20) NULL auto_increment,
  `Box_H_ID` int(11) NULL,
  `Qty` int(11) NULL,
  `Unit` varchar(15) NULL,
  `CollectID` int(11) NULL,
  `Remarks` text NULL,
  PRIMARY KEY (`Box_D_ID`),
  KEY `ID_Box_H` (`Box_H_ID`,`CollectID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_box_h` (
  `Box_H_ID` int(10) NULL auto_increment,
  `BoxNumber` varchar(30) NULL,
  `PL_H_ID` int(11) NULL,
  `Length` decimal(10,0) NULL,
  `Width` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Weight` decimal(10,0) NULL,
  PRIMARY KEY (`Box_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_client` (
  `ClientID` int(11) NULL auto_increment,
  `ClientCompany` varchar(100) NULL,
  PRIMARY KEY (`ClientID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_currency` (
  `CurrencyID` int(11) NULL auto_increment,
  `CurrencyCode` varchar(3) NULL,
  `Currency` varchar(50) NULL,
  `Rate` decimal(10,2) NULL default '0.00',
  PRIMARY KEY (`CurrencyID`),
  UNIQUE KEY `CurrencyCode` (`CurrencyCode`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_deliveryterm` (
  `DeliveryTermID` int(11) NULL auto_increment,
  `DeliveryTerm` varchar(100) NULL,
  PRIMARY KEY (`DeliveryTermID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_deliverytime` (
  `DeliveryTimeID` int(20) NULL auto_increment,
  `DeliveryTime` varchar(100) NULL,
  PRIMARY KEY (`DeliveryTimeID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_invoice_d` (
  `Invoice_D_ID` int(20) NULL auto_increment,
  `Invoice_H_ID` int(11) NULL,
  `Qty` int(11) NULL,
  `Unit` varchar(15) NULL,
  `CollectID` int(11) NULL,
  `CollectCode` varchar(13) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Total` decimal(10,0) NULL,
  PRIMARY KEY (`Invoice_D_ID`),
  KEY `ID_Invoice_H` (`Invoice_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_invoice_h` (
  `Invoice_H_ID` int(20) NULL auto_increment,
  `InvoiceNo` varchar(100) NULL,
  `InvoiceDate` date NULL default '0000-00-00',
  `ClientOrderRef` varchar(50) NULL,
  `GayaOrderRef` varchar(50) NULL,
  `DeliveryTermID` int(11) NULL,
  `PaymentTermID` int(50) NULL,
  `DueDate` date NULL default '0000-00-00',
  `ClientID` int(11) NULL,
  `Quotation_H_ID` int(11) NULL,
  `Proforma_H_ID` int(11) NULL,
  `AddressID` int(11) NULL,
  `CurrencyID` int(11) NULL,
  `PackagingCost` int(11) NULL,
  `InvoiceContactID` int(11) NULL,
  `DeliveryContactID` int(11) NULL,
  `SubTotal` decimal(10,2) NULL default '0.00',
  `Discount` decimal(10,2) NULL default '0.00',
  `Packaging` decimal(10,2) NULL default '0.00',
  `Fumigation` decimal(10,2) NULL default '0.00',
  `GrandTotal` decimal(10,2) NULL default '0.00',
  `PaymentBankTransferred` decimal(10,0) NULL,
  `Balance` decimal(10,0) NULL,
  `DocMaker` int(11) NULL,
  PRIMARY KEY (`Invoice_H_ID`),
  UNIQUE KEY `InvoiceNo_2` (`InvoiceNo`),
  KEY `ClientOrderRef` (`ClientOrderRef`),
  KEY `GayaOrderRef` (`GayaOrderRef`),
  KEY `InvoiceNo` (`InvoiceNo`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_invoice_sh` (
  `Invoice_SH_ID` int(11) NULL auto_increment,
  `InvoiceNo` varchar(16) NULL,
  `ClientID` int(11) NULL,
  `Quotation_H_ID` int(11) NULL,
  `Proforma_H_ID` int(11) NULL,
  `AddressID` int(11) NULL,
  PRIMARY KEY (`Invoice_SH_ID`),
  KEY `InvoiceNo` (`InvoiceNo`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_packinglist_d` (
  `PL_D_ID` int(11) NULL auto_increment,
  `PL_H_ID` int(11) NULL,
  `Box_H_ID` int(11) NULL,
  PRIMARY KEY (`PL_D_ID`),
  KEY `ID_PackingList_H` (`PL_H_ID`,`Box_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_packinglist_h` (
  `PL_H_ID` int(11) NULL auto_increment,
  `PLNo` varchar(15) NULL,
  `PLDate` date NULL default '0000-00-00',
  `Invoice_H_ID` int(11) NULL,
  `AddressID` int(11) NULL,
  `InvoiceContactID` int(11) NULL,
  `DeliveryContactID` int(11) NULL,
  `OrderRef` varchar(200) NULL,
  PRIMARY KEY (`PL_H_ID`),
  KEY `PackListNo` (`PLNo`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_payment` (
  `PaymentId` int(11) NULL,
  `AR_ID` int(11) NULL,
  `DocCode` varchar(12) NULL,
  `PaymentType` int(11) NULL,
  `DatePaid` date NULL default '0000-00-00',
  `CurencyConversion` decimal(10,2) NULL,
  `AmountPaid` decimal(10,2) NULL,
  PRIMARY KEY (`PaymentId`),
  KEY `AR_ID` (`AR_ID`,`DocCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tbladminist_paymentterm` (
  `PaymentTermID` int(8) NULL auto_increment,
  `PaymentTerm` varchar(100) NULL,
  PRIMARY KEY (`PaymentTermID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_paymenttype` (
  `PaymentTypeID` tinyint(4) NULL auto_increment,
  `PaymentType` varchar(15) NULL,
  PRIMARY KEY (`PaymentTypeID`),
  KEY `PaymentType` (`PaymentType`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_pol_d` (
  `POL_D_ID` int(11) NULL auto_increment,
  `POL_H_ID` int(11) NULL,
  `CollectID` int(11) NULL,
  `Qty` int(11) NULL,
  PRIMARY KEY (`POL_D_ID`),
  KEY `POL_H_ID` (`POL_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_pol_h` (
  `POL_H_ID` int(11) NULL auto_increment,
  `POLNo` varchar(11) NULL,
  `Proforma_H_ID` int(11) NULL,
  `ClientID` int(11) NULL,
  `ClientOrderRef` varchar(30) NULL,
  `POLDate` date NULL default '0000-00-00',
  `DeliveryTimeID` int(11) NULL,
  PRIMARY KEY (`POL_H_ID`),
  KEY `Proforma_H_ID` (`Proforma_H_ID`),
  KEY `POLNo` (`POLNo`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_prodorderlist_proforma` (
  `Prof_Pol_ID` int(11) NULL auto_increment,
  `ProformaID` int(11) NULL,
  `ProdOrderListID` int(11) NULL,
  PRIMARY KEY (`Prof_Pol_ID`),
  KEY `ProformaID` (`ProformaID`,`ProdOrderListID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_proforma_d` (
  `Proforma_D_ID` int(20) NULL auto_increment,
  `Proforma_H_ID` int(11) NULL,
  `CollectID` int(11) NULL,
  `CollectCode` varchar(13) NULL,
  `Qty` int(11) NULL,
  `Unit` varchar(15) NULL,
  `Type` int(11) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Total` decimal(10,0) NULL,
  PRIMARY KEY (`Proforma_D_ID`),
  KEY `Proforma_H_ID` (`Proforma_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_proforma_h` (
  `Proforma_H_ID` int(11) NULL auto_increment,
  `ProformaNo` varchar(11) NULL,
  `Rev` varchar(10) NULL,
  `Validity` varchar(15) NULL,
  `ProformaDate` date NULL,
  `ClientOrderRef` varchar(50) NULL,
  `ClientID` int(11) NULL,
  `AddressID` int(11) NULL,
  `ContactID` int(11) NULL,
  `PackagingCost` int(11) NULL,
  `DeliveryTermID` int(11) NULL,
  `DeliveryTimeID` int(11) NULL,
  `PaymentTermID` int(11) NULL,
  `SpecialInstruction` text NULL,
  `PreviewDPDate` date NULL default '0000-00-00',
  `Quotation_H_ID` int(11) NULL,
  `SubTotal` decimal(10,2) NULL default '0.00',
  `Discount` decimal(10,2) NULL default '0.00',
  `Packaging` decimal(10,2) NULL default '0.00',
  `Fumigation` decimal(10,2) NULL default '0.00',
  `GrandTotal` decimal(10,2) NULL default '0.00',
  `Currency` int(11) NULL,
  `DocMaker` int(11) NULL,
  PRIMARY KEY (`Proforma_H_ID`),
  KEY `ProformaNo` (`ProformaNo`,`ClientOrderRef`),
  KEY `Quotation_H_ID` (`Quotation_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tbladminist_proformarev_d` (
  `ProformaRev_D_ID` int(11) NULL auto_increment,
  `Proforma_D_ID` int(20) NULL,
  `Proforma_H_ID` int(11) NULL,
  `CollectID` int(11) NULL,
  `CollectCode` varchar(13) NULL,
  `Qty` int(11) NULL,
  `Unit` varchar(15) NULL,
  `Type` int(11) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Total` decimal(10,0) NULL,
  PRIMARY KEY (`ProformaRev_D_ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_proformarev_h` (
  `ProformaRev_H_ID` int(11) NULL auto_increment,
  `Proforma_H_ID` int(11) NULL,
  `ProformaNo` varchar(11) NULL,
  `Rev` varchar(10) NULL,
  `Validity` varchar(15) NULL,
  `ProformaDate` date NULL,
  `ClientOrderRef` varchar(50) NULL,
  `ClientID` int(11) NULL,
  `AddressID` int(11) NULL,
  `ContactID` int(11) NULL,
  `PackagingCost` decimal(10,0) NULL,
  `DeliveryTermID` int(11) NULL,
  `DeliveryTimeID` int(11) NULL,
  `PaymentTermID` int(11) NULL,
  `SpecialInstruction` text NULL,
  `PreviewDPDate` date NULL default '0000-00-00',
  `Quotation_H_ID` int(11) NULL,
  PRIMARY KEY (`ProformaRev_H_ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotation_d` (
  `Quotation_D_ID` int(20) NULL auto_increment,
  `Quotation_H_ID` int(11) NULL,
  `RndCode` varchar(12) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Remark` text NULL,
  PRIMARY KEY (`Quotation_D_ID`),
  KEY `ID_Quotation_H` (`Quotation_H_ID`,`RndCode`)
) TYPE=MyISAM AUTO_INCREMENT=5;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotation_h` (
  `Quotation_H_ID` int(20) NULL auto_increment,
  `QuotationNo` varchar(11) NULL,
  `Rev` varchar(10) NULL,
  `Validity` varchar(15) NULL,
  `QuotationDate` date NULL default '0000-00-00',
  `ClientOrderRef` varchar(50) NULL,
  `ClientID` int(11) NULL,
  `AddressID` int(11) NULL,
  `ContactID` int(11) NULL,
  `PackagingCost` float(10,0) NULL,
  `DeliveryTermID` int(11) NULL,
  `DeliveryTimeID` int(11) NULL,
  `PaymentTermID` int(11) NULL,
  `SpecialInstruction` text NULL,
  `Currency` int(11) NULL,
  `DocMaker` int(11) NULL,
  PRIMARY KEY (`Quotation_H_ID`),
  KEY `QuotationNo` (`QuotationNo`,`ClientOrderRef`),
  KEY `ClientID` (`ClientID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotation_proforma` (
  `ID` int(11) NULL auto_increment,
  `QuotationID` int(11) NULL,
  `ProformaID` int(11) NULL,
  PRIMARY KEY (`ID`),
  KEY `ProformaID` (`ProformaID`,`QuotationID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotationrev_d` (
  `QuotationRev_D_ID` int(11) NULL auto_increment,
  `QuotationRev_H_ID` int(11) NULL,
  `Quotation_D_ID` int(20) NULL,
  `Quotation_H_ID` int(11) NULL,
  `RndCode` varchar(12) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Remark` text NULL,
  PRIMARY KEY (`QuotationRev_D_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotationrev_h` (
  `QuotationRev_H_ID` int(11) NULL auto_increment,
  `Quotation_H_ID` int(20) NULL,
  `QuotationNo` varchar(11) NULL,
  `Rev` varchar(10) NULL,
  `Validity` varchar(15) NULL,
  `QuotationDate` date NULL default '0000-00-00',
  `ClientOrderRef` varchar(50) NULL,
  `ClientID` int(11) NULL,
  `AddressID` int(11) NULL,
  `ContactID` int(11) NULL,
  `PackagingCost` float(10,0) NULL,
  `DeliveryTermID` int(11) NULL,
  `DeliveryTimeID` int(11) NULL,
  `PaymentTermID` int(11) NULL,
  `SpecialInstruction` text NULL,
  PRIMARY KEY (`QuotationRev_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tblcasting` (
  `ID` int(11) NULL auto_increment,
  `CastingCode` varchar(10) NULL,
  `CastingDescription` varchar(100) NULL,
  `CastingDate` date NULL default '0000-00-00',
  `CastingTechDraw` varchar(50) NULL,
  `CastingPhoto1` varchar(50) NULL,
  `CastingPhoto2` varchar(50) NULL,
  `CastingPhoto3` varchar(50) NULL,
  `CastingPhoto4` varchar(50) NULL,
  `CastingNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `CastingCode` (`CastingCode`)
) TYPE=MyISAM AUTO_INCREMENT=28;

CREATE TABLE `GayaFusionAll`.`tblclay` (
  `ID` int(11) NULL auto_increment,
  `ClayCode` varchar(10) NULL,
  `ClayDescription` varchar(100) NULL,
  `ClayDate` date NULL default '0000-00-00',
  `ClayTechDraw` varchar(50) NULL,
  `ClayPhoto1` varchar(50) NULL,
  `ClayPhoto2` varchar(50) NULL,
  `ClayPhoto3` varchar(50) NULL,
  `ClayPhoto4` varchar(50) NULL,
  `ClayNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ClayCode` (`ClayCode`)
) TYPE=MyISAM AUTO_INCREMENT=6;

CREATE TABLE `GayaFusionAll`.`tblcollect_category` (
  `CategoryCode` varchar(2) NULL,
  `CategoryName` varchar(50) NULL,
  PRIMARY KEY (`CategoryCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_color` (
  `ColorCode` varchar(2) NULL,
  `ColorName` varchar(100) NULL,
  PRIMARY KEY (`ColorCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_design` (
  `DesignCode` varchar(2) NULL,
  `DesignName` varchar(100) NULL,
  PRIMARY KEY (`DesignCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_group_det` (
  `ID` int(11) NULL auto_increment,
  `Group_H_ID` int(11) NULL,
  `CollectCode` varchar(15) NULL,
  `Qty` int(11) NULL,
  PRIMARY KEY (`ID`),
  KEY `Group_H_ID` (`Group_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=5;

CREATE TABLE `GayaFusionAll`.`tblcollect_group_h` (
  `Group_H_ID` int(11) NULL auto_increment,
  `GroupCode` varchar(12) NULL,
  `GroupDate` date NULL default '0000-00-00',
  `DesignCode` varchar(2) NULL,
  `GroupDescription` varchar(255) NULL,
  `ClientCode` varchar(50) NULL,
  `ClientDesc` varchar(255) NULL,
  `GroupPhoto` varchar(50) NULL,
  `Diameter` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Weight` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  PRIMARY KEY (`Group_H_ID`),
  UNIQUE KEY `Code` (`GroupCode`)
) TYPE=MyISAM AUTO_INCREMENT=4;

CREATE TABLE `GayaFusionAll`.`tblcollect_master` (
  `ID` int(11) NULL auto_increment,
  `CollectCode` varchar(15) NULL,
  `DesignCode` varchar(2) NULL,
  `NameCode` varchar(2) NULL,
  `CategoryCode` varchar(2) NULL,
  `SizeCode` varchar(2) NULL,
  `TextureCode` varchar(2) NULL,
  `ColorCode` varchar(2) NULL,
  `MaterialCode` varchar(2) NULL,
  `ClientCode` varchar(20) NULL,
  `ClientDescription` varchar(50) NULL,
  `CollectDate` date NULL default '0000-00-00',
  `TechDraw` varchar(50) NULL,
  `Photo1` varchar(50) NULL,
  `Photo2` varchar(50) NULL,
  `Photo3` varchar(50) NULL,
  `Photo4` varchar(50) NULL,
  `RefID` int(11) NULL,
  `Clay` int(11) NULL,
  `ClayKG` decimal(10,2) NULL default '0.00',
  `ClayNote` text NULL,
  `BuildTech` varchar(50) NULL,
  `BuildTechNote` text NULL,
  `Rim` varchar(30) NULL,
  `Feet` varchar(30) NULL,
  `Casting1` int(11) NULL,
  `Casting2` int(11) NULL,
  `Casting3` int(11) NULL,
  `Casting4` int(11) NULL,
  `CastingNote` text NULL,
  `Estruder1` int(11) NULL,
  `Estruder2` int(11) NULL,
  `Estruder3` int(11) NULL,
  `Estruder4` int(11) NULL,
  `EstruderNote` text NULL,
  `Texture1` int(11) NULL,
  `Texture2` int(11) NULL,
  `Texture3` int(11) NULL,
  `Texture4` int(11) NULL,
  `TextureNote` text NULL,
  `Tools1` int(11) NULL,
  `Tools2` int(11) NULL,
  `Tools3` int(11) NULL,
  `Tools4` int(11) NULL,
  `ToolsNote` text NULL,
  `Engobe1` int(11) NULL,
  `Engobe2` int(11) NULL,
  `Engobe3` int(11) NULL,
  `Engobe4` int(11) NULL,
  `EngobeNote` text NULL,
  `BisqueTemp` varchar(10) NULL default '960',
  `StainOxide1` int(11) NULL,
  `StainOxide2` int(11) NULL,
  `StainOxide3` int(11) NULL,
  `StainOxide4` int(11) NULL,
  `StainOxideNote` text NULL,
  `Glaze1` int(11) NULL,
  `Glaze2` int(11) NULL,
  `Glaze3` int(11) NULL,
  `Glaze4` int(11) NULL,
  `GlazeDensity1` varchar(10) NULL,
  `GlazeDensity2` varchar(10) NULL,
  `GlazeDensity3` varchar(10) NULL,
  `GlazeDensity4` varchar(10) NULL,
  `GlazeNote` text NULL,
  `GlazeTemp` varchar(10) NULL,
  `Firing` varchar(10) NULL,
  `FiringNote` text NULL,
  `Width` decimal(10,2) NULL,
  `Height` decimal(10,2) NULL,
  `Length` decimal(10,2) NULL,
  `Diameter` decimal(10,2) NULL,
  `SampCeramicVolume` decimal(10,2) NULL default '0.00',
  `FinalSizeNote` text NULL,
  `DesignMat1` int(11) NULL,
  `DesignMat2` int(11) NULL,
  `DesignMat3` int(11) NULL,
  `DesignMat4` int(11) NULL,
  `DesignMatQty1` int(10) NULL,
  `DesignMatQty2` int(10) NULL,
  `DesignMatQty3` int(10) NULL,
  `DesignMatQty4` int(10) NULL,
  `DesignMatNote` text NULL,
  `History` text NULL,
  `ClayType` varchar(50) NULL,
  `ClayPreparationMinute` int(11) NULL,
  `WheelMinute` int(11) NULL,
  `SlabMinute` int(11) NULL,
  `CastingMinute` int(11) NULL,
  `FinishingMinute` int(11) NULL,
  `GlazingMinute` int(11) NULL,
  `StandardBisqueLoading` int(11) NULL,
  `StandardGlazeLoading` int(11) NULL,
  `RakuBisqueLoading` int(11) NULL,
  `RakuGlazeLoading` int(11) NULL,
  `MovementMinute` int(11) NULL,
  `PackagingWorkMinute` int(11) NULL,
  `ClayPreparationPPH` int(11) NULL,
  `WheelPPH` int(11) NULL,
  `SlabPPH` int(11) NULL,
  `CastingPPH` int(11) NULL,
  `FinishingPPH` int(11) NULL,
  `GlazingPPH` int(11) NULL,
  `MovementPPH` int(11) NULL,
  `PackagingWorkPPH` int(11) NULL,
  `RealSellingPrice` double NULL,
  `LastUpdate` date NULL default '0000-00-00',
  `PriceDollar` decimal(10,2) NULL default '0.00',
  `PriceEuro` decimal(10,2) NULL default '0.00',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `CollectCode` (`CollectCode`)
) TYPE=MyISAM AUTO_INCREMENT=59;

CREATE TABLE `GayaFusionAll`.`tblcollect_material` (
  `MaterialCode` varchar(2) NULL,
  `MaterialName` varchar(50) NULL,
  PRIMARY KEY (`MaterialCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_name` (
  `NameCode` varchar(2) NULL,
  `NameDesc` varchar(50) NULL,
  PRIMARY KEY (`NameCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_size` (
  `SizeCode` varchar(2) NULL,
  `SizeName` varchar(50) NULL,
  PRIMARY KEY (`SizeCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_texture` (
  `TextureCode` varchar(2) NULL,
  `TextureName` varchar(50) NULL,
  PRIMARY KEY (`TextureCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcosting_casting` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_clay` (
  `ID` int(11) NULL auto_increment,
  `ClayType` varchar(50) NULL,
  `PricePerKG` double NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ClayType` (`ClayType`)
) TYPE=MyISAM AUTO_INCREMENT=4;

CREATE TABLE `GayaFusionAll`.`tblcosting_claypreparation` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_costbudgetpreview` (
  `ID` int(11) NULL auto_increment,
  `BudgetYear` int(11) NULL,
  `CostBudgetAmmount` double NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_finishing` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_glazing` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_master` (
  `ID` int(1) NULL,
  `ClayPreparationCPM` int(11) NULL,
  `ClayPreparationPPH` int(11) NULL,
  `WheelCPM` int(11) NULL,
  `WheelPPH` int(11) NULL,
  `SlabCPM` int(11) NULL,
  `SlabPPH` int(11) NULL,
  `CastingCPM` int(11) NULL,
  `CastingPPH` int(11) NULL,
  `FinishingCPM` int(11) NULL,
  `FinishingPPH` int(11) NULL,
  `GlazingCPM` int(11) NULL,
  `GlazingPPH` int(11) NULL,
  `MovementCPM` int(11) NULL,
  `MovementPPH` int(11) NULL,
  `PackagingWorkCPM` int(11) NULL,
  `PackagingWorkPPH` int(11) NULL,
  `StandardBisqueCPM` int(11) NULL,
  `StandardBisquePPH` int(11) NULL,
  `StandardGlazeCPM` int(11) NULL,
  `StandardGlazePPH` int(11) NULL,
  `RakuBisqueCPM` int(11) NULL,
  `RakuBisquePPH` int(11) NULL,
  `RakuGlazeCPM` int(11) NULL,
  `RakuGlazePPH` int(11) NULL,
  `ProductiveHourDay` decimal(10,2) NULL default '0.00',
  `ProductiveHourMonth` int(11) NULL,
  `ProductiveHourYear` int(11) NULL,
  `TrowWorker` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcosting_movement` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_packagingwork` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_productivehours` (
  `ID` int(11) NULL auto_increment,
  `Day` decimal(10,2) NULL default '0.00',
  `Month` int(11) NULL,
  `Year` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_rakubisque` (
  `ID` int(11) NULL auto_increment,
  `PricePerFiring` decimal(10,2) NULL default '0.00',
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tblcosting_rakuglaze` (
  `ID` int(11) NULL auto_increment,
  `PricePerFiring` decimal(10,2) NULL default '0.00',
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_slab` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_standardbisque` (
  `ID` int(11) NULL auto_increment,
  `PricePerFiring` decimal(10,2) NULL default '0.00',
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_standardglaze` (
  `ID` int(1) NULL auto_increment,
  `PricePerFiring` decimal(10,2) NULL default '0.00',
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_trowworker` (
  `ID` int(11) NULL auto_increment,
  `TrowWorker` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_wheel` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tbldesignmat` (
  `DesignMatID` int(11) NULL auto_increment,
  `DesignMatCode` varchar(10) NULL,
  `DesignMatDescription` varchar(100) NULL,
  `DesignMatTechDraw` varchar(50) NULL,
  `DesignMatPhoto1` varchar(50) NULL,
  `DesignMatPhoto2` varchar(50) NULL,
  `DesignMatPhoto3` varchar(50) NULL,
  `DesignMatPhoto4` varchar(50) NULL,
  `DesignMatSupplier` int(11) NULL,
  `DesignMatUnit` varchar(2) NULL,
  `DesignMatUnitPrice` decimal(10,0) NULL,
  `DesignMatNotes` text NULL,
  `DesignMatDate` date NULL default '0000-00-00',
  PRIMARY KEY (`DesignMatID`),
  UNIQUE KEY `DesignMatCode` (`DesignMatCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblengobe` (
  `ID` int(11) NULL auto_increment,
  `EngobeCode` varchar(10) NULL,
  `EngobeDescription` varchar(100) NULL,
  `EngobeDate` date NULL default '0000-00-00',
  `EngobeTechDraw` varchar(50) NULL,
  `EngobePhoto1` varchar(50) NULL,
  `EngobePhoto2` varchar(50) NULL,
  `EngobePhoto3` varchar(50) NULL,
  `EngobePhoto4` varchar(50) NULL,
  `EngobeNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `EngobeCode` (`EngobeCode`)
) TYPE=MyISAM AUTO_INCREMENT=9;

CREATE TABLE `GayaFusionAll`.`tblestruder` (
  `ID` int(11) NULL auto_increment,
  `EstruderCode` varchar(10) NULL,
  `EstruderDescription` varchar(100) NULL,
  `EstruderDate` date NULL default '0000-00-00',
  `EstruderTechDraw` varchar(50) NULL,
  `EstruderPhoto1` varchar(50) NULL,
  `EstruderPhoto2` varchar(50) NULL,
  `EstruderPhoto3` varchar(50) NULL,
  `EstruderPhoto4` varchar(50) NULL,
  `EstruderNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `EstruderCode` (`EstruderCode`)
) TYPE=MyISAM AUTO_INCREMENT=25;

CREATE TABLE `GayaFusionAll`.`tblfiringplan` (
  `ID` int(11) NULL auto_increment,
  `FiringPlanCode` varchar(10) NULL,
  `FiringPlanDescription` varchar(100) NULL,
  `FiringPlanDate` date NULL default '0000-00-00',
  `FiringPlanTechDraw` varchar(50) NULL,
  `FiringPlanPhoto1` varchar(50) NULL,
  `FiringPlanPhoto2` varchar(50) NULL,
  `FiringPlanPhoto3` varchar(50) NULL,
  `FiringPlanPhoto4` varchar(50) NULL,
  `FiringPlanNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `FiringPlanCode` (`FiringPlanCode`)
) TYPE=MyISAM AUTO_INCREMENT=4;

CREATE TABLE `GayaFusionAll`.`tblglaze` (
  `ID` int(11) NULL auto_increment,
  `GlazeCode` varchar(10) NULL,
  `GlazeDescription` varchar(100) NULL,
  `GlazeDate` date NULL default '0000-00-00',
  `GlazeTechDraw` varchar(50) NULL,
  `GlazePhoto1` varchar(50) NULL,
  `GlazePhoto2` varchar(50) NULL,
  `GlazePhoto3` varchar(50) NULL,
  `GlazePhoto4` varchar(50) NULL,
  `GlazeNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `GlazeCode` (`GlazeCode`)
) TYPE=MyISAM AUTO_INCREMENT=38;

CREATE TABLE `GayaFusionAll`.`tblreference` (
  `ID` int(11) NULL auto_increment,
  `RefCode` varchar(20) NULL,
  `sID` int(11) NULL,
  `CollectID` int(11) NULL,
  `RefNote` text NULL,
  PRIMARY KEY (`ID`),
  KEY `sID` (`sID`),
  KEY `CollectID` (`CollectID`)
) TYPE=MyISAM AUTO_INCREMENT=14;

CREATE TABLE `GayaFusionAll`.`tblstainoxide` (
  `ID` int(11) NULL auto_increment,
  `StainOxideCode` varchar(10) NULL,
  `StainOxideDescription` varchar(100) NULL,
  `StainOxideDate` date NULL default '0000-00-00',
  `StainOxideTechDraw` varchar(50) NULL,
  `StainOxidePhoto1` varchar(50) NULL,
  `StainOxidePhoto2` varchar(50) NULL,
  `StainOxidePhoto3` varchar(50) NULL,
  `StainOxidePhoto4` varchar(50) NULL,
  `StainOxideNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `stainoxideCode` (`StainOxideCode`)
) TYPE=MyISAM AUTO_INCREMENT=16;

CREATE TABLE `GayaFusionAll`.`tblsupplier` (
  `ID` int(11) NULL auto_increment,
  `SupCode` varchar(15) NULL,
  `SupCompany` varchar(100) NULL,
  `SupContact` varchar(100) NULL,
  `SupAddress` varchar(200) NULL,
  `SupHP` varchar(15) NULL,
  `SupOffice` varchar(100) NULL,
  `SupFax` varchar(20) NULL,
  `SupEmail` varchar(50) NULL,
  `SupItems` varchar(100) NULL,
  `SupOtherInfo` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SupCode` (`SupCode`)
) TYPE=MyISAM AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tbltexture` (
  `ID` int(11) NULL auto_increment,
  `TextureCode` varchar(10) NULL,
  `TextureDescription` varchar(100) NULL,
  `TextureDate` date NULL default '0000-00-00',
  `TextureTechDraw` varchar(50) NULL,
  `TexturePhoto1` varchar(50) NULL,
  `TexturePhoto2` varchar(50) NULL,
  `TexturePhoto3` varchar(50) NULL,
  `TexturePhoto4` varchar(50) NULL,
  `TextureNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `TextureCode` (`TextureCode`)
) TYPE=MyISAM AUTO_INCREMENT=10;

CREATE TABLE `GayaFusionAll`.`tbltools` (
  `ID` int(11) NULL auto_increment,
  `ToolsCode` varchar(10) NULL,
  `ToolsDescription` varchar(100) NULL,
  `ToolsDate` date NULL default '0000-00-00',
  `ToolsTechDraw` varchar(50) NULL,
  `ToolsPhoto1` varchar(50) NULL,
  `ToolsPhoto2` varchar(50) NULL,
  `ToolsPhoto3` varchar(50) NULL,
  `ToolsPhoto4` varchar(50) NULL,
  `ToolsNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ToolsCode` (`ToolsCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblunit` (
  `UnitID` varchar(2) NULL,
  `UnitValue` varchar(30) NULL,
  PRIMARY KEY (`UnitID`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tbluser` (
  `id` int(11) NULL auto_increment,
  `UserName` varchar(15) NULL,
  `LastName` varchar(50) NULL,
  `FirstName` varchar(30) NULL,
  `Password` varchar(50) NULL,
  `Type` varchar(15) NULL,
  PRIMARY KEY (`id`)
) TYPE=MyISAM AUTO_INCREMENT=18;


# dumping data for GayaFusionAll.ar_invoice
INSERT INTO `ar_invoice` (`ar_invoice_id`, `proforma_h_id`, `invoice_h_id`, `ClientID`, `due_date`, `SubTotal`, `Discount`, `Packaging`, `Fumigation`, `GrandTotal`, `Currency`, `Rate`, `Paid`) VALUES (1, 1, 1, 1, '1900-01-31', 0.00, 0.00, 0.00, 0.00, 0.00, 2, 15000.00, 0);
INSERT INTO `ar_invoice` (`ar_invoice_id`, `proforma_h_id`, `invoice_h_id`, `ClientID`, `due_date`, `SubTotal`, `Discount`, `Packaging`, `Fumigation`, `GrandTotal`, `Currency`, `Rate`, `Paid`) VALUES (2, 1, 2, 1, '1900-01-31', 375.00, 0.00, 37.50, 50.00, 462.50, 2, 15000.00, 0);








# dumping data for GayaFusionAll.sampleceramic
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (1, 'SC08-001', 'AMAN HANGZHOU - SAMPLE AMENITY BOTTLE - SMOOTH', NULL, NULL, '2008-11-08', '200811100600180.amenity bottle.jpg', '200811100729100.amenity_smooth_200.jpg', NULL, NULL, NULL, NULL, 1, 0.70, NULL, 'TROWING', NULL, 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, 'USE WAX TO COVER NECK UNTIL RIM PART, ONLY ON THE OUTSIDE PART. THEN DIPPING IN TRANSPARENT GLAZE. \r\n\r\nGUNAKAN LILIN PADA BAGIAN LEHER HINGGA BAGIAN ATAS (RIM), HANYA PADA BAGIAN LUAR SAJA. LALU DIPPING DI GLAZE TRANSPARENT.', '1250', 'Oxidation', 'STANDART FIRING.', NULL, 10.00, NULL, 8.50, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 6, 0, 0, 10, 5, 700, 350, 0, 0, 5, 5, 60, 10, 0, 0, 6, 12, 12, 12, 0.00, 13.00, 0.00, '2008-12-01');
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (2, 'SC08-004', 'AMAN HANGZHOU - SAMPLE BATH SALT CONTAINER - MEDIUM HAND TROWED', NULL, NULL, '2008-11-08', '200811100613290.bath salt.jpg', '200811100613290.bath salth_med hand trowed_200.jpg', NULL, NULL, NULL, NULL, 1, 1.20, NULL, 'TROWING', NULL, 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 7, NULL, NULL, NULL, 'MAKES TEXTURE WHILE THE PIECES STILL MOVING. MOVE THE TOOLS FROM BOTTOM TILL TOP AND OPPOSITE.\r\n\r\nBUAT TEKSTUR SAAT BARANG MASIH DIPUTAR. GUNAKAN ALAT DARI BAWAH KE ATAS DAN SEBALIKNYA. ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, 'USE WAX TO COVER NECK UNTIL RIM PART, ONLY ON THE OUTSIDE PART. THEN DIPPING IN TRANSPARENT GLAZE.', '1250', 'Oxidation', NULL, NULL, 10.00, NULL, 12.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 13.00, 0.00, '2008-12-01');
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (3, 'SC08-007', 'AMAN HANGZHOU - SAMPLE BATH TRAY', NULL, NULL, '2008-11-08', '200811100616320.bath tray.jpg', '200811100616320.bath tray_200.jpg', NULL, NULL, NULL, NULL, 1, 2.00, NULL, 'TROWING', 'BE CAREFUL ON TRIMMING PROCESS. KEEP SAME THICKNESS.', 'FLAT', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, 'WAX ALMOST ALL THE RIM AND BOTTOM PART, THEN DIPPING IN GLAZE TRANSPARENT.', '1250', 'Oxidation', 'STANDART FIRING', NULL, 0.50, NULL, 29.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 19.00, 0.00, '2008-12-01');
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (4, 'SC08-008', 'AMAN HANGZHOU - SAMPLE FLOWER DISH', NULL, NULL, '2008-11-06', '200811100619250.flower vase.jpg', '200811100619250.flower vase_200.jpg', NULL, NULL, NULL, NULL, 1, 0.40, NULL, 'TROWING', 'TROWING THICK', 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, NULL, NULL, NULL, 'MAKE DEEP GENTENG TEXTURE USING PROPER TOOLS BEFORE TRIMMING WHEN THE CLAY STILL WET.\r\n\r\n', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, NULL, '1250', 'Oxidation', 'STANDART FIRING', NULL, 5.00, NULL, 8.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 10.00, 0.00, '2008-12-01');
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (5, 'SC08-009', 'AMAN HANGZHOU - SAMPLE COTTON BUD/WOOL CONTAINER - MEDIUM HAND TROWED', NULL, NULL, '2008-11-10', '200811100552530.cotton bud&wool.jpg', '200811100605050.cotton_med hand trowed_200.jpg', NULL, NULL, NULL, NULL, 1, 0.70, NULL, 'TROWING', NULL, 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 7, NULL, NULL, NULL, 'KEEP MEDIUM HAND-TROWED TEXTURE ON THE PIECES.', NULL, NULL, NULL, NULL, 'MAKES TEXTURE WHILE THE PIECES STILL MOVING. MOVE THE TOOLS FROM BOTTOM TILL TOP AND OPPOSITE.\r\n\r\nBUAT TEKSTUR SAAT BARANG MASIH DIPUTAR. GUNAKAN ALAT DARI BAWAH KE ATAS DAN SEBALIKNYA. ', NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, 'USE WAX TO COVER NECK UNTIL RIM PART, ONLY ON THE OUTSIDE PART. THEN DIPPING IN TRANSPARENT GLAZE.\r\n\r\nGUNAKAN LILIN PADA BAGIAN LEHER SAMPAI RIM, LALU DIPPING DI GLAZE TRANSPARENT. ', '1250', 'Oxidation', NULL, NULL, 9.50, NULL, 9.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 12.00, 0.00, '2008-12-01');
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (6, 'SC08-002', 'AMAN HANGZHOU - SAMPLE AMENITY BOTTLE - MED HAND TROWED', NULL, NULL, '2008-11-10', '200811100648070.amenity bottle.jpg', '200811100648070.amenity_med hand trowed_200.jpg', NULL, NULL, NULL, NULL, 1, 0.70, NULL, 'TROWING', NULL, 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 7, NULL, NULL, NULL, 'KEEP MEDIUM HAND TROWED TEXTURE ON THE PIECES.', NULL, NULL, NULL, NULL, 'MAKES TEXTURE WHILE THE PIECES STILL MOVING. MOVE THE TOOLS FROM BOTTOM TILL TOP AND OPPOSITE.\r\n\r\nBUAT TEKSTUR SAAT BARANG MASIH DIPUTAR. GUNAKAN ALAT DARI BAWAH KE ATAS DAN SEBALIKNYA.', NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, 'USE WAX TO COVER NECK UNTIL RIM PART, ONLY ON THE OUTSIDE PART. THEN DIPPING IN TRANSPARENT GLAZE.\r\n\r\nGUNAKAN LILIN PADA BAGIAN LEHER SAMPAI RIM, LALU DIPPING DI GLAZE TRANSPARENT.', '1250', 'Oxidation', NULL, NULL, 10.00, NULL, 8.50, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 13.00, 0.00, '2008-12-01');
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (7, 'SC08-003', 'AMAN HANGZHOU - SAMPLE AMENITY BOTTLE - ROUGH HAND TROWED', NULL, NULL, '2008-11-10', '200811100750500.amenity bottle.jpg', '200811100750500.amenity_rough hand trowed_200.jpg', NULL, NULL, NULL, NULL, 1, 0.70, NULL, 'TROWING', 'NOT PERFECT BODY SHAPE.\r\n\r\nTROWING BENTUK TIDAK SEMPURNA, SEDIKIT GOYANG.', 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 8, NULL, NULL, NULL, 'MAKE TEXTURES DURING TRIMMING, TO KEEP HAND TROWED FEELING.\r\n\r\nBUAT TEKSTUR AGAK DALAM SAAT, TRIMMING.', NULL, NULL, NULL, NULL, 'USE PROPER TOOLS TO MAKE TEXTURE ,WHILE THE PIECES STILL MOVING. MAKE DEEP TEXTURE.', NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, 'WAX NECK PART UNTIL THE TOP (RIM), THEN DIPPING IN GLAZE TRANSPARENT.\r\n\r\nGUNAKAN LILIN PADA BAGIAN DARI BATAS BAWAH LEHER SAMPAI RIM, LALU DIPPING DI GLAZE TRANSPARENT.', '1250', 'Oxidation', NULL, NULL, 10.00, NULL, 8.50, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 12.00, 0.00, '2008-12-01');
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (8, 'SC08-005', 'AMAN HANGZHOU - SAMPLE BATH SALT CONTAINER - SMOOTH', NULL, NULL, '2008-11-10', '200811100819590.bath salt.jpg', '200811100820560.bath salth_smooth_200.jpg', NULL, NULL, NULL, NULL, 1, 1.20, NULL, 'TROWING', NULL, 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, 'USE WAX TO COVER NECK UNTIL RIM PART, ONLY ON THE OUTSIDE PART. THEN DIPPING IN TRANSPARENT GLAZE.\r\n\r\nGUNAKAN LILIN PADA BAGIAN LEHER SAMPAI RIM, LALU DIPPING DI GLAZE TRANSPARENT. ', '1250', 'Oxidation', NULL, NULL, 10.00, NULL, 12.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 15.00, 0.00, '2008-12-01');
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (9, 'SC08-006', 'AMAN HANGZHOU - SAMPLE BATH SALT CONTAINER - ROUGH HAND TROWED', NULL, NULL, '2008-11-10', '200811100824230.bath salt.jpg', '200811100825480.bath salt_rough hand trow_200.jpg', NULL, NULL, NULL, NULL, 1, 1.20, NULL, 'TROWING', 'NOT PERFECT BODY SHAPE.\r\n\r\nTROWING BENTUK TIDAK SEMPURNA, SEDIKIT GOYANG. ', 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 8, NULL, NULL, NULL, 'MAKE TEXTURES DURING TRIMMING, TO KEEP HAND TROWED FEELING.\r\n\r\nBUAT TEKSTUR AGAK DALAM SAAT, TRIMMING. ', NULL, NULL, NULL, NULL, 'USE PROPER TOOLS TO MAKE TEXTURE ,WHILE THE PIECES STILL MOVING. MAKE DEEP TEXTURE. ', NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, 'WAX NECK PART UNTIL THE TOP (RIM), THEN DIPPING IN GLAZE TRANSPARENT.\r\n\r\nGUNAKAN LILIN PADA BAGIAN DARI BATAS BAWAH LEHER SAMPAI RIM, LALU DIPPING DI GLAZE TRANSPARENT. ', '1250', 'Oxidation', NULL, NULL, 10.00, NULL, 12.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 14.00, 0.00, '2008-12-01');
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (10, 'SC08-010', 'AMAN HANGZHOU - SAMPLE COTTON BUD/WOOL CONTAINER - ROUGH HAND TROWED ', NULL, NULL, '2008-11-10', '200811100835250.cotton bud&wool.jpg', '200811100835250.cottonl_rough hand trowed_200.jpg', NULL, NULL, NULL, NULL, 1, 0.70, NULL, 'TROWING', 'NOT PERFECT BODY SHAPE.\r\n\r\nTROWING BENTUK TIDAK SEMPURNA, SEDIKIT GOYANG. ', 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 8, NULL, NULL, NULL, 'MAKE TEXTURES DURING TRIMMING, TO KEEP HAND TROWED FEELING.\r\n\r\nBUAT TEKSTUR AGAK DALAM SAAT, TRIMMING.', NULL, NULL, NULL, NULL, 'USE PROPER TOOLS TO MAKE TEXTURE ,WHILE THE PIECES STILL MOVING. MAKE DEEP TEXTURE. ', NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, 'WAX NECK PART UNTIL THE TOP (RIM), THEN DIPPING IN GLAZE TRANSPARENT.\r\n\r\nGUNAKAN LILIN PADA BAGIAN DARI BATAS BAWAH LEHER SAMPAI RIM, LALU DIPPING DI GLAZE TRANSPARENT. ', '1250', 'Oxidation', NULL, NULL, 9.50, NULL, 9.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 11.00, 0.00, '2008-12-01');
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (11, 'SC08-011', 'AMAN HANGZHOU - SAMPLE COTTON BUD/WOOL CONTAINER - BAMBOO', NULL, NULL, '2008-11-10', '200811100838010.cotton bud&wool_bamboo.jpg', '200811100838010.cotton_bamboo_200.jpg', NULL, NULL, NULL, NULL, 1, 0.70, NULL, 'TROWING', 'MAKE BAMBOO SHAPE WHEN TRIMMING.', 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9, NULL, NULL, NULL, 'ADD LINE TEXTURE ON BAMBOO SHAPE.', NULL, NULL, NULL, NULL, 'USING GIGI TOOLS TO MAKE LINE TEXTURE ON BAMBOO.', NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 9.00, NULL, 7.50, 'STANDART FIRING', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 12.00, 0.00, '2008-12-01');
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (12, 'SC08-012', 'AMAN HANGZHOU - SAMPLE SHOWER CAP CONTAINER', NULL, NULL, '2008-11-10', '200811100846000.shower cap.jpg', '200811100846000.shower cap_200.jpg', NULL, NULL, NULL, NULL, 1, 0.20, NULL, 'TROWING', NULL, 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 5.50, NULL, 5.50, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 6.00, 0.00, '2008-12-01');
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (13, 'SC08-013', 'AMAN HANGZHOU - SAMPLE ASHTRAY', NULL, NULL, '2008-11-12', '200811120716000.ashtray.jpg', '200811120716000.ashtray_200.jpg', NULL, NULL, NULL, NULL, 1, 0.30, NULL, 'TROWING', 'TROWING THICK', 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, NULL, NULL, NULL, 'CARVED DEEP GENTENG TEXTURE, ON THE OUTSIDE PART ONLY, USING PROPER TOOLS WHEN THE CLAY STILL WET BEFORE TRIMMING PROCESS. (ON BODY ONLY)\r\n', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 4.50, NULL, 8.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 13.00, 0.00, '2008-12-01');
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (14, 'SC08-014', 'AMAN HANGZHOU - SAMPLE FINGER BOWL', NULL, NULL, '2008-11-12', '200811120723340.finger bowl.jpg', '200811120723340.finger bow_200.jpg', NULL, NULL, NULL, NULL, 1, 1.00, NULL, 'TROWING', 'TROWING THICK', 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, NULL, NULL, NULL, 'CARVED DEEP GENTENG TEXTURE ON THE OUTSIDE PART ONLY, USING PROPER TOOLS.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 6.00, NULL, 13.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 15.00, 0.00, '2008-12-01');
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (15, 'SC08-015', 'AMAN HANGZHOU - SAMPLE FLOWER DISH', NULL, NULL, '2008-11-12', '200811120725590.flower vase.jpg', '200811120725590.flower vase_200.jpg', NULL, NULL, NULL, NULL, 1, 0.40, NULL, 'TROWING', 'TROWING THICK', 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, NULL, NULL, NULL, 'CARVED DEEP GENTENG TEXTURE, ON THE OUTSIDE PART ONLY, USING PROPER TOOLS.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 5.00, NULL, 8.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 10.00, 0.00, '2008-12-01');
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (16, 'SC08-016', 'AMAN HANGZHOU - SAMPLE FRUIT BOWL', NULL, NULL, '2008-11-12', '200811120739250.fruit bowl.jpg', '200811120739250.fruit bowl_200.jpg', NULL, NULL, NULL, NULL, 1, 4.30, 'PART A (UPPER PART) : 2.8\r\nPART B (BOTTOM PART) : 1.5', 'TROWING', 'BUILD IN TWO PART, TROWING THICK FOR TEXTURED PART (PLATE). JOIN UPPER AND BOTTOM PART AFTER TRIMMING.', 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, NULL, NULL, NULL, 'CARVED DEEP GENTENG TEXTURE, ON THE OUTSIDE PART OF THE PLATE. WHEN THE CLAY STILL WET BEFORE TRIMMING.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 10.50, NULL, 26.50, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'FIRST SAMPLE GOT LITTLE PROBLEM ON THE TOP PART (PLATE), LITTLE BIT FALL DOWN.\r\n\r\nTHIS WORKPLAN IS USING FIRST REVISION FOR THE SIZE. NEW SIZE FOR PLATE (UPPER PART) NOW IS 6 CM (TOTAL) FROM 4 CM (TOTAL) ON THE FIRST SAMPLE. ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 37.00, 0.00, '2008-12-01');
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `PriceDollar`, `PriceEuro`, `LastUpdate`) VALUES (17, 'SC08-017', 'AMAN HANGZHOU - SAMPLE FRUIT PLATE', NULL, NULL, '2008-11-12', '200811120758190.fruit plate.jpg', '200811120758190.fruit plate_200.jpg', NULL, NULL, NULL, NULL, 1, 1.50, NULL, 'TROWING ', 'TROWING THICK', 'ROUND', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, NULL, NULL, NULL, 'CARVED DEEP GENTENG TEXTURE ON THE UPPER PART OF THE PLATE. ALMOST 3 CM FROM THE RIM, WHEN THE CLAY STILL WET BEFORE TRIMMING.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 2.00, NULL, 22.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 15.00, 0.00, '2008-12-01');




# dumping data for GayaFusionAll.samplepackaging
INSERT INTO `samplepackaging` (`ID`, `SampleCode`, `Description`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `DesMat1`, `DesMat2`, `DesMat3`, `DesMat4`, `DesMat5`, `QtyDesMat1`, `QtyDesMat2`, `QtyDesMat3`, `QtyDesMat4`, `QtyDesMat5`, `TotalDesMat1`, `TotalDesMat2`, `TotalDesMat3`, `TotalDesMat4`, `TotalDesMat5`, `Supplier1`, `Supplier2`, `Supplier3`, `Supplier4`, `Supplier5`, `Material1`, `Material2`, `Material3`, `Material4`, `Material5`, `Color1`, `Color2`, `Color3`, `Color4`, `Color5`, `CostPrice1`, `CostPrice2`, `CostPrice3`, `CostPrice4`, `CostPrice5`, `TotalDesMat`, `TotalCostPrice`, `TotalCost`, `InnerQty`, `Width`, `Height`, `Length`, `Diameter`, `Volume`, `Weight`, `Notes`, `PriceRisk`, `RealPrice`) VALUES (1, 'SP08-001', 'Packaging for Lilypad Exhibition', '2008-10-08', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tbladmin
INSERT INTO `tbladmin` (`ID`, `UserName`, `Passwd`) VALUES (1, 'ADMIN', 'ADMIN');




























































# dumping data for GayaFusionAll.tblcasting
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (1, 'CA08-001', 'CYLINDER_01 - S', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (5, 'CA08-005', 'CYLINDER_02 - S', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (2, 'CA08-002', 'CYLINDER_01 - M', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (3, 'CA08-003', 'CYLINDER_01 - L', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (4, 'CA08-004', 'CYLINDER_02 - XS', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (6, 'CA08-006', 'CYLINDER_02 - M', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (7, 'CA08-007', 'BOTTLE', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (8, 'CA08-008', 'LOTUS - SALT n PEPPER', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (9, 'CA08-009', 'OVAL PLATE', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (10, 'CA08-010', 'TENT', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (11, 'CA08-011', 'VESSEL DECORATIVE VASE', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (12, 'CA08-012', 'BALI BOX - S', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (13, 'CA08-013', 'BALI BOX - M', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (14, 'CA08-014', 'BALI BOX - L', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (15, 'CA08-015', 'GLASS - FISH', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (16, 'CA08-016', 'GLASS - UMBRELLA', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (17, 'CA08-017', 'GLASS - PALM TREE & MONSTER', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (18, 'CA08-018', 'GLASS - VOLCANO', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (19, 'CA08-019', 'GLASS - MONSTER', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (20, 'CA08-020', 'GLASS - GIRL', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (21, 'CA08-021', 'GLASS - SEA HORSE', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (22, 'CA08-022', 'GLASS - BIG FISH', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (23, 'CA08-023', 'GLASS - BIRD', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (24, 'CA08-024', 'GLASS - OCTOPUS', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (25, 'CA08-025', 'OBIKA - S', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (26, 'CA08-026', 'OBIKA - L', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (27, 'CA08-027', 'OSHIBURI', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblclay
INSERT INTO `tblclay` (`ID`, `ClayCode`, `ClayDescription`, `ClayDate`, `ClayTechDraw`, `ClayPhoto1`, `ClayPhoto2`, `ClayPhoto3`, `ClayPhoto4`, `ClayNotes`) VALUES (1, 'CL08-001', 'PORCELAIN', '2008-11-17', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblclay` (`ID`, `ClayCode`, `ClayDescription`, `ClayDate`, `ClayTechDraw`, `ClayPhoto1`, `ClayPhoto2`, `ClayPhoto3`, `ClayPhoto4`, `ClayNotes`) VALUES (2, 'CL08-002', 'STONEWARE', '2008-11-17', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblclay` (`ID`, `ClayCode`, `ClayDescription`, `ClayDate`, `ClayTechDraw`, `ClayPhoto1`, `ClayPhoto2`, `ClayPhoto3`, `ClayPhoto4`, `ClayNotes`) VALUES (3, 'CL08-003', 'RAKU', '2008-11-17', NULL, NULL, NULL, NULL, NULL, 'RECIPE (FOR MAKE 75 KG RAKU CLAY) :\r\n===================================\r\n24 KG KAOLIN\r\n21 KG MOLOCITE\r\n3  KG BENTONITE\r\n27 KG BALL CLAY\r\n---------------\r\n75 KG TOTAL\r\n\r\nMIX ALL MATERIAL, THEN ADD WATER BASED ON NECESSITY. \r\n\r\n');
INSERT INTO `tblclay` (`ID`, `ClayCode`, `ClayDescription`, `ClayDate`, `ClayTechDraw`, `ClayPhoto1`, `ClayPhoto2`, `ClayPhoto3`, `ClayPhoto4`, `ClayNotes`) VALUES (4, 'CL08-004', 'PORCELAIN RECYCLE', '2008-11-17', NULL, NULL, NULL, NULL, NULL, 'MIX AFTER TRIMMING RESIDUE CLAY WITH WATER.');
INSERT INTO `tblclay` (`ID`, `ClayCode`, `ClayDescription`, `ClayDate`, `ClayTechDraw`, `ClayPhoto1`, `ClayPhoto2`, `ClayPhoto3`, `ClayPhoto4`, `ClayNotes`) VALUES (5, 'CL08-005', 'STONEWARE RECYCLE', '2008-11-17', NULL, NULL, NULL, NULL, NULL, 'MIX AFTER TRIMMING RESIDUE CLAY WITH WATER.');


# dumping data for GayaFusionAll.tblcollect_category
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('00', 'MAIN COURSE PLATE');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('01', 'ENTREE PLATE');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('02', 'SIDE PLATE');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('03', 'CURRY BOWL');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('04', 'NOODLE BOWL');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('05', 'CONDIMENT BOWL');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('06', 'SOYA BOTTLE POURING+LID');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('07', 'WATER JUG');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('08', 'SOAP DISH');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('09', 'COTTON BUD CONTAINER');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('10', 'COTTON WOOL CONTAINER');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('11', 'BATH SALT CONTAINER');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('12', 'AMENITY TOILETRY');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('13', 'MOISTURIZER BOTTLE');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('14', 'DISH TRAY');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('15', 'FLOWER VASE');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('16', 'FINGER BOWL');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('17', 'AMENITY BOTTLE');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('18', 'BUTTER DISH');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('19', 'CHOPSTICK HOLDER');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('20', 'JAM DISH');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('21', 'SALT AND PEPPER DISH');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('22', 'SUGAR AND DIET SUGAR DISH');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('23', 'TOOTHPICK HOLDER WITH LID');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('24', 'FRUIT PLATE');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('25', 'BODY TREATMENT BOWL');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('26', 'OIL DISH BOWL');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('27', 'TEA CUP');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('28', 'CREAM BOTTLE');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('29', 'BATH TRAY');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('30', 'COTTON BUD/COTTON WOOL CONTAINER');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('31', 'SHOWER CAP CONTAINER');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('32', 'VANITY WATER GLASS');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('33', 'ASHTRAY');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('34', 'FLOWER DISH');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('35', 'FRUIT BOWL');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('36', 'OIL BURNER');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('37', 'TEA POT');


# dumping data for GayaFusionAll.tblcollect_color
INSERT INTO `tblcollect_color` (`ColorCode`, `ColorName`) VALUES ('AA', 'MATTE LIGHT GREY STONE + RIM TRANSPARENT DEC.');
INSERT INTO `tblcollect_color` (`ColorCode`, `ColorName`) VALUES ('AB', 'MATTE METALLIC DARK BROWN');
INSERT INTO `tblcollect_color` (`ColorCode`, `ColorName`) VALUES ('AC', 'WHITE UNGLAZED, SHINY WHITE DEC.');
INSERT INTO `tblcollect_color` (`ColorCode`, `ColorName`) VALUES ('AD', 'SHINY WHITE');
INSERT INTO `tblcollect_color` (`ColorCode`, `ColorName`) VALUES ('AE', 'MATTE LIGHT GREY STONE + SANDY DARK BROWN DEC.');
INSERT INTO `tblcollect_color` (`ColorCode`, `ColorName`) VALUES ('AF', 'MATTE LIGHT GREY STONE + TRANSPARENT DEC.');
INSERT INTO `tblcollect_color` (`ColorCode`, `ColorName`) VALUES ('AG', 'MATTE LIGHT GREY STONE');


# dumping data for GayaFusionAll.tblcollect_design
INSERT INTO `tblcollect_design` (`DesignCode`, `DesignName`) VALUES ('AL', 'AMAN LAOS');
INSERT INTO `tblcollect_design` (`DesignCode`, `DesignName`) VALUES ('AH', 'AMAN HANGZHOU');


# dumping data for GayaFusionAll.tblcollect_group_det
INSERT INTO `tblcollect_group_det` (`ID`, `Group_H_ID`, `CollectCode`, `Qty`) VALUES (1, 1, '1', 1);
INSERT INTO `tblcollect_group_det` (`ID`, `Group_H_ID`, `CollectCode`, `Qty`) VALUES (2, 1, '3', 1);
INSERT INTO `tblcollect_group_det` (`ID`, `Group_H_ID`, `CollectCode`, `Qty`) VALUES (3, 3, '19', 1);
INSERT INTO `tblcollect_group_det` (`ID`, `Group_H_ID`, `CollectCode`, `Qty`) VALUES (4, 3, '20', 1);


# dumping data for GayaFusionAll.tblcollect_group_h
INSERT INTO `tblcollect_group_h` (`Group_H_ID`, `GroupCode`, `GroupDate`, `DesignCode`, `GroupDescription`, `ClientCode`, `ClientDesc`, `GroupPhoto`, `Diameter`, `Height`, `Weight`, `Length`) VALUES (1, 'MMGR08-001', '0000-01-01', 'MM', 'SET GRAFITTI BOWL SMALL', NULL, NULL, '200810310117090.TEA 05.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblcollect_group_h` (`Group_H_ID`, `GroupCode`, `GroupDate`, `DesignCode`, `GroupDescription`, `ClientCode`, `ClientDesc`, `GroupPhoto`, `Diameter`, `Height`, `Weight`, `Length`) VALUES (2, 'MMGR08-002', '0000-01-01', 'MM', 'SET GRAFITTI BOWL LARGE', NULL, NULL, '200810310117210.TEA SAU 05.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblcollect_group_h` (`Group_H_ID`, `GroupCode`, `GroupDate`, `DesignCode`, `GroupDescription`, `ClientCode`, `ClientDesc`, `GroupPhoto`, `Diameter`, `Height`, `Weight`, `Length`) VALUES (3, 'AL08-001', '0000-01-01', 'AL', 'SET BOTTLES', NULL, NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblcollect_master
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (1, 'MMGFDBSMSM01PR', 'MM', 'GF', 'DB', 'SM', 'SM', '01', 'PR', NULL, NULL, '0000-01-01', '200810310115530.wp.jpg', '200810310115530.TEA 01.jpg', NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-11-04', 0.00, 10.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (2, 'MMGFDBLASM01PR', 'MM', 'GF', 'DB', 'LA', 'SM', '01', 'PR', NULL, NULL, '0000-01-01', '200810310116090.wp.jpg', '200810310116090.TEA 02.jpg', NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-10-08', 0.00, 15.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (3, 'MMGFDUSMSM01PR', 'MM', 'GF', 'DU', 'SM', 'SM', '01', 'PR', NULL, NULL, '0000-01-01', '200810310116250.wp.jpg', '200810310116250.TEA 03.jpg', NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-10-08', 0.00, 10.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (4, 'MMGFDULASM01PR', 'MM', 'GF', 'DU', 'LA', 'SM', '01', 'PR', NULL, NULL, '0000-01-01', '200810310116370.wp.jpg', '200810310116370.TEA 04.jpg', NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-10-08', 0.00, 15.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (5, 'ALAB00AJ00AA', 'AL', 'AB', '00', 'AJ', '00', 'AA', 'P', NULL, NULL, '2008-11-05', '200811050855590.main course.jpg', '200811050855590.Main Plate_200.jpg', NULL, NULL, NULL, NULL, 1, 3.00, NULL, 'TROWING', NULL, 'ROUND AND THIN', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, 2, NULL, NULL, '1210', '1230', NULL, NULL, 'DOUBLE DIPPING :\r\n1. FULL DIPPING IN MAT LIGHT GREY STONE GLAZE.\r\n2. DIPPING RIM PART ONLY IN TRANSPARENT GLAZE.', '1250', 'Oxidation', NULL, NULL, 3.50, NULL, 31.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 4, 9, 0, 0, 13, 6, 200, 100, 200, 4, 5, 5, 15, 7, 0, 0, 5, 10, 12, 12, 0, '2008-11-24', 19.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (6, 'ALAB01AJ00AA', 'AL', 'AB', '01', 'AJ', '00', 'AA', 'P', NULL, NULL, '2008-11-06', '200811060645020.entree plate.jpg', '200811060645020.Entree Plate_200.jpg', NULL, NULL, NULL, NULL, 1, 1.80, NULL, 'TROWING', NULL, 'ROUND AND THIN', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 2, 1, NULL, NULL, '1230', '1210', NULL, NULL, 'DOUBLE DIPPING :\r\n1. FULL DIPPING IN MAT LIGHT GREY STONE GLAZE.\r\n2. DIPPING RIM PART ONLY IN TRANSPARENT GLAZE. ', '1250', 'Oxidation', NULL, NULL, 3.00, NULL, 24.50, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 5, 7, 0, 0, 10, 0, 300, 200, 0, 0, 5, 5, 12, 9, 0, 0, 6, 0, 12, 12, 0, '2008-11-24', 14.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (7, 'ALAB02AJ00AAP', 'AL', 'AB', '02', 'AJ', '00', 'AA', 'P', NULL, NULL, '2008-11-11', '200811110557020.entree plate.jpg', '200811110557020.Entree Plate_200.jpg', NULL, NULL, NULL, NULL, 1, 0.90, NULL, 'TROWING', NULL, 'ROUND AND THIN', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 2, 1, NULL, NULL, '1230', '1210', NULL, NULL, 'DOUBLE DIPPING :\r\n1. FULL DIPPING IN MAT LIGHT GREY STONE GLAZE.\r\n2. DIPPING RIM PART ONLY IN TRANSPARENT GLAZE. ', '1250', 'Oxidation', NULL, NULL, 2.70, NULL, 16.50, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-12-01', 7.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (8, 'ALAB03AJ00AAP', 'AL', 'AB', '03', 'AJ', '00', 'AA', 'P', NULL, NULL, '2008-11-11', '200811110648190.curry bowl.jpg', '200811110648190.curry bowl_200.jpg', NULL, NULL, NULL, NULL, 1, 1.30, NULL, 'TROWING', NULL, 'ROUND AND THIN', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 2, 1, NULL, NULL, '1230', '1210', NULL, NULL, 'DOUBLE DIPPING :\r\n1. FULL DIPPING IN MAT LIGHT GREY STONE GLAZE.\r\n2. DIPPING RIM PART ONLY IN TRANSPARENT GLAZE. ', '1250', 'Oxidation', NULL, NULL, 6.50, NULL, 17.50, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-12-01', 15.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (9, 'ALAB04AJ00AAP', 'AL', 'AB', '04', 'AJ', '00', 'AA', 'P', NULL, NULL, '2008-11-11', '200811110725490.noodle bowl.jpg', '200811110725490.Noodle Bowl_200.jpg', NULL, NULL, NULL, NULL, 1, 1.00, NULL, 'TROWING', NULL, 'ROUND AND THIN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 2, 1, NULL, NULL, '1230', '1210', NULL, NULL, 'DOUBLE DIPPING :\r\n1. FULL DIPPING IN MAT LIGHT GREY STONE GLAZE.\r\n2. DIPPING RIM PART ONLY IN TRANSPARENT GLAZE. ', '1250', 'Oxidation', NULL, NULL, 8.00, NULL, 14.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-12-01', 15.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (10, 'ALAB05AJ00AAP', 'AL', 'AB', '05', 'AJ', '00', 'AA', 'P', NULL, NULL, '2008-11-11', '200811110852210.small condiment.jpg', '200811110852210.Small Condiment_200.jpg', NULL, NULL, NULL, NULL, 1, 0.00, NULL, 'TROWING', NULL, 'ROUND AND THIN', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 2, 1, NULL, NULL, '1230', '1210', NULL, NULL, 'DOUBLE DIPPING :\r\n1. FULL DIPPING IN MAT LIGHT GREY STONE GLAZE.\r\n2. DIPPING RIM PART ONLY IN TRANSPARENT GLAZE.  ', '1250', 'Oxidation', NULL, NULL, 2.50, NULL, 6.80, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-12-01', 4.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (11, 'ALAB06AJ00AAP', 'AL', 'AB', '06', 'AJ', '00', 'AA', 'P', NULL, NULL, '2008-11-12', '200811120208380.soya pouring.jpg', '200811120208380.Soya Pooring B.jpg', NULL, NULL, NULL, NULL, 1, 0.50, NULL, 'TROWING', NULL, 'ROUND AND THIN', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 2, 1, NULL, NULL, '1230', '1210', NULL, NULL, 'DOUBLE DIPPING :\r\n1. FULL DIPPING IN MAT LIGHT GREY STONE GLAZE.\r\n2. DIPPING RIM PART ONLY IN TRANSPARENT GLAZE.  ', '1250', 'Oxidation', NULL, NULL, 11.00, NULL, 8.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-12-01', 7.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (12, 'ALAB07AJ01AAP', 'AL', 'AB', '07', 'AJ', '01', 'AA', 'P', NULL, NULL, '2008-11-12', '200811120214510.water jug.jpg', '200811120214510.water Jug_200.jpg', NULL, NULL, NULL, NULL, 1, 4.10, 'PART A (BOTTOM PART) : 2.5\r\nPART B (UPPER PART) : 1.6', 'TROWING', 'MADE IN TWO PART, AFTER BOTH PART FINISH, JOIN THEM AFTER TRIMMING PROCESS.', 'ROUND', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, 'MAKE CIRCULAR LINE DECORATION BELOW NECK PART, DON\'T MAKE IT TO PRECISE.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 2, 1, NULL, NULL, '1230', '1210', NULL, NULL, 'DOUBLE DIPPING :\r\n1. FULL DIPPING IN MAT LIGHT GREY STONE GLAZE.\r\n2. DIPPING RIM PART ONLY IN TRANSPARENT GLAZE.  ', '1250', 'Oxidation', NULL, NULL, 19.00, NULL, 18.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-12-01', 35.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (13, 'ALAA08AE01ABP', 'AL', 'AA', '08', 'AE', '01', 'AB', 'P', NULL, NULL, '2008-11-12', '200811120844440.soap dish_mod 1.jpg', '200811120232240.soap dish A_200.jpg', NULL, NULL, NULL, NULL, 1, 0.50, NULL, 'TROWING', NULL, 'SEDIKIT MIRING', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, 'MAKE CIRCULAR LINE DECORATION, ONLY ON THE TOP PART OF THE PIECES.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '1180', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 3.20, NULL, 9.50, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-12-01', 13.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (14, 'ALAA08AF00AB', 'AL', 'AA', '08', 'AF', '00', 'AB', 'P', NULL, NULL, '2008-11-12', '200811120240460.soap dish_mod 2.jpg', '200811120240460.soap dish B_200.jpg', NULL, NULL, NULL, NULL, 1, 0.60, NULL, 'TROWING', 'MAKE THREE SMALL HOLES INSIDE AFTER TRIMMING.\r\n\r\nBUAT TIGA LUBANG KECIL DI BAGIAN DALAM, SETELAH PROSES TRIMMING', 'ROUND AND THIN', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '1180', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 3.50, NULL, 10.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-12-01', 13.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (15, 'ALAA08AG00ABP', 'AL', 'AA', '08', 'AG', '00', 'AB', 'P', NULL, NULL, '2008-11-12', '200811120244130.soap dish_mod 3.jpg', '200811120244130.soap dish D_200.jpg', NULL, NULL, NULL, NULL, 1, 0.60, NULL, 'TROWING', NULL, 'ROUND AND THIN', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '1180', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 3.50, NULL, 10.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-12-01', 13.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (16, 'ALAA09AJ00ABP', 'AL', 'AA', '09', 'AJ', '00', 'AB', 'P', NULL, NULL, '2008-11-12', '200901120701310.cotton bud&wool.jpg', '200811120308520.cotton bud & wool_200.jpg', NULL, NULL, NULL, NULL, 1, 0.30, NULL, 'TROWING', NULL, 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '1180', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 5.00, NULL, 7.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-12-01', 7.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (17, 'ALAA10AJ00ABP', 'AL', 'AA', '10', 'AJ', '00', 'AB', 'P', NULL, NULL, '2008-11-12', '200901120701410.cotton bud&wool.jpg', '200811120309570.cotton bud & wool_200.jpg', NULL, NULL, NULL, NULL, 1, 0.30, NULL, 'TROWING', NULL, 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '1180', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 5.00, NULL, 7.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-12-01', 7.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (18, 'ALAA11AJ00ABP', 'AL', 'AA', '11', 'AJ', '00', 'AB', 'P', NULL, NULL, '2008-11-12', '200901130639220.bath salt.jpg', '200811120314420.bath salt_200.jpg', NULL, NULL, NULL, NULL, 1, 0.60, NULL, 'TROWING', NULL, 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '1180', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 5.00, NULL, 10.50, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-12-01', 9.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (19, 'ALAA12AJ00ABP', 'AL', 'AA', '12', 'AJ', '00', 'AB', 'P', NULL, NULL, '2008-11-12', '200811120319470.amenity bottle.jpg', '200811120319470.amenity toiletry_200.jpg', NULL, NULL, NULL, NULL, 1, 0.50, NULL, 'TROWING', 'BE CAREFUL WHEN MAKE LID.\r\n\r\nHATI - HATI SAAT PEMBUATAN TOPI, SELALU CEK UKURAN DENGAN BARANG.', 'ROUND AND THIN', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '1180', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 14.50, NULL, 7.50, 0.00, 'FINAL SIZE MEASURED WITH LID ALREADY.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-12-01', 18.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (20, 'ALAA13AJ00ABP', 'AL', 'AA', '13', 'AJ', '00', 'AB', 'P', NULL, NULL, '2008-11-12', '200811120329220.shower bath.jpg', '200811120329220.moisturizer_200.jpg', NULL, NULL, NULL, NULL, 1, 0.50, NULL, 'TROWING', 'PAY ATTENTION IN THE LID.\r\n\r\nHATI - HATI SAAT PEMBUATAN TOPI.', 'ROUND AND THIN', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '1180', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 11.00, NULL, 8.00, 0.00, 'FINAL SIZE ALREADY MEASURED WITH LID.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-12-01', 18.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (21, 'ALAA14AJ00ABP', 'AL', 'AA', '14', 'AJ', '00', 'AB', 'P', NULL, NULL, '2008-11-12', '200811120347260.dish tray.jpg', '200811120347260.tray_200.jpg', NULL, NULL, NULL, NULL, 1, 2.00, NULL, 'TROWING', 'PAY ATTENTION ON THE THICKNESS.\r\n\r\nHATI - HATI TERHADAP KETEBALAN BARANG, HARUS SELALU CEK.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '1180', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 0.50, NULL, 29.30, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-12-01', 19.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (22, 'ALAA15AJ00ABP', 'AL', 'AA', '15', 'AJ', '00', 'AB', 'P', NULL, NULL, '2008-11-12', '200811120348370.flower vase.jpg', '200811120348370.flower vase_200.jpg', NULL, NULL, NULL, NULL, 1, NULL, NULL, 'TROWING', NULL, 'ROUND AND THIN', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '1180', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 11.00, NULL, 10.80, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-12-01', 16.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (23, 'ALAA16AJ00ABP', 'AL', 'AA', '16', 'AJ', '00', 'AB', 'P', NULL, NULL, '2008-11-12', '200811180620530.finger bowl.jpg', '200811120351500.finger bowl_200.jpg', NULL, NULL, NULL, NULL, 1, 0.80, NULL, 'TROWING', NULL, 'ROUND AND THIN', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '1180', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 6.70, NULL, 12.30, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2008-12-01', 15.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (24, 'AHAA28AJ00ACP', 'AH', 'AA', '28', 'AJ', '00', 'AC', 'P', NULL, NULL, '2008-11-08', '200811100600180.amenity bottle.jpg', '200811100729100.amenity_smooth_200.jpg', NULL, NULL, NULL, 1, 1, 0.70, NULL, 'TROWING', NULL, 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, 'USE WAX TO COVER NECK UNTIL RIM PART, ONLY ON THE OUTSIDE PART. THEN DIPPING IN TRANSPARENT GLAZE. \r\n\r\nGUNAKAN LILIN PADA BAGIAN LEHER HINGGA BAGIAN ATAS (RIM), HANYA PADA BAGIAN LUAR SAJA. LALU DIPPING DI GLAZE TRANSPARENT.', '1250', 'Oxidation', 'STANDART FIRING.', NULL, 10.00, NULL, 8.50, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 1, 6, 0, 0, 10, 5, 700, 350, 0, 0, 5, 5, 60, 10, 0, 0, 6, 12, 12, 12, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (26, 'ALAA24AJ00ABP', 'AL', 'AA', '24', 'AJ', '00', 'AB', 'P', NULL, NULL, '2008-12-12', '200812120715150.fruit plate.jpg', '200812130214280.fruit plate200.jpg', NULL, NULL, NULL, NULL, 1, 1.20, NULL, 'TROWING', NULL, 'ROUND AND THIN', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '1180', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 2.50, NULL, 21.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (27, 'ALAB18AJ00AGP', 'AL', 'AB', '18', 'AJ', '00', 'AG', 'P', NULL, NULL, '2008-12-13', '200812160052270.butter dish.jpg', '200812130213360.butter dish200.jpg', NULL, NULL, NULL, NULL, 1, 0.50, NULL, 'TROWING', NULL, 'FLAT NOT SO SHARP', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, '1230', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 3.00, NULL, 9.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (28, 'ALAB19AJ00AFP', 'AL', 'AB', '19', 'AJ', '00', 'AF', 'P', NULL, NULL, '2008-12-13', '200812130155140.chopstick holder.jpg', '200812130212540.chopstick holder200.jpg', NULL, NULL, NULL, NULL, 1, 0.00, NULL, 'TROWING', NULL, 'ROUND', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 2, 1, NULL, NULL, '1230', '1210', NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 1.00, NULL, 7.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (29, 'ALAB20AJ00AGP', 'AL', 'AB', '20', 'AJ', '00', 'AG', 'P', NULL, NULL, '2008-12-13', '200812130158390.jam bowl.jpg', '200812130212360.jam dish200.jpg', NULL, NULL, NULL, NULL, 1, 0.30, NULL, 'TROWING', NULL, 'ROUND', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, '1230', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 5.50, NULL, 7.50, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (30, 'ALAB21AJ00AGP', 'AL', 'AB', '21', 'AJ', '00', 'AG', 'P', NULL, NULL, '2008-12-13', '200812130159390.salt n pepper.jpg', '200812130212200.salt n pepper200.jpg', NULL, NULL, NULL, NULL, 1, 0.00, NULL, 'TROWING', NULL, 'ROUND', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, '1230', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 3.00, NULL, 5.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (31, 'ALAB22AJ00AGP', 'AL', 'AB', '22', 'AJ', '00', 'AG', 'P', NULL, NULL, '2008-12-13', '200901130156080.diet&sugar dish.jpg', '200812130212010.sugar&diet dish200.jpg', NULL, NULL, NULL, NULL, 1, 0.40, NULL, 'TROWING', NULL, 'ROUND', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, '1230', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 9.00, NULL, 8.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (32, 'ALAB23AJ00AGP', 'AL', 'AB', '23', 'AJ', '00', 'AG', 'P', NULL, NULL, '2008-12-13', '200901130156470.toothpick holder.jpg', '200812130211420.toothpick holder&lid200.jpg', NULL, NULL, NULL, NULL, 1, 0.40, NULL, 'TROWING', NULL, 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, '1230', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 9.50, NULL, 3.80, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (33, 'ALAC25AC00AEP', 'AL', 'AC', '25', 'AC', '00', 'AE', 'P', NULL, NULL, '0000-01-01', '200812150216380.body treatment_l.jpg', '200812130208570.L-body treatment200.jpg', NULL, NULL, NULL, NULL, 1, 3.80, NULL, 'TROWING', NULL, 'ROUND', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, 'PUT ENGOBE PORCELAIN + 40% SAND ON THE OUTSIDE PART ONLY.\r\n\r\nDEKORASI ENGOBE PORCELAIN + 40 % SAND HANYA PADA BAGIAN LUAR.', '960', NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, '1230', NULL, NULL, NULL, NULL, '1250', NULL, NULL, NULL, 12.30, NULL, 27.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (34, 'ALAC25AA00AEP', 'AL', 'AC', '25', 'AA', '00', 'AE', 'P', NULL, NULL, '0000-01-01', '200812150237390.body treatment_s.jpg', '200812130208380.S-body treatment200.jpg', NULL, NULL, NULL, NULL, 1, 1.10, NULL, 'TROWING', NULL, 'ROUND', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, 'PUT ENGOBE PORCELAIN + 40% SAND ON THE OUTSIDE PART ONLY.\r\n\r\nDEKORASI ENGOBE PORCELAIN + 40 % SAND HANYA PADA BAGIAN LUAR. ', '960', NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, '1230', NULL, NULL, NULL, NULL, '1250', NULL, NULL, NULL, 6.00, NULL, 15.50, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (35, 'ALAC26AA00AEP', 'AL', 'AC', '26', 'AA', '00', 'AE', 'P', NULL, NULL, '0000-01-01', '200812150238590.oil dish bowl_s.jpg', '200812130207300.S-bowl-oil dish200.jpg', NULL, NULL, NULL, NULL, 1, 0.20, NULL, 'TROWING', NULL, 'ROUND', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, 'PUT ENGOBE PORCELAIN + 40% SAND ON THE OUTSIDE PART ONLY.\r\n\r\nDEKORASI ENGOBE PORCELAIN + 40 % SAND HANYA PADA BAGIAN LUAR. ', '960', NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, '1230', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 5.00, NULL, 7.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (36, 'ALAC26AB00AEP', 'AL', 'AC', '26', 'AB', '00', 'AE', 'P', NULL, NULL, '0000-01-01', '200812150250160.oil dish bowl_m.jpg', '200812130207110.M-bowl-oil dish200.jpg', NULL, NULL, NULL, NULL, 1, 0.30, NULL, 'TROWING', NULL, 'ROUND', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, 'PUT ENGOBE PORCELAIN + 40% SAND ON THE OUTSIDE PART ONLY.\r\n\r\nDEKORASI ENGOBE PORCELAIN + 40 % SAND HANYA PADA BAGIAN LUAR. ', '960', NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, '1230', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 5.00, NULL, 8.50, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (37, 'ALAC26AC00AEP', 'AL', 'AC', '26', 'AC', '00', 'AE', 'P', NULL, NULL, '0000-01-01', '200812150258070.oil dish bowl_l.jpg', '200812130206460.L-bowl-oil dish200.jpg', NULL, NULL, NULL, NULL, 1, 0.50, NULL, 'TROWING', NULL, 'ROUND', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, 'PUT ENGOBE PORCELAIN + 40% SAND ON THE OUTSIDE PART ONLY.\r\n\r\nDEKORASI ENGOBE PORCELAIN + 40 % SAND HANYA PADA BAGIAN LUAR. ', '960', NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, '1230', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 5.50, NULL, 12.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (38, 'ALAC27AJ00AGP', 'AL', 'AC', '27', 'AJ', '00', 'AG', 'P', NULL, NULL, '2008-12-15', '200812150303410.tea cup.jpg', '200812130205480.tea cup200.jpg', NULL, NULL, NULL, NULL, 1, 0.40, NULL, 'TROWING', NULL, 'ROUND', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, '1230', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 7.50, NULL, 8.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (39, 'AHAA17AJ02ACP', 'AH', 'AA', '17', 'AJ', '02', 'AC', 'P', NULL, NULL, '2008-11-10', '200812230136550.amenity bottle.jpg', '200811100648070.amenity_med hand trowed_200.jpg', NULL, NULL, NULL, 2, 1, 0.70, NULL, 'TROWING', NULL, 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 7, NULL, NULL, NULL, 'KEEP MEDIUM HAND TROWED TEXTURE ON THE PIECES.', NULL, NULL, NULL, NULL, 'MAKES TEXTURE WHILE THE PIECES STILL MOVING. MOVE THE TOOLS FROM BOTTOM TILL TOP AND OPPOSITE.\r\n\r\nBUAT TEKSTUR SAAT BARANG MASIH DIPUTAR. GUNAKAN ALAT DARI BAWAH KE ATAS DAN SEBALIKNYA.', NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, 'USE WAX TO COVER NECK UNTIL RIM PART, ONLY ON THE OUTSIDE PART. THEN DIPPING IN TRANSPARENT GLAZE.\r\n\r\nGUNAKAN LILIN PADA BAGIAN LEHER SAMPAI RIM, LALU DIPPING DI GLAZE TRANSPARENT.', '1250', 'Oxidation', NULL, NULL, 10.00, NULL, 8.50, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (40, 'AHAA11AJ02ACP', 'AH', 'AA', '11', 'AJ', '02', 'AC', 'P', NULL, NULL, '2008-11-08', '200812230138260.bath salt_med.jpg', '200811100613290.bath salth_med hand trowed_200.jpg', NULL, NULL, NULL, 3, 1, 1.20, NULL, 'TROWING', NULL, 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 7, NULL, NULL, NULL, 'MAKES TEXTURE WHILE THE PIECES STILL MOVING. MOVE THE TOOLS FROM BOTTOM TILL TOP AND OPPOSITE.\r\n\r\nBUAT TEKSTUR SAAT BARANG MASIH DIPUTAR. GUNAKAN ALAT DARI BAWAH KE ATAS DAN SEBALIKNYA. ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, 'USE WAX TO COVER NECK UNTIL RIM PART, ONLY ON THE OUTSIDE PART. THEN DIPPING IN TRANSPARENT GLAZE.', '1250', 'Oxidation', NULL, NULL, 10.00, NULL, 12.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (41, 'AHAA30AJ02ACP', 'AH', 'AA', '30', 'AJ', '02', 'AC', 'P', NULL, NULL, '2008-11-10', '200812230217110.cotton bud&wool_med.jpg', '200811100605050.cotton_med hand trowed_200.jpg', NULL, NULL, NULL, 4, 1, 0.70, NULL, 'TROWING', NULL, 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 7, NULL, NULL, NULL, 'KEEP MEDIUM HAND-TROWED TEXTURE ON THE PIECES.', NULL, NULL, NULL, NULL, 'MAKES TEXTURE WHILE THE PIECES STILL MOVING. MOVE THE TOOLS FROM BOTTOM TILL TOP AND OPPOSITE.\r\n\r\nBUAT TEKSTUR SAAT BARANG MASIH DIPUTAR. GUNAKAN ALAT DARI BAWAH KE ATAS DAN SEBALIKNYA. ', NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, 'USE WAX TO COVER NECK UNTIL RIM PART, ONLY ON THE OUTSIDE PART. THEN DIPPING IN TRANSPARENT GLAZE.\r\n\r\nGUNAKAN LILIN PADA BAGIAN LEHER SAMPAI RIM, LALU DIPPING DI GLAZE TRANSPARENT. ', '1250', 'Oxidation', NULL, NULL, 9.50, NULL, 9.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (42, 'AHAA29AJ00ADP', 'AH', 'AA', '29', 'AJ', '00', 'AD', 'P', NULL, NULL, '2008-11-08', '200811100616320.bath tray.jpg', '200811100616320.bath tray_200.jpg', NULL, NULL, NULL, 5, 1, 2.00, NULL, 'TROWING', 'BE CAREFUL ON TRIMMING PROCESS. KEEP SAME THICKNESS.', 'FLAT', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, 'WAX ALMOST ALL THE RIM AND BOTTOM PART, THEN DIPPING IN GLAZE TRANSPARENT.', '1250', 'Oxidation', 'STANDART FIRING', NULL, 0.50, NULL, 29.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (45, 'AHAA31AJ00ADP', 'AH', 'AA', '31', 'AJ', '00', 'AD', 'P', NULL, NULL, '2008-11-10', '200811100846000.shower cap.jpg', '200811100846000.shower cap_200.jpg', NULL, NULL, NULL, 8, 1, 0.20, NULL, 'TROWING', NULL, 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 5.50, NULL, 5.50, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (46, 'AHAA08AJ03ADP', 'AH', 'AA', '08', 'AJ', '03', 'AD', 'P', NULL, NULL, '2008-12-23', '200812230227060.soap dish.jpg', '200812230227060.soap dish_200.jpg', NULL, NULL, NULL, NULL, 1, 0.00, NULL, 'SLAB', NULL, '45�', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, NULL, NULL, NULL, 'MAKE GENTENG TEXTURE, FOLLOW THE SAMPLE ON THE UPPER PART ONLY.\r\n\r\nBUAT TEKSTUR GENTENG SESUAI DENGAN SAMPLE HANYA PADA BAGIAN ATAS.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, 7.50, 1.50, 12.50, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (47, 'AHAA32AJ01ADP', 'AH', 'AA', '32', 'AJ', '01', 'AD', 'P', NULL, NULL, '2008-12-23', '200812230235350.vanity water glass.jpg', '200812230235350.vanity water glass_200.jpg', NULL, NULL, NULL, NULL, 1, 0.70, NULL, 'TROWING', NULL, 'ROUND', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, 'MAKE CIRCULAR LINE TEXTURE NOT REALLY DEEP ON THE OUTSIDE PART ONLY.\r\n\r\nBUAT TEKSTUR GARIS MELINGKAR DAN TIDAK TERLALU DALAM. HANYA PADA BAGIAN LUAR.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 10.50, NULL, 7.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (48, 'AHAD33AJ03ADP', 'AH', 'AD', '33', 'AJ', '03', 'AD', 'P', NULL, NULL, '2008-11-12', '200811120716000.ashtray.jpg', '200811120716000.ashtray_200.jpg', NULL, NULL, NULL, 9, 1, 0.30, NULL, 'TROWING', 'TROWING THICK', 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, NULL, NULL, NULL, 'CARVED DEEP GENTENG TEXTURE, ON THE OUTSIDE PART ONLY, USING PROPER TOOLS WHEN THE CLAY STILL WET BEFORE TRIMMING PROCESS. (ON BODY ONLY)\r\n', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 4.50, NULL, 8.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (49, 'AHAD16AJ03ADP', 'AH', 'AD', '16', 'AJ', '03', 'AD', 'P', NULL, NULL, '2008-11-12', '200811120723340.finger bowl.jpg', '200811120723340.finger bow_200.jpg', NULL, NULL, NULL, 10, 1, 1.00, NULL, 'TROWING', 'TROWING THICK', 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, NULL, NULL, NULL, 'CARVED DEEP GENTENG TEXTURE ON THE OUTSIDE PART ONLY, USING PROPER TOOLS.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 6.00, NULL, 13.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (50, 'AHAD34AJ03ADP', 'AH', 'AD', '34', 'AJ', '03', 'AD', 'P', NULL, NULL, '2008-11-06', '200811100619250.flower vase.jpg', '200811100619250.flower vase_200.jpg', NULL, NULL, NULL, 11, 1, 0.40, NULL, 'TROWING', 'TROWING THICK', 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, NULL, NULL, NULL, 'MAKE DEEP GENTENG TEXTURE USING PROPER TOOLS BEFORE TRIMMING WHEN THE CLAY STILL WET.\r\n\r\n', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, NULL, '1250', 'Oxidation', 'STANDART FIRING', NULL, 5.00, NULL, 8.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (51, 'AHAD35AJ03ADP', 'AH', 'AD', '35', 'AJ', '03', 'AD', 'P', NULL, NULL, '2008-11-12', '200811120739250.fruit bowl.jpg', '200811120739250.fruit bowl_200.jpg', NULL, NULL, NULL, 12, 1, 4.30, 'PART A (UPPER PART) : 2.8\r\nPART B (BOTTOM PART) : 1.5', 'TROWING', 'BUILD IN TWO PART, TROWING THICK FOR TEXTURED PART (PLATE). JOIN UPPER AND BOTTOM PART AFTER TRIMMING.', 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, NULL, NULL, NULL, 'CARVED DEEP GENTENG TEXTURE, ON THE OUTSIDE PART OF THE PLATE. WHEN THE CLAY STILL WET BEFORE TRIMMING.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 10.50, NULL, 26.50, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'FIRST SAMPLE GOT LITTLE PROBLEM ON THE TOP PART (PLATE), LITTLE BIT FALL DOWN.\r\n\r\nTHIS WORKPLAN IS USING FIRST REVISION FOR THE SIZE. NEW SIZE FOR PLATE (UPPER PART) NOW IS 6 CM (TOTAL) FROM 4 CM (TOTAL) ON THE FIRST SAMPLE. ', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (52, 'AHAD24AJ03ADP', 'AH', 'AD', '24', 'AJ', '03', 'AD', 'P', NULL, NULL, '2008-11-12', '200811120758190.fruit plate.jpg', '200811120758190.fruit plate_200.jpg', NULL, NULL, NULL, 13, 1, 1.50, NULL, 'TROWING ', 'TROWING THICK', 'ROUND', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, NULL, NULL, NULL, 'CARVED DEEP GENTENG TEXTURE ON THE UPPER PART OF THE PLATE. ALMOST 3 CM FROM THE RIM, WHEN THE CLAY STILL WET BEFORE TRIMMING.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 2.00, NULL, 22.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (53, 'AHAD19AJ03ADP', 'AH', 'AD', '19', 'AJ', '03', 'AD', 'P', NULL, NULL, '2008-12-24', NULL, '200812240316030.chopstick holder_200.jpg', NULL, NULL, NULL, NULL, 1, 0.00, NULL, 'SLAB', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, NULL, NULL, NULL, 'MAKE GENTENG TEXTURE, FOLLOW THE SAMPLE ON THE UPPER PART ONLY.\r\n\r\nBUAT TEKSTUR GENTENG SESUAI DENGAN SAMPLE HANYA PADA BAGIAN ATAS. ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '1210', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, 2.50, 1.50, 7.00, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (54, 'ALAC36AJ00AEP', 'AL', 'AC', '36', 'AJ', '00', 'AE', 'P', NULL, NULL, '2009-01-02', '200901120826390.oil burner.jpg', '200901120828340.oil burnersand200.jpg', NULL, NULL, NULL, NULL, 1, 1.10, 'TOP PART : 0.3\r\nBOTTOM PART : 0.4\r\nPLATE : 0.4', 'TROWING', NULL, 'ROUND AND THIN', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, 'PUT ENGOBE 60% PORCELAIN + 40% SAND ON THE OUTSIDE PART ONLY.\r\n\r\nDEKORASI ENGOBE 60% PORCELAIN + 40% SAND, HANYA PADA BAGIAN LUAR SAJA.', '960', NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, '1230', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, NULL, NULL, NULL, 0.00, 'UPPER PART : DIAM. 8.8 X H 9\r\nBOTTOM PART (PLATE) : DIAM 10 X H3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (55, 'ALAA31AJ00ABP', 'AL', 'AA', '31', 'AJ', '00', 'AB', 'P', NULL, NULL, '2009-01-12', '200901120710100.cotton bud&wool.jpg', '200901120710100.cotton bud & wool_200.jpg', NULL, NULL, NULL, NULL, 1, 0.30, NULL, 'TROWING', NULL, 'FLAT', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '1180', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 5.00, NULL, 7.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (56, 'ALAA15AA00ABP', 'AL', 'AA', '15', 'AA', '00', 'AB', 'P', NULL, NULL, '2009-01-12', '200901120742290.small flower vase.jpg', '200901120746330.small flower_200.jpg', NULL, NULL, NULL, NULL, 1, 0.40, NULL, 'TROWING', NULL, 'ROUND', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '1180', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, NULL, 6.70, NULL, 8.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayPreparationMinute`, `WheelMinute`, `SlabMinute`, `CastingMinute`, `FinishingMinute`, `GlazingMinute`, `StandardBisqueLoading`, `StandardGlazeLoading`, `RakuBisqueLoading`, `RakuGlazeLoading`, `MovementMinute`, `PackagingWorkMinute`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `RealSellingPrice`, `LastUpdate`, `PriceDollar`, `PriceEuro`) VALUES (58, 'ALAC37AJ00AGP', 'AL', 'AC', '37', 'AJ', '00', 'AG', 'P', NULL, NULL, '2009-01-13', '200901130227380.Tea_Pot.jpg', '200901130223050.tea pot200.jpg', NULL, NULL, NULL, NULL, 1, 0.90, NULL, 'TROWING', NULL, 'ROUND', 'ROUND', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, '1230', NULL, NULL, NULL, NULL, '1250', 'Oxidation', NULL, 14.50, 7.50, 18.50, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0.00, 0.00);


# dumping data for GayaFusionAll.tblcollect_material
INSERT INTO `tblcollect_material` (`MaterialCode`, `MaterialName`) VALUES ('S', 'STONEWARE');
INSERT INTO `tblcollect_material` (`MaterialCode`, `MaterialName`) VALUES ('P', 'PORCELAIN');
INSERT INTO `tblcollect_material` (`MaterialCode`, `MaterialName`) VALUES ('R', 'RAKU');


# dumping data for GayaFusionAll.tblcollect_name
INSERT INTO `tblcollect_name` (`NameCode`, `NameDesc`) VALUES ('AA', 'BATHROOM');
INSERT INTO `tblcollect_name` (`NameCode`, `NameDesc`) VALUES ('AB', 'RESTAURANT');
INSERT INTO `tblcollect_name` (`NameCode`, `NameDesc`) VALUES ('AC', 'SPA');
INSERT INTO `tblcollect_name` (`NameCode`, `NameDesc`) VALUES ('AD', 'ROOM');
INSERT INTO `tblcollect_name` (`NameCode`, `NameDesc`) VALUES ('AE', 'F & B');


# dumping data for GayaFusionAll.tblcollect_size
INSERT INTO `tblcollect_size` (`SizeCode`, `SizeName`) VALUES ('AB', 'MEDIUM');
INSERT INTO `tblcollect_size` (`SizeCode`, `SizeName`) VALUES ('AA', 'SMALL');
INSERT INTO `tblcollect_size` (`SizeCode`, `SizeName`) VALUES ('AC', 'LARGE');
INSERT INTO `tblcollect_size` (`SizeCode`, `SizeName`) VALUES ('AD', 'BIG');
INSERT INTO `tblcollect_size` (`SizeCode`, `SizeName`) VALUES ('AE', 'MODEL 1');
INSERT INTO `tblcollect_size` (`SizeCode`, `SizeName`) VALUES ('AF', 'MODEL 2');
INSERT INTO `tblcollect_size` (`SizeCode`, `SizeName`) VALUES ('AG', 'MODEL 3');
INSERT INTO `tblcollect_size` (`SizeCode`, `SizeName`) VALUES ('AH', 'MODEL 4');
INSERT INTO `tblcollect_size` (`SizeCode`, `SizeName`) VALUES ('AI', 'MODEL 5');
INSERT INTO `tblcollect_size` (`SizeCode`, `SizeName`) VALUES ('AJ', 'UNIQUE SIZE');


# dumping data for GayaFusionAll.tblcollect_texture
INSERT INTO `tblcollect_texture` (`TextureCode`, `TextureName`) VALUES ('00', 'SMOOTH');
INSERT INTO `tblcollect_texture` (`TextureCode`, `TextureName`) VALUES ('01', 'CIRCULAR LINE');
INSERT INTO `tblcollect_texture` (`TextureCode`, `TextureName`) VALUES ('02', 'MEDIUM HAND - TROWED');
INSERT INTO `tblcollect_texture` (`TextureCode`, `TextureName`) VALUES ('03', 'GENTENG');


# dumping data for GayaFusionAll.tblcosting_casting
INSERT INTO `tblcosting_casting` (`ID`, `CostPerMinute`) VALUES (1, 400);


# dumping data for GayaFusionAll.tblcosting_clay
INSERT INTO `tblcosting_clay` (`ID`, `ClayType`, `PricePerKG`) VALUES (1, 'PORCELAIN', 3350);
INSERT INTO `tblcosting_clay` (`ID`, `ClayType`, `PricePerKG`) VALUES (2, 'STONEWARE', 2200);
INSERT INTO `tblcosting_clay` (`ID`, `ClayType`, `PricePerKG`) VALUES (3, 'RAKU', 4000);


# dumping data for GayaFusionAll.tblcosting_claypreparation
INSERT INTO `tblcosting_claypreparation` (`ID`, `CostPerMinute`) VALUES (1, 400);


# dumping data for GayaFusionAll.tblcosting_costbudgetpreview
INSERT INTO `tblcosting_costbudgetpreview` (`ID`, `BudgetYear`, `CostBudgetAmmount`) VALUES (1, 2007, 1500000000);


# dumping data for GayaFusionAll.tblcosting_finishing
INSERT INTO `tblcosting_finishing` (`ID`, `CostPerMinute`) VALUES (1, 400);


# dumping data for GayaFusionAll.tblcosting_glazing
INSERT INTO `tblcosting_glazing` (`ID`, `CostPerMinute`) VALUES (1, 400);




# dumping data for GayaFusionAll.tblcosting_movement
INSERT INTO `tblcosting_movement` (`ID`, `CostPerMinute`) VALUES (1, 400);


# dumping data for GayaFusionAll.tblcosting_packagingwork
INSERT INTO `tblcosting_packagingwork` (`ID`, `CostPerMinute`) VALUES (1, 400);


# dumping data for GayaFusionAll.tblcosting_productivehours
INSERT INTO `tblcosting_productivehours` (`ID`, `Day`, `Month`, `Year`) VALUES (1, 6.00, 25, 12);


# dumping data for GayaFusionAll.tblcosting_rakubisque
INSERT INTO `tblcosting_rakubisque` (`ID`, `PricePerFiring`) VALUES (1, 1500.00);


# dumping data for GayaFusionAll.tblcosting_rakuglaze
INSERT INTO `tblcosting_rakuglaze` (`ID`, `PricePerFiring`) VALUES (1, 10000.00);


# dumping data for GayaFusionAll.tblcosting_slab
INSERT INTO `tblcosting_slab` (`ID`, `CostPerMinute`) VALUES (1, 400);


# dumping data for GayaFusionAll.tblcosting_standardbisque
INSERT INTO `tblcosting_standardbisque` (`ID`, `PricePerFiring`) VALUES (1, 1500.00);


# dumping data for GayaFusionAll.tblcosting_standardglaze
INSERT INTO `tblcosting_standardglaze` (`ID`, `PricePerFiring`) VALUES (1, 3000.00);


# dumping data for GayaFusionAll.tblcosting_trowworker
INSERT INTO `tblcosting_trowworker` (`ID`, `TrowWorker`) VALUES (1, 3);


# dumping data for GayaFusionAll.tblcosting_wheel
INSERT INTO `tblcosting_wheel` (`ID`, `CostPerMinute`) VALUES (1, 400);


# dumping data for GayaFusionAll.tbldesignmat
INSERT INTO `tbldesignmat` (`DesignMatID`, `DesignMatCode`, `DesignMatDescription`, `DesignMatTechDraw`, `DesignMatPhoto1`, `DesignMatPhoto2`, `DesignMatPhoto3`, `DesignMatPhoto4`, `DesignMatSupplier`, `DesignMatUnit`, `DesignMatUnitPrice`, `DesignMatNotes`, `DesignMatDate`) VALUES (1, 'DM08-001', 'SILVER', NULL, NULL, NULL, NULL, NULL, 1, '01', 12000, NULL, '0000-01-01');


# dumping data for GayaFusionAll.tblengobe
INSERT INTO `tblengobe` (`ID`, `EngobeCode`, `EngobeDescription`, `EngobeDate`, `EngobeTechDraw`, `EngobePhoto1`, `EngobePhoto2`, `EngobePhoto3`, `EngobePhoto4`, `EngobeNotes`) VALUES (1, 'EN08-001', 'STONEWARE + 50% SAND', '2008-11-14', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n50% STONEWARE + 50% SAND');
INSERT INTO `tblengobe` (`ID`, `EngobeCode`, `EngobeDescription`, `EngobeDate`, `EngobeTechDraw`, `EngobePhoto1`, `EngobePhoto2`, `EngobePhoto3`, `EngobePhoto4`, `EngobeNotes`) VALUES (2, 'EN08-002', 'PORCELAIN + 40% SAND (EN08-002)', '2008-11-15', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n60% PORCELAIN + 40% SAND');
INSERT INTO `tblengobe` (`ID`, `EngobeCode`, `EngobeDescription`, `EngobeDate`, `EngobeTechDraw`, `EngobePhoto1`, `EngobePhoto2`, `EngobePhoto3`, `EngobePhoto4`, `EngobeNotes`) VALUES (3, 'EN08-003', 'RAKU + 50% SAND', '2008-11-15', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n50% PORCELAIN + 40% SAND');
INSERT INTO `tblengobe` (`ID`, `EngobeCode`, `EngobeDescription`, `EngobeDate`, `EngobeTechDraw`, `EngobePhoto1`, `EngobePhoto2`, `EngobePhoto3`, `EngobePhoto4`, `EngobeNotes`) VALUES (4, 'EN08-004', 'PORCELAIN + 1% SAND', '2008-11-15', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n99% PORCELAIN + 1% SAND');
INSERT INTO `tblengobe` (`ID`, `EngobeCode`, `EngobeDescription`, `EngobeDate`, `EngobeTechDraw`, `EngobePhoto1`, `EngobePhoto2`, `EngobePhoto3`, `EngobePhoto4`, `EngobeNotes`) VALUES (5, 'EN08-005', 'PORCELAIN + 3% CROME OXIDE', '2008-11-15', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n100% PORCELAIN + 3% CROME OXIDE');
INSERT INTO `tblengobe` (`ID`, `EngobeCode`, `EngobeDescription`, `EngobeDate`, `EngobeTechDraw`, `EngobePhoto1`, `EngobePhoto2`, `EngobePhoto3`, `EngobePhoto4`, `EngobeNotes`) VALUES (6, 'EN08-006', 'PORCELAIN + 3% C.500', '2008-11-15', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n100% PORCELAIN + 3% C.500');
INSERT INTO `tblengobe` (`ID`, `EngobeCode`, `EngobeDescription`, `EngobeDate`, `EngobeTechDraw`, `EngobePhoto1`, `EngobePhoto2`, `EngobePhoto3`, `EngobePhoto4`, `EngobeNotes`) VALUES (7, 'EN08-007', 'PORCELAIN + 3% BLACK STAIN', '2008-11-15', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n100% PORCELAIN + 3% C.500');
INSERT INTO `tblengobe` (`ID`, `EngobeCode`, `EngobeDescription`, `EngobeDate`, `EngobeTechDraw`, `EngobePhoto1`, `EngobePhoto2`, `EngobePhoto3`, `EngobePhoto4`, `EngobeNotes`) VALUES (8, 'EN08-008', 'PORCELAIN + 30% SAND', '2008-11-15', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n70% PORCELAIN + 30% SAND');


# dumping data for GayaFusionAll.tblestruder
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (1, 'ES08-001', 'ESTRUDER - 001', '2008-11-17', NULL, '200811170458480.est001_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (2, 'ES08-002', 'ESTRUDER - 002', '2008-11-17', NULL, '200811170504010.est002_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (3, 'ES08-003', 'ESTRUDER - 003', '2008-11-17', NULL, '200811170511440.est003_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (4, 'ES08-004', 'ESTRUDER - 004', '2008-11-17', NULL, '200811170511540.est004_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (5, 'ES08-005', 'ESTRUDER - 005', '2008-11-17', NULL, '200811170514130.est005_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (6, 'ES08-006', 'ESTRUDER - 006', '2008-11-17', NULL, '200811170514220.est006_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (7, 'ES08-007', 'ESTRUDER - 007', '2008-11-17', NULL, '200811170514320.est007_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (8, 'ES08-008', 'ESTRUDER - 008', '2008-11-17', NULL, '200811170514400.est008_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (9, 'ES08-009', 'ESTRUDER - 009', '2008-11-17', NULL, '200811170514510.est009_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (10, 'ES08-010', 'ESTRUDER - 010', '2008-11-17', NULL, '200811170514580.est010_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (11, 'ES08-011', 'ESTRUDER - 011', '2008-11-17', NULL, '200811170520580.est011_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (12, 'ES08-012', 'ESTRUDER - 012', '2008-11-17', NULL, '200811170521070.est012_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (13, 'ES08-013', 'ESTRUDER - 013', '2008-11-17', NULL, '200811170530390.est013_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (14, 'ES08-014', 'ESTRUDER - 014', '2008-11-17', NULL, '200811170530470.est014_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (15, 'ES08-015', 'ESTRUDER - 015', '2008-11-17', NULL, '200811170530560.est015_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (16, 'ES08-016', 'ESTRUDER - 016', '2008-11-17', NULL, '200811170531040.est016_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (17, 'ES08-017', 'ESTRUDER - 017', '2008-11-17', NULL, '200811170531310.est017_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (18, 'ES08-018', 'ESTRUDER - 018', '2008-11-17', NULL, '200811170531390.est018_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (19, 'ES08-019', 'ESTRUDER - 019', '2008-11-17', NULL, '200811170531470.est019_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (20, 'ES08-020', 'ESTRUDER - 020', '2008-11-17', NULL, '200811170533440.est020_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (21, 'ES08-021', 'ESTRUDER - 021', '2008-11-17', NULL, '200811170536160.est021_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (22, 'ES08-022', 'ESTRYDER - 022', '2008-11-17', NULL, '200811170536530.est022_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (23, 'ES08-023', 'ESTRUDER - 023', '2008-11-17', NULL, '200811170536380.est023_200.jpg', NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (24, 'ES08-024', 'ESTRUDER - 024', '2008-11-17', NULL, '200811170537010.est024_200.jpg', NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblfiringplan
INSERT INTO `tblfiringplan` (`ID`, `FiringPlanCode`, `FiringPlanDescription`, `FiringPlanDate`, `FiringPlanTechDraw`, `FiringPlanPhoto1`, `FiringPlanPhoto2`, `FiringPlanPhoto3`, `FiringPlanPhoto4`, `FiringPlanNotes`) VALUES (1, 'FP08-001', 'OXIDATION', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblfiringplan` (`ID`, `FiringPlanCode`, `FiringPlanDescription`, `FiringPlanDate`, `FiringPlanTechDraw`, `FiringPlanPhoto1`, `FiringPlanPhoto2`, `FiringPlanPhoto3`, `FiringPlanPhoto4`, `FiringPlanNotes`) VALUES (2, 'FP08-002', 'REDUCTION', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblfiringplan` (`ID`, `FiringPlanCode`, `FiringPlanDescription`, `FiringPlanDate`, `FiringPlanTechDraw`, `FiringPlanPhoto1`, `FiringPlanPhoto2`, `FiringPlanPhoto3`, `FiringPlanPhoto4`, `FiringPlanNotes`) VALUES (3, 'FP08-003', 'RAKU FIRING', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblglaze
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (1, 'GS08-001', 'TRANSPARENT GS08-001', '2008-11-06', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G4-074\r\n\r\nRECIPE :\r\n********\r\nREVISION 3 :\r\n============\r\n48 % POTASH FELDSPAR\r\n20.2 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n4.50 % ZINC OXIDE\r\n9.30 % KAOLIN\r\n------------------------------\r\n100 % TOTAL\r\n\r\nNOTES :\r\n1. GLAZE MADE ON 07-05-2007, GET RECIPE FROM LINE BLEND B4.AC.NO 29\r\n2. GLAZE GOOD\r\n3. DENSITY 1210 (NORMAL DIPPING)\r\n4. POSITION ON THE OVEN FROM TOP TILL BOTTOM\r\n**************************************************\r\n**************************************************\r\nREVISION 2 :\r\n============\r\n48 % POTASH FELDSPAR\r\n20.2 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n4.50 % ZINC OXIDE\r\n9.30 % KAOLIN\r\n-------------------------------\r\n100 % TOTAL\r\n\r\nNOTES :\r\n1. GLAZE MADE ON 03-04-2006\r\n2. GLAZE NOT GOOD (CRACK)\r\n3. DENSITY 1280 (NORMAL DIPPING)\r\n4. POSITION ON THE OVEN FROM MIDDLE TILL TOP\r\n**************************************************\r\n**************************************************\r\nREVISION 1 :\r\n============\r\n50 % POTASH FELDSPAR\r\n20 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n5 % ZINC OXIDE\r\n5 % KAOLIN\r\n-------------------------------\r\n98 % TOTAL\r\n\r\nNOTES :\r\n1. CHANGE PERCENTAGE ON 18-08-2005, ZINC OXIDE FROM 7% BECAME 5%\r\n2. GLAZE NOT GOOD (CRACK)\r\n3. DENSITY 1400 (NORMAL DIPPING)\r\n4. GLAZE FALL DOWN FAST IN BASKET\r\n5. POSITION ON THE OVEN FROM MIDDLE TILL TOP\r\n**************************************************\r\n**************************************************\r\nORIGINAL RECIPE :\r\n=================\r\n50 % POTASH FELDSPAR\r\n20 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n7 % ZINC OXIDE\r\n5 % KAOLIN\r\n-------------------------------\r\n100 % TOTAL');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (2, 'GM08-002', 'LIGHT GREY STONE GM08-002', '2008-11-06', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G8-002\r\n\r\nRECIPE :\r\n********\r\n36.1 % POTASH FELDSPAR\r\n15 % SILICA\r\n13.20 % WHITING/CALCIUM CARBONATE\r\n16.70 % KAOLIN\r\n13.20 % ZIRCOFAX/ZIRCOSIL FIVE/ZIRCONIUM SILICATE\r\n5.80 % MAGNESIUM\r\n------------------------------\r\n100 % TOTAL \r\n\r\n0.5 % BLACK STAIN\r\n1.13 % IRON OXIDE\r\n\r\nNOTES :\r\n1. GLAZE MADE ON 28-03-2008\r\n2. DENSITY 1230\r\n3. POSITION ON THE OVEN FROM MIDDLE TILL TOP');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (4, 'GM08-003', 'BROWN GM08-003', '2008-11-08', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G4-044\r\n\r\nRECIPE :\r\n********\r\nREVISION 2 :\r\n============ \r\n30 % POTASH FELDSPAR\r\n12 % SILICA\r\n15 % WHITING/CALCIUM CARBONATE\r\n6 % TITANIUM\r\n10 % KAOLIN\r\n7 % ZINC OXIDE\r\n------------------------------\r\n80 % TOTAL\r\n\r\n6.5 % MANGANESE -->SUP : MR. SIMON\r\n5 % IRON OXIDE -->SUP : MR. SIMON\r\n\r\nNOTES :\r\nDENSITY : 1180\r\n**************************************************\r\n**************************************************\r\nREVISION 1 :\r\n============ \r\n30 % POTASH FELDSPAR\r\n12 % SILICA\r\n15 % WHITING/CALCIUM CARBONATE\r\n6 % TITANIUM\r\n10 % KAOLIN\r\n7 % ZINC OXIDE\r\n------------------------------\r\n80 % TOTAL\r\n\r\n6.5 % MANGANESE \r\n5 % IRON OXIDE\r\n\r\nNOTES :\r\n1. DENSITY : 1230\r\n2. GLAZE DATE : 10/11/2005\r\n3. POSITION ON THE OVEN : MIDDLE TILL BOTTOM\r\n**************************************************\r\n**************************************************\r\nORIGINAL :\r\n============ \r\n30 % POTASH FELDSPAR\r\n12 % SILICA\r\n15 % WHITING/CALCIUM CARBONATE\r\n10 % ZINC OXIDE\r\n10 % KAOLIN\r\n6 % TITANIUM\r\n------------------------------\r\n83 % TOTAL\r\n\r\n13 % MANGANESE\r\n10 % IRON OXIDE');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (5, 'GM08-004', 'PORCELAIN UNGLAZED', '2008-11-13', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (6, 'GS08-005', 'DARK BLUE', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G5-082\r\n\r\nRECIPE :\r\n********\r\nREVISION 2 :\r\n============\r\n48 % POTASH FELDSPAR\r\n20.2 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n9.3 % KAOLIN\r\n4.5 % ZINC OXIDE\r\n------------------------------\r\n100 % TOTAL\r\n\r\n2 % COBALT OXIDE\r\n2 % IRON OXIDE\r\n1 % BENTONITE\r\n\r\nNOTES :\r\n1. GLAZE MADE ON 08-02-2006\r\n2. POSITION ON THE OVEN FROM MIDDLE TILL BOTTOM\r\n3. DENSITY : PORCELAIN 1400, CASTING 1400, STONEWARE 1400\r\n**************************************************\r\n************************************************** \r\nREVISION 1 :\r\n============\r\n50 % POTASH FELDSPAR\r\n20 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n5 % KAOLIN\r\n5 % ZINC OXIDE\r\n------------------------------\r\n98 % TOTAL\r\n\r\n2 % COBALT OXIDE\r\n2 % IRON OXIDE\r\n1 % BENTONITE\r\n\r\nNOTES :\r\n1. GLAZE MADE ON 03-10-2005\r\n2. GLAZE NOT GOOD (BUBBLE)\r\n**************************************************\r\n**************************************************\r\nORIGINAL :\r\n============\r\n50 % POTASH FELDSPAR\r\n20 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n5 % KAOLIN\r\n5 % ZINC OXIDE\r\n------------------------------\r\n98 % TOTAL\r\n\r\n2 % COBALT OXIDE\r\n2.5 % IRON OXIDE');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (7, 'GS08-006', 'TRANSPARENT RAKU', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G4-047\r\n\r\nRECIPE :\r\n********\r\nREVISION 1 :\r\n============\r\n50 % PRITTA CERDEC\r\n25 % LITTIUM/FONDENTE\r\n\r\nNOTES :\r\nCHANGE DENSITY FROM 1450 TO 1400 (NORMAL DIPPING)\r\n**************************************************\r\n************************************************** \r\nORIGINAL:\r\n============\r\n50 % PRITTA CERDEC\r\n25 % LITTIUM/FONDENTE\r\n\r\nNOTES :\r\n1. DENSITY 1450 (NORMAL DIPPING)\r\n2. RAKU FIRING (900�)');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (8, 'GS08-007', 'SENAPE', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G6-005\r\n\r\nRECIPE :\r\n********\r\nREVISION 1 :\r\n============\r\n42.79 % POTASH FELDSPAR\r\n24.58 % SILICA\r\n16.05 % WHITING/CALCIUM CARBONATE\r\n4.01 % ZINC OXIDE\r\n12.57 % KAOLIN\r\n------------------------------\r\n100 % TOTAL\r\n\r\n0.5 % C.500\r\n2 % IRON OXIDE\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1300\r\n2. GLAZE NOT CRACK, BUT FORMER CLIP TRACE WAS APPEAR ON THE PIECES AFTER FIRING.\r\n3. USING SPRAY TECHNIQUE, NOT DIPPING TO AVOID CLIP TRACE PROBLEM.\r\n4. POSITION ON THE OVEN FROM MIDDLE TILL TOP.\r\n**************************************************\r\n**************************************************\r\nORIGINAL :\r\n============\r\n48 % POTASH FELDSPAR\r\n20.2 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n4.5 % ZINC OXIDE\r\n9.3 % KAOLIN\r\n------------------------------\r\n100 % TOTAL\r\n\r\n0.5 % C.500\r\n2 % IRON OXIDE\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1280\r\n2. GLAZE CRACK AND FORMER CLIP TRACE WAS APPEAR ON THE PIECES AFTER FIRING.\r\n3. POSITION ON THE OVEN FROM MIDDLE TILL TOP.');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (9, 'GS08-008', 'LIGHT GREEN OLIVE', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G6-003\r\n\r\nRECIPE :\r\n********\r\n48 % POTASH FELDSPAR\r\n20.2 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n4.5 % ZINC OXIDE\r\n9.3 % KAOLIN\r\n------------------------------\r\n100 % TOTAL\r\n\r\n2 % IRON OXIDE\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1280\r\n2. GLAZE CRACK\r\n3. POSITION ON THE OVEN FROM TOP TILL BOTTOM.');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (10, 'GS08-009', 'DARK HONEY', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G6-004\r\n\r\nRECIPE :\r\n********\r\nREVISION 1 :\r\n============\r\n29.1 % POTASH FELDSPAR\r\n24.3 % SILICA\r\n11.6 % WHITING/CALCIUM CARBONATE\r\n4.8 % ZINC OXIDE\r\n14.6 % KAOLIN\r\n9.7 % TALC\r\n5.8 % BARIUM CARBONATE\r\n------------------------------\r\n100 % TOTAL\r\n\r\n5 % IRON OXIDE\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1200 (BIG ITEM), PORCELAIN 1230 (SMALL ITEM)\r\n2. GLAZE NOT CRACK, BUT THE COLOR BECOME LITTLE BIT YELLOW.\r\n3. GLAZE FALL DOWN IF TO THICK, AND SOMETIMES BUBBLE.\r\n4. POSITION ON THE OVEN FROM MIDDLE TILL BOTTOM.\r\n**************************************************\r\n**************************************************\r\nORIGINAL:\r\n============\r\n48 % POTASH FELDSPAR\r\n20.2 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n4.5 % ZINC OXIDE\r\n9.3 % KAOLIN\r\n------------------------------\r\n100 % TOTAL\r\n\r\n6 % IRON OXIDE\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1280\r\n2. GLAZE CRACK\r\n3. GLAZE FALL DOWN\r\n4. POSITION ON THE OVEN FROM MIDDLE TILL TOP.');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (11, 'GS08-010', 'BLUE CRYSTAL', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G6-007\r\n\r\nRECIPE :\r\n********\r\n39.57 % POTASH FELDSPAR\r\n15.70 % SILICA\r\n19.84 % WHITING/CALCIUM CARBONATE\r\n9.28 % ZINC OXIDE\r\n15.61 % KAOLIN\r\n------------------------------\r\n100 % TOTAL\r\n\r\n8.1 % TITANIUM\r\n0.5 % BLACK STAIN\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1240.\r\n2. BOTTOM OVEN POSITION.\r\n3. SOMETIMES GLAZE BECOME BUBBLE.\r\n4. CRYSTAL COLOR GLAZE.');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (12, 'GS08-011', 'GREEN CRYSTAL', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G6-006\r\n\r\nRECIPE :\r\n********\r\n39.57 % POTASH FELDSPAR\r\n15.70 % SILICA\r\n19.84 % WHITING/CALCIUM CARBONATE\r\n9.28 % ZINC OXIDE\r\n15.61 % KAOLIN\r\n------------------------------\r\n100 % TOTAL\r\n\r\n8.1 % TITANIUM\r\n4.3 % C.604\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1240.\r\n2. BOTTOM OVEN POSITION.\r\n3. GLAZE SOMETIMES BECOME BUBBLE.\r\n4. CRYSTAL COLOR GLAZE.');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (13, 'GM08-012', 'BLACK LEATHER', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G7-001\r\n\r\nRECIPE :\r\n********\r\n48 % POTASH FELDSPAR\r\n2 % SILICA\r\n20 % WHITING/CALCIUM CARBONATE\r\n25 % KAOLIN\r\n5 % TALC\r\n------------------------------\r\n100 % TOTAL\r\n\r\n3 % COPPER OXIDE\r\n\r\nNOTES :\r\n1. GLAZE CRACK.\r\n2. GLAZE COLOR LIKE FADED BLACK LEATHER.\r\n3. POSITION ON THE OVEN FROM MIDDLE TILL BOTTOM.');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (14, 'GM08-013', 'DARK GREEN', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G4-023\r\n\r\nRECIPE :\r\n********\r\n48 % POTASH FELDSPAR\r\n10 % SILICA\r\n20 % WHITING/CALCIUM CARBONATE\r\n5 % TALC\r\n22 % KAOLIN\r\n------------------------------\r\n105 % TOTAL\r\n\r\n2 % C.500\r\n\r\nNOTES :\r\n1. GLAZE CRACK.\r\n2. POSITION ON THE OVEN FROM MIDDLE TILL BOTTOM.');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (15, 'GM08-014', 'TURQUOISE', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G4-030\r\n\r\nRECIPE :\r\n********\r\n48 % POTASH FELDSPAR\r\n10 % SILICA\r\n20 % WHITING/CALCIUM CARBONATE\r\n22 % KAOLIN\r\n5 % TALC\r\n------------------------------\r\n105 % TOTAL\r\n\r\n5 % C.446\r\nNOTES :\r\n1. DENSITY : STONEWARE 1440.\r\n2. GLAZE CRACK.\r\n3. POSITION ON THE OVEN FROM MIDDLE TILL BOTTOM.');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (16, 'GM08-015', 'BLUE', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G4-025\r\n\r\nRECIPE :\r\n********\r\n48 % POTASH FELDSPAR\r\n10 % SILICA\r\n20 % WHITING/CALCIUM CARBONATE\r\n22 % KAOLIN\r\n5 % TALC\r\n------------------------------\r\n105 % TOTAL\r\n\r\n2 % C.410\r\n\r\nNOTES :\r\n1. DENSITY : STONEWARE 1440.\r\n2. POSITION ON THE OVEN FROM MIDDLE TILL BOTTOM.\r\n3. GLAZE CRACK.');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (17, 'GS08-016', 'CHAMPAGNE', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G6-002\r\n\r\nRECIPE :\r\n********\r\nREVISION 2 :\r\n============\r\n29.1 % POTASH FELDSPAR\r\n24.3 % SILICA\r\n11.6 % WHITING/CALCIUM CARBONATE\r\n4.8 % ZINC OXIDE\r\n14.6 % KAOLIN\r\n9.7 % TALC\r\n5.8 % BARIUM CARBONATE\r\n------------------------------\r\n100 % TOTAL\r\n\r\n1 % IRON OXIDE\r\n1 % MANGANESE OXIDE\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1220.\r\n2. GLAZE NOT CRACK, BUT FORMER CLIP TRACE WHEN DIPPING, APPEAR ON THE PIECES AFTER FIRING\r\n3. POSITION ON THE OVEN FROM MIDDLE TILL TOP.\r\n**************************************************\r\n**************************************************\r\nREVISION 1 :\r\n============\r\n48 % POTASH FELDSPAR\r\n20.2 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n4.5 % ZINC OXIDE\r\n9.3 % KAOLIN\r\n------------------------------\r\n100 % TOTAL\r\n\r\n1 % IRON OXIDE\r\n1 % MANGANESE OXIDE\r\n\r\nNOTES :\r\nGLAZE CRACK\r\n**************************************************\r\n**************************************************\r\nREVISION 2 :\r\n============\r\n50 % POTASH FELDSPAR\r\n20 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n5 % ZINC OXIDE\r\n5 % KAOLIN\r\n------------------------------\r\n98 % TOTAL\r\n\r\n1 % IRON OXIDE\r\n1 % MANGANESE OXIDE\r\n\r\nNOTES :\r\nGLAZE CRACK');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (18, 'GM08-017', 'BLACK', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G4-053\r\n\r\nRECIPE :\r\n********\r\nREVISION 1 :\r\n============\r\n36.10 % POTASH FELDSPAR\r\n15 % SILICA\r\n13.20 % WHITING/CALCIUM CARBONATE\r\n16.7 % KAOLIN\r\n13.20 % ZIRCOFAX/ZIRCOSIL FIVE/ZIRCONIUM SILICATE\r\n5.80 % MAGNESIUM\r\n-------------------------------------------------\r\n100 % TOTAL\r\n\r\n4 % BLACK STAIN\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1250, STONEWARE 1250.\r\n2. GLAZE GOOD.\r\n4. POSITION ON THE OVEN FROM BOTTOM TILL TOP (FREE).\r\n**************************************************\r\n**************************************************\r\nORIGINAL :\r\n============\r\n48 % POTASH FELDSPAR\r\n10 % SILICA\r\n20 % WHITING/CALCIUM CARBONATE\r\n22 % KAOLIN\r\n5 % TALC\r\n-------------------------------------------------\r\n105 % TOTAL\r\n\r\n2 % BLACK STAIN');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (19, 'GS08-018', 'LIGHT BLUE_01', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G5-076\r\n\r\nRECIPE :\r\n********\r\nREVISION 1 :\r\n============\r\n48 % POTASH FELDSPAR\r\n20.2 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n4.5 % ZINC OXIDE\r\n9.3 % KAOLIN\r\n------------------------------\r\n100 % TOTAL\r\n\r\n3 % C.446\r\n\r\nNOTES :\r\n1. DENSITY : STONEWARE 1380\r\n2. GLAZE CRACK\r\n**************************************************\r\n**************************************************\r\nORIGINAL :\r\n============\r\n50 % POTASH FELDSPAR\r\n20 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n5 % ZINC OXIDE\r\n5 % KAOLIN\r\n------------------------------\r\n98 % TOTAL\r\n\r\n3 % C.446\r\n\r\nNOTES :\r\nGLAZE CRACK');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (20, 'GS08-019', 'DARK BLACK', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G5-083\r\n\r\nRECIPE :\r\n********\r\nREVISION 1 :\r\n============\r\n48 % POTASH FELDSPAR\r\n20.2 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n4.5 % ZINC OXIDE\r\n9.3 % KAOLIN\r\n------------------------------\r\n100 % TOTAL\r\n\r\n4 % BLACK STAIN\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1280\r\n2. GLAZE CRACK.\r\n3. POSITION ON THE OVEN FROM BOTTOM TILL TOP (FREE)\r\n**************************************************\r\n**************************************************\r\nORIGINAL :\r\n============\r\n50 % POTASH FELDSPAR\r\n20 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n5 % ZINC OXIDE\r\n5 % KAOLIN\r\n------------------------------\r\n98 % TOTAL\r\n\r\n4 % BLACK STAIN');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (21, 'GS08-020', 'LIGHT BLUE_02', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G5-078\r\n\r\nRECIPE :\r\n********\r\nREVISION 1 :\r\n============\r\n48 % POTASH FELDSPAR\r\n20.2 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n4.5 % ZINC OXIDE\r\n9.3 % KAOLIN\r\n------------------------------\r\n100 % TOTAL\r\n\r\n1 % C.410\r\n\r\nNOTES :\r\n1. GLAZE CRACK\r\n2. POSITION ON THE OVEN FROM MIDDLE TILL TOP.\r\n**************************************************\r\n**************************************************\r\nORIGINAL :\r\n============\r\n50 % POTASH FELDSPAR\r\n20 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n5 % ZINC OXIDE\r\n5 % KAOLIN\r\n------------------------------\r\n98 % TOTAL\r\n\r\n1 % C.410\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1400\r\n2. GLAZE CRACK');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (22, 'GS08-021', 'LIGHT GREY', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G5-079\r\n\r\nRECIPE :\r\n********\r\nREVISION 1 :\r\n============\r\n48 % POTASH FELDSPAR\r\n20.2 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n4.5 % ZINC OXIDE\r\n9.3 % KAOLIN\r\n------------------------------\r\n100 % TOTAL\r\n\r\n0.5 % C.500\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1340.\r\n2. GLAZE CRACK.\r\n3. MIDDLE OVEN POSITION\r\n**************************************************\r\n**************************************************\r\nORIGINAL :\r\n============\r\n50 % POTASH FELDSPAR\r\n20 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n5 % ZINC OXIDE\r\n5 % KAOLIN\r\n------------------------------\r\n98 % TOTAL\r\n\r\n0.5 % C.500\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1400.\r\n2. GLAZE CRACK.');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (23, 'GS08-022', 'ASH CELADON', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G8-004\r\n\r\nRECIPE :\r\n********\r\n41.2 % POTASH FELDSPAR\r\n29.3 % SILICA\r\n11.5 % WHITING/CALCIUM CARBONATE\r\n3.8 % DOLOMITE\r\n3.8 % ZINC OXIDE\r\n7.5 % KAOLIN\r\n1.9 % BENTONITE\r\n1 % TALC\r\n------------------------------\r\n100 % TOTAL\r\n\r\n0.5 % MANGANESE OXIDE\r\n1 % COPPER OXIDE\r\n0.6 % C.500\r\n0.33 CC CUKA\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1320\r\n2. POSITION ON THE OVEN FROM BOTTOM TILL TOP.');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (24, 'GS08-023', 'LIGHT PINK', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G5-084\r\n\r\nRECIPE :\r\n********\r\nREVISION 1 :\r\n============\r\n48 % POTASH FELDSPAR\r\n20.2 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n4.5 % ZINC OXIDE\r\n9.3 % KAOLIN\r\n------------------------------\r\n100 % TOTAL\r\n\r\n1 % CF.129/P\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1280\r\n2. GLAZE CRACK\r\n2. POSITION ON THE OVEN FROM MIDDLE TILL BOTTOM.\r\n**************************************************\r\n**************************************************\r\nORIGINAL :\r\n============\r\n50 % POTASH FELDSPAR\r\n20 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n5 % ZINC OXIDE\r\n5 % KAOLIN\r\n------------------------------\r\n98 % TOTAL\r\n\r\n1 % CF.129/P\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1400\r\n2. GLAZE CRACK\r\n2. POSITION ON THE OVEN FROM MIDDLE TILL BOTTOM.');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (25, 'GS08-024', 'GREEN FOREST', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G5-085\r\n\r\nRECIPE :\r\n********\r\nREVISION 2 :\r\n=============\r\n41.2 % POTASH FELDSPAR\r\n29.3 % SILICA\r\n11.5 % WHITING/CALCIUM CARBONATE\r\n3.8 % DOLOMITE\r\n3.8 % ZINC OXIDE\r\n7.5 % KAOLIN\r\n1.9 % BENTONITE\r\n1 % TALC\r\n------------------------------\r\n100 % TOTAL\r\n\r\n3 % COPPER OXIDE\r\n0.33 CC CUKA\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1320, RAKU 1390\r\n2. POSITION ON THE OVEN FROM MIDDLE TILL TOP.\r\n3. NO CRACK\r\n**************************************************\r\n**************************************************\r\nREVISION 1 :\r\n============\r\n48 % POTASH FELDSPAR\r\n20.2 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n4.5 % ZINC OXIDE\r\n9.3 % KAOLIN\r\n------------------------------\r\n100 % TOTAL\r\n\r\n3 % COPPER OXIDE\r\n\r\nNOTES :\r\n1. DENSITY : 1280\r\n2. POSITION ON THE OVEN FROM MIDDLE TILL TOP.\r\n3. GLAZE CRACK.\r\n**************************************************\r\n**************************************************\r\nORIGINAL :\r\n==========\r\n50 % POTASH FELDSPAR\r\n20 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n5 % ZINC OXIDE\r\n5 % KAOLIN\r\n------------------------------\r\n98 % TOTAL\r\n\r\n3 % COPPER OXIDE\r\n\r\nNOTES :\r\n1. DENSITY : 1400\r\n2. POSITION ON THE OVEN FROM MIDDLE TILL TOP.\r\n3. GLAZE CRACK');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (26, 'GS08-025', 'RAKU TURQUOISE', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G4-048\r\n\r\nRECIPE :\r\n========\r\n50 % PRITTA \r\n25  % LITTIUM\r\n--------------\r\n75  % TOTAL\r\n\r\n2 % COPPER OXIDE\r\n\r\nNOTES :\r\n1. RAKU FIRING (900�)\r\n2. DENSITY 1510 ');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (27, 'GM08-026', 'WHITE', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G4-032\r\n\r\nRECIPE :\r\n********\r\nREVISION 1 :\r\n=============\r\n36.10 % POTASH FELDSPAR\r\n15.00 % SILICA\r\n13.20 % WHITING/CALCIUM CARBONATE\r\n16.70 % KAOLIN\r\n13.20 % ZIRCOFAX/ZIRCOSIL FIVE/ZIRCONIUM SILICATE\r\n5.80 % MAGNESIUM\r\n-------------------\r\n100 % TOTAL\r\n\r\n0.8 % IRON OXIDE\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1280, STONEWARE 1310.\r\n2. POSITION ON THE OVEN FROM MIDDLE TILL TOP.\r\n3. BASE GLAZE TAKEN FROM DOF MOON RECIPE.\r\n**************************************************\r\n**************************************************\r\nORIGINAL :\r\n=============\r\n48 % POTASH FELDSPAR\r\n10 % SILICA\r\n20 % WHITING/CALCIUM CARBONATE\r\n22 % KAOLIN\r\n5 % TALC\r\n-------------------\r\n105 % TOTAL\r\n\r\nNOTES :\r\n1. POSITION ON THE OVEN FROM MIDDLE TILL BOTTOM.\r\n2. GLAZE CRACK.');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (35, 'GM08-032', 'STONEWARE UNGLAZED', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (28, 'GS08-027', 'LIGHT BLUE_03', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G5-077\r\n\r\nRECIPE :\r\n********\r\nREVISION 1 :\r\n=============\r\n48 % POTASH FELDSPAR\r\n20.2 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n4.5 % ZINC OXIDE\r\n9.3 % KAOLIN\r\n------------------------------\r\n100 % TOTAL\r\n\r\n0.2 % C.410\r\n**************************************************\r\n**************************************************\r\nORIGINAL :\r\n=============\r\n50 % POTASH FELDSPAR\r\n20 % SILICA\r\n18 % WHITING/CALCIUM CARBONATE\r\n5 % ZINC OXIDE\r\n5 % KAOLIN\r\n------------------------------\r\n98 % TOTAL\r\n\r\n0.2 % C.410');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (29, 'GM08-028', 'LIGHT GREEN', '2008-11-13', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G4-019\r\n\r\nRECIPE :\r\n********\r\n48 % POTASH FELDSPAR\r\n10 % SILICA\r\n20 % WHITING/CALCIUM CARBONATE\r\n22 % KAOLIN\r\n5 % TALC\r\n------------------------------\r\n105 % TOTAL\r\n\r\n3 % C.446\r\n\r\nNOTES :\r\n1. POSITION ON THE OVEN FROM MIDDLE TILL BOTTOM.\r\n2. GLAZE CRACK.');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (36, 'GM08-033', 'RAKU UNGLAZED', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (37, 'GS09-004', 'CARAMEL_2', '2009-01-10', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (31, 'GS08-029', 'DARK BROWN', '2008-11-18', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G6-001\r\n\r\nREVISION 1 :\r\n************\r\n48 % POTASH FELDSPAR\r\n9.3 % KAOLIN\r\n18 % CALCIUM CARBONATE\r\n4.5 % ZINC OXIDE\r\n20.2 % SILICA\r\n------------------------------\r\n100 % TOTAL\r\n\r\n2 % BLACK STAIN\r\n1 % IRON OXIDE\r\n\r\nNOTE :\r\nNEW DENSITY 1330, BEFORE 1290-1310\r\n**************************************************\r\n**************************************************\r\nORIGINAL :\r\n**********\r\n50 % POTASH FELDSPAR\r\n5 % KAOLIN\r\n18 % CALCIUM CARBONATE\r\n5 % ZINC OXIDE\r\n20 % SILICA\r\n------------------------------\r\n98 % TOTAL\r\n\r\n2 % BLACK STAIN\r\n1 % IRON OXIDE');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (32, 'GM08-030', 'CAPPUCINO', '2008-11-18', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G8-003\r\n\r\nRECIPE :\r\n********\r\n36.10 % POTASH FELDSPAR\r\n15.00 % SILICA\r\n13.20 % WHITING/CALCIUM CARBONATE\r\n16.70 % KAOLIN\r\n13.20 % ZIRCOFAX/ZIRCOSIL FIVE/ZIRCONIUM SILICATE\r\n5.80 % MAGNESIUM\r\n-------------------\r\n100 % TOTAL\r\n\r\n0.5 % CHROME OXIDE\r\n\r\nNOTES :\r\n1. DENSITY : PORCELAIN 1230.\r\n2. GLAZE MADE ON 09-06-2008, AND RECIPE WAS TAKEN FROM RECIPE M.27 ARMANI');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (33, 'GM08-031', 'ASH CELADON', '2008-11-18', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G8-005\r\n\r\nRECIPE :\r\n********\r\n36.10 % POTASH FELDSPAR\r\n15.00 % SILICA\r\n13.20 % WHITING/CALCIUM CARBONATE\r\n16.70 % KAOLIN\r\n13.20 % ZIRCOFAX/ZIRCOSIL FIVE/ZIRCONIUM SILICATE\r\n5.80 % MAGNESIUM\r\n-------------------\r\n100 % TOTAL\r\n\r\n3 % COPPER OXIDE\r\n0.5 % MANGANESE OXIDE\r\n\r\nNOTE :\r\n1. GLAZE MADE ON 26-06-2008.\r\n2. DENSITY PORCELAIN 1320.');


# dumping data for GayaFusionAll.tblreference
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (1, '20081118064637', 1, 24, NULL);
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (2, '20081223013621', 6, 39, NULL);
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (3, '20081223013808', 2, 40, NULL);
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (4, '20081223021646', 5, 41, NULL);
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (5, '20081223021825', 3, 42, NULL);
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (6, '20081223022034', 12, 43, NULL);
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (7, '20081223022146', 12, 44, NULL);
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (8, '20081223022244', 12, 45, NULL);
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (9, '20081223032015', 13, 48, NULL);
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (10, '20081223032609', 14, 49, NULL);
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (11, '20081223035003', 4, 50, NULL);
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (12, '20081223035628', 16, 51, NULL);
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (13, '20081224011945', 17, 52, NULL);


# dumping data for GayaFusionAll.tblstainoxide
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (1, 'SX08-001', 'BLACK STAIN', '2008-11-08', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n70 % BLACK STAIN\r\n30 % TRANSPARENT\r\n--------\r\n100% TOTAL \r\n\r\n\r\nNOTE :\r\n* OLD CODE 67.007 AND CHANGED SX08-001\r\n* USE FOR DECORATION BLACK BRUSH BOWL ');
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (2, 'SX08-002', 'CF.129/P', '2008-11-17', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n70 % CF.129/P\r\n30 % DRY TRANSPARENT\r\n---------\r\n100% TOTAL\r\n\r\n\r\nNOTES :\r\n* OLD CODE 67.006 AND CHANGED SX08-002\r\n* USE FOR DECORATION VALLETE\r\n');
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (3, 'SX08-003', 'C.410', '2008-11-17', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n100 % C.410\r\n--------\r\n100% TOTAL\r\n\r\n\r\nNOTES :\r\n* USE FOR DECORATION\r\n* MATERIAL HANYA COLOR C.410');
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (4, 'SX08-004', 'C.500', '2008-11-17', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n100 % C.500\r\n--------\r\n100% total\r\n\r\nNOTES :\r\n* USE FOR DECORATION\r\n* MATERIAL HANYA COLOR C.500');
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (5, 'SX08-005', 'C.604', '2008-11-17', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n100 % C.604\r\n--------\r\n100% TOTAL\r\n\r\n\r\nNOTE :\r\n* USE FOR DECORATION AND ADD WATER AS NEEDED\r\n* MATERIAL HANYA C.604');
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (6, 'SX08-006', 'C.F4/410', '2008-11-17', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n100 % C.F4/410\r\n--------\r\n100% TOTAL\r\n\r\nNOTE :\r\n* USE FOR DECORATION AND ADD WATER AS NEEDED\r\n* MATERIAL HANYA C.F4/410');
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (7, 'SX08-007', 'C.446', '2008-11-17', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n100 % C.446\r\n--------\r\n100% TOTAL\r\n\r\nNOTE :\r\n* USE FOR DECORATION\r\n* MATERIAL HANYA C.446\r\n* WARNA YANG DITIMBULKAN ADALAH  TOURQISE');
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (8, 'SX08-008', 'IRON OXIDE', '2008-11-17', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n100% IRON OXIDE\r\n--------\r\n100% TOTAL\r\n--------\r\n\r\nRECIPE FOR BVLGARI VESSEL DECORATIVE :\r\n60 % IRON OXIDE\r\n40 % DRY TRANSPARENT\r\n\r\n\r\nNOTE :\r\n\r\n* MIX WITH WATER IF USE FOR DECORATION.\r\n* WARNA YANG DITIMBULKAN SETELAH FIRING COKLAT MUDA SAMPAI TUA');
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (9, 'SX08-009', 'COPPER OXIDE', '2008-11-17', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n100% COPPER OXIDE\r\n--------\r\n100% TOTAL\r\n\r\nNOTE :\r\n* MIX WITH WATER IF USE FOR DECORATION.\r\n* WARNA YANG DITIMBULKAN SETELAH FIRING HIJAU MUDA SAMPAI HITAM');
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (10, 'SX08-010', 'MANGANESE OXIDE', '2008-11-17', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n100% MANGANESE OXIDE\r\n--------\r\n100% TOTAL\r\n\r\nNOTE :\r\n* USE FOR RAKU DECORATION.\r\n* WARNA YANG DITIMBULKAN KUNING KECOKLATAN');
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (11, 'SX08-011', 'COBALT OXIDE', '2008-11-17', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n100% COBALT OXIDE\r\n--------\r\n100% TOTAL \r\n\r\n\r\nNOTE :\r\n* USE AS GLAZE RECIPE.\r\n* WARNA YANG DITIMBULKAN SETELAH BAKAR BIRU MUDA SAMPAI TUA.');
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (12, 'SX08-012', 'CROME OXIDE', '2008-11-17', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n100% CRHOME OXIDE\r\n--------\r\n100% TOTAL\r\n\r\n\r\nNOTE :\r\n* USE AS ENGOBE RECIPE.\r\n* WARNA YANG DITIMBULKAN SETELAH BAKAR ADALAH COKLAT MUDA/CREM\r\n');
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (13, 'SX08-013', 'RED COPPER REDUCTION', '2008-11-20', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G7-005\r\n\r\nRECIPE :\r\n********\r\n70 % COPPER OXIDE\r\n20 % PRITTA\r\n10 % IRON OXIDE\r\n------------------------------\r\n100 % TOTAL\r\n\r\nNOTE :\r\n1. OLD CODE 67.005 AND CHANGED SX08-013\r\n2. WARNA YANG DITIMBULKAN ABSTRAK DAN DIBAKAR PADA\r\n   OPEN RAKU  ');
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (14, 'SX08-014', 'COFFE', '2008-11-20', NULL, NULL, NULL, NULL, NULL, 'OLD GLAZE CODE : G8-006\r\n\r\nRECIPE :\r\n********\r\n30 % LITTIUM\r\n70 % IRON OXIDE\r\n20 % MANGANESE OXIDE\r\n-------------------\r\n120 % TOTAL\r\n\r\nNOTE :\r\n* THIS COLOUR WAS MADE ON 09-10-2008.\r\n* THIS COLOUR IS FOR RAKU DECORATION.\r\n* IF COLOUR TO THICK, IT WILL BECAME BLACK.\r\n* WARNA YANG DITIMBULKAN COKLAT KEKUNING-KUNINGAN(KILAP)');
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (15, 'SX08-015', 'IRON OXIDE+TRANSPARENT', '2008-12-27', NULL, NULL, NULL, NULL, NULL, 'RECIPE :\r\n========\r\n60% IRON OXIDE\r\n40% DRY TRANSPATENT(TRANSPARENT KERING)\r\n-------\r\n100% TOTAL\r\n\r\nNOTE :\r\n* WARNA YANG DITIMBULKAN SETELAH DIBAKAR COKLAT KEMERAHAN.');


# dumping data for GayaFusionAll.tblsupplier
INSERT INTO `tblsupplier` (`ID`, `SupCode`, `SupCompany`, `SupContact`, `SupAddress`, `SupHP`, `SupOffice`, `SupFax`, `SupEmail`, `SupItems`, `SupOtherInfo`) VALUES (1, 'SU08-001', 'ARTHA SILVER', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblsupplier` (`ID`, `SupCode`, `SupCompany`, `SupContact`, `SupAddress`, `SupHP`, `SupOffice`, `SupFax`, `SupEmail`, `SupItems`, `SupOtherInfo`) VALUES (2, 'SU08-002', 'TOKO BALE AGUNG', 'PAK AGUNG ???', 'JL. RAYA SESETAN, NO. 221 E', NULL, '(0361)-727972/727978', NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tbltexture
INSERT INTO `tbltexture` (`ID`, `TextureCode`, `TextureDescription`, `TextureDate`, `TextureTechDraw`, `TexturePhoto1`, `TexturePhoto2`, `TexturePhoto3`, `TexturePhoto4`, `TextureNotes`) VALUES (1, 'TX08-001', 'SMOOTH', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbltexture` (`ID`, `TextureCode`, `TextureDescription`, `TextureDate`, `TextureTechDraw`, `TexturePhoto1`, `TexturePhoto2`, `TexturePhoto3`, `TexturePhoto4`, `TextureNotes`) VALUES (2, 'TX08-002', 'CIRCULAR LINE', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbltexture` (`ID`, `TextureCode`, `TextureDescription`, `TextureDate`, `TextureTechDraw`, `TexturePhoto1`, `TexturePhoto2`, `TexturePhoto3`, `TexturePhoto4`, `TextureNotes`) VALUES (5, 'TX08-003', 'GENTENG', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbltexture` (`ID`, `TextureCode`, `TextureDescription`, `TextureDate`, `TextureTechDraw`, `TexturePhoto1`, `TexturePhoto2`, `TexturePhoto3`, `TexturePhoto4`, `TextureNotes`) VALUES (6, 'TX08-004', 'HAND TROWED', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbltexture` (`ID`, `TextureCode`, `TextureDescription`, `TextureDate`, `TextureTechDraw`, `TexturePhoto1`, `TexturePhoto2`, `TexturePhoto3`, `TexturePhoto4`, `TextureNotes`) VALUES (7, 'TX08-005', 'MEDIUM HAND-TROWED', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbltexture` (`ID`, `TextureCode`, `TextureDescription`, `TextureDate`, `TextureTechDraw`, `TexturePhoto1`, `TexturePhoto2`, `TexturePhoto3`, `TexturePhoto4`, `TextureNotes`) VALUES (8, 'TX08-006', 'ROUGH HAND-TROWED', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbltexture` (`ID`, `TextureCode`, `TextureDescription`, `TextureDate`, `TextureTechDraw`, `TexturePhoto1`, `TexturePhoto2`, `TexturePhoto3`, `TexturePhoto4`, `TextureNotes`) VALUES (9, 'TX08-007', 'BAMBOO', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tbltools
INSERT INTO `tbltools` (`ID`, `ToolsCode`, `ToolsDescription`, `ToolsDate`, `ToolsTechDraw`, `ToolsPhoto1`, `ToolsPhoto2`, `ToolsPhoto3`, `ToolsPhoto4`, `ToolsNotes`) VALUES (1, 'TL08-001', 'KNIFE', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblunit
INSERT INTO `tblunit` (`UnitID`, `UnitValue`) VALUES ('01', 'GR');
INSERT INTO `tblunit` (`UnitID`, `UnitValue`) VALUES ('02', 'KG');
INSERT INTO `tblunit` (`UnitID`, `UnitValue`) VALUES ('03', 'PCS');


# dumping data for GayaFusionAll.tbluser
INSERT INTO `tbluser` (`id`, `UserName`, `LastName`, `FirstName`, `Password`, `Type`) VALUES (12, 'marcello', 'Massoni', 'Marcello', '31467345736caba361a25d3c09a127df', 'Costing');
INSERT INTO `tbluser` (`id`, `UserName`, `LastName`, `FirstName`, `Password`, `Type`) VALUES (13, 'admin', 'boongan', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin');
INSERT INTO `tbluser` (`id`, `UserName`, `LastName`, `FirstName`, `Password`, `Type`) VALUES (14, 'rizma', 'Shanti', 'Rizma', 'd8b80c94e5636f57fc11c7b501b69441', 'Admin');
INSERT INTO `tbluser` (`id`, `UserName`, `LastName`, `FirstName`, `Password`, `Type`) VALUES (15, 'madeadi', 'Saputra', 'Made Adi', '9fd478b47a61aeffc744ee55742fb0b7', 'RnD');
INSERT INTO `tbluser` (`id`, `UserName`, `LastName`, `FirstName`, `Password`, `Type`) VALUES (16, 'madegun', 'Gunawan', 'Made', '714400c0a4331c134cd6b82f79e6c9a5', 'RnD');
INSERT INTO `tbluser` (`id`, `UserName`, `LastName`, `FirstName`, `Password`, `Type`) VALUES (17, 'rani', 'Arriani', 'Arriani', '25982691ac9455cdbd9be17a71a51c72', 'Administration');


