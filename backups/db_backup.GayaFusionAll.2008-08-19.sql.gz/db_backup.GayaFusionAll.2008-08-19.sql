# backupDB() v1.1.31 (http://www.silisoftware.com)
# mySQL backup (August 19, 2008 1:03 am)   Type = Complete

CREATE TABLE `GayaFusionAll`.`sampleceramic` (
  `sID` int(10) NULL auto_increment,
  `SampleCode` varchar(12) NULL,
  `SampleDescription` varchar(100) NULL,
  `ClientCode` varchar(20) NULL,
  `ClientDescription` varchar(50) NULL,
  `SampleDate` date NULL,
  `TechDraw` varchar(50) NULL,
  `Photo1` varchar(50) NULL,
  `Photo2` varchar(50) NULL,
  `Photo3` varchar(50) NULL,
  `Photo4` varchar(50) NULL,
  `RefID` int(11) NULL,
  `Clay` int(11) NULL,
  `ClayKG` decimal(10,0) NULL,
  `ClayNote` text NULL,
  `BuildTech` varchar(50) NULL,
  `BuildTechNote` text NULL,
  `Rim` varchar(30) NULL,
  `Feet` varchar(30) NULL,
  `Casting1` int(11) NULL,
  `Casting2` int(11) NULL,
  `Casting3` int(11) NULL,
  `Casting4` int(11) NULL,
  `CastingNote` text NULL,
  `Estruder1` int(11) NULL,
  `Estruder2` int(11) NULL,
  `Estruder3` int(11) NULL,
  `Estruder4` int(11) NULL,
  `EstruderNote` text NULL,
  `Texture1` int(11) NULL,
  `Texture2` int(11) NULL,
  `Texture3` int(11) NULL,
  `Texture4` int(11) NULL,
  `TextureNote` text NULL,
  `Tools1` int(11) NULL,
  `Tools2` int(11) NULL,
  `Tools3` int(11) NULL,
  `Tools4` int(11) NULL,
  `ToolsNote` text NULL,
  `Engobe1` int(11) NULL,
  `Engobe2` int(11) NULL,
  `Engobe3` int(11) NULL,
  `Engobe4` int(11) NULL,
  `EngobeNote` text NULL,
  `BisqueTemp` varchar(10) NULL,
  `StainOxide1` int(11) NULL,
  `StainOxide2` int(11) NULL,
  `StainOxide3` int(11) NULL,
  `StainOxide4` int(11) NULL,
  `StainOxideNote` text NULL,
  `Glaze1` int(11) NULL,
  `Glaze2` int(11) NULL,
  `Glaze3` int(11) NULL,
  `Glaze4` int(11) NULL,
  `GlazeDensity1` varchar(10) NULL,
  `GlazeDensity2` varchar(10) NULL,
  `GlazeDensity3` varchar(10) NULL,
  `GlazeDensity4` varchar(10) NULL,
  `GlazeNote` text NULL,
  `GlazeTemp` varchar(10) NULL,
  `Firing` varchar(10) NULL default 'Oxidation',
  `FiringNote` text NULL,
  `Width` decimal(10,2) NULL,
  `Height` decimal(10,2) NULL,
  `Length` decimal(10,2) NULL,
  `Diameter` decimal(10,2) NULL,
  `FinalSizeNote` text NULL,
  `DesignMat1` int(11) NULL,
  `DesignMat2` int(11) NULL,
  `DesignMat3` int(11) NULL,
  `DesignMat4` int(11) NULL,
  `DesignMatQty1` int(10) NULL,
  `DesignMatQty2` int(10) NULL,
  `DesignMatQty3` int(10) NULL,
  `DesignMatQty4` int(10) NULL,
  `DesignMatNote` text NULL,
  `History` text NULL,
  `ClayType` int(11) NULL,
  `ClayCost` decimal(10,2) NULL default '0.00',
  `ClayPreparationMinute` int(11) NULL,
  `ClayPreparationCost` decimal(10,2) NULL default '0.00',
  `WheelMinute` int(11) NULL,
  `WheelCost` decimal(10,2) NULL default '0.00',
  `SlabMinute` int(11) NULL,
  `SlabCost` decimal(10,2) NULL default '0.00',
  `CastingMinute` int(11) NULL,
  `CastingCost` int(11) NULL,
  `FinishingMinute` int(11) NULL,
  `FinishingCost` double NULL,
  `GlazingMinute` int(11) NULL,
  `GlazingCost` double NULL,
  `StandardBisqueLoading` int(11) NULL,
  `StandardBisqueCost` double NULL,
  `StandardGlazeLoading` int(11) NULL,
  `StandardGlazeCost` double NULL,
  `RakuBisqueLoading` int(11) NULL,
  `RakuBisqueCost` double NULL,
  `RakuGlazeLoading` int(11) NULL,
  `RakuGlazeCost` double NULL,
  `MovementMinute` int(11) NULL,
  `MovementCost` double NULL,
  `PackagingWorkMinute` int(11) NULL,
  `PackagingWorkCost` double NULL,
  `ClayPreparationPPH` int(11) NULL,
  `WheelPPH` int(11) NULL,
  `SlabPPH` int(11) NULL,
  `CastingPPH` int(11) NULL,
  `FinishingPPH` int(11) NULL,
  `GlazingPPH` int(11) NULL,
  `MovementPPH` int(11) NULL,
  `PackagingWorkPPH` int(11) NULL,
  `TotalAllCost` double NULL,
  `RiskPrice` double NULL,
  `HypoSellingPrice` decimal(10,2) NULL default '0.00',
  `RealSellingPrice` decimal(10,2) NULL default '0.00',
  PRIMARY KEY (`sID`),
  UNIQUE KEY `SampleCode` (`SampleCode`)
) TYPE=MyISAM AUTO_INCREMENT=15;

CREATE TABLE `GayaFusionAll`.`sampleother` (
  `ID` int(10) NULL auto_increment,
  `SampleCode` varchar(12) NULL,
  `Description` varchar(50) NULL,
  `SampleDate` date NULL default '0000-00-00',
  `TechDraw` varchar(50) NULL,
  `Photo1` varchar(50) NULL,
  `Photo2` varchar(50) NULL,
  `Photo3` varchar(50) NULL,
  `Photo4` varchar(50) NULL,
  `DesMat1` int(11) NULL,
  `DesMat2` int(11) NULL,
  `DesMat3` int(11) NULL,
  `DesMat4` int(11) NULL,
  `DesMat5` int(11) NULL,
  `QtyDesMat1` int(11) NULL,
  `QtyDesMat2` int(11) NULL,
  `QtyDesMat3` int(11) NULL,
  `QtyDesMat4` int(11) NULL,
  `QtyDesMat5` int(11) NULL,
  `TotalDesMat1` decimal(10,0) NULL,
  `TotalDesMat2` decimal(10,0) NULL,
  `TotalDesMat3` decimal(10,0) NULL,
  `TotalDesMat4` decimal(10,0) NULL,
  `TotalDesMat5` decimal(10,0) NULL,
  `Supplier1` int(11) NULL,
  `Supplier2` int(11) NULL,
  `Supplier3` int(11) NULL,
  `Supplier4` int(11) NULL,
  `Supplier5` int(11) NULL,
  `Material1` varchar(50) NULL,
  `Material2` varchar(50) NULL,
  `Material3` varchar(50) NULL,
  `Material4` varchar(50) NULL,
  `Material5` varchar(50) NULL,
  `Color1` varchar(50) NULL,
  `Color2` varchar(50) NULL,
  `Color3` varchar(50) NULL,
  `Color4` varchar(50) NULL,
  `Color5` varchar(50) NULL,
  `CostPrice1` decimal(10,0) NULL,
  `CostPrice2` decimal(10,0) NULL,
  `CostPrice3` decimal(10,0) NULL,
  `CostPrice4` decimal(10,0) NULL,
  `CostPrice5` decimal(10,0) NULL,
  `TotalDesMat` double NULL,
  `TotalCostPrice` double NULL,
  `TotalCost` double NULL,
  `Width` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  `Diameter` decimal(10,0) NULL,
  `Volume` decimal(10,2) NULL,
  `Notes` text NULL,
  `PriceRisk` double NULL,
  `RealPrice` double NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SampleCode` (`SampleCode`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`samplepackaging` (
  `ID` int(10) NULL auto_increment,
  `SampleCode` varchar(12) NULL,
  `Description` varchar(50) NULL,
  `SampleDate` date NULL default '0000-00-00',
  `TechDraw` varchar(50) NULL,
  `Photo1` varchar(50) NULL,
  `Photo2` varchar(50) NULL,
  `Photo3` varchar(50) NULL,
  `Photo4` varchar(50) NULL,
  `DesMat1` int(11) NULL,
  `DesMat2` int(11) NULL,
  `DesMat3` int(11) NULL,
  `DesMat4` int(11) NULL,
  `DesMat5` int(11) NULL,
  `QtyDesMat1` int(11) NULL,
  `QtyDesMat2` int(11) NULL,
  `QtyDesMat3` int(11) NULL,
  `QtyDesMat4` int(11) NULL,
  `QtyDesMat5` int(11) NULL,
  `TotalDesMat1` double NULL,
  `TotalDesMat2` double NULL,
  `TotalDesMat3` double NULL,
  `TotalDesMat4` double NULL,
  `TotalDesMat5` double NULL,
  `Supplier1` int(11) NULL,
  `Supplier2` int(11) NULL,
  `Supplier3` int(11) NULL,
  `Supplier4` int(11) NULL,
  `Supplier5` int(11) NULL,
  `Material1` varchar(50) NULL,
  `Material2` varchar(50) NULL,
  `Material3` varchar(50) NULL,
  `Material4` varchar(50) NULL,
  `Material5` varchar(50) NULL,
  `Color1` varchar(50) NULL,
  `Color2` varchar(50) NULL,
  `Color3` varchar(50) NULL,
  `Color4` varchar(50) NULL,
  `Color5` varchar(50) NULL,
  `CostPrice1` decimal(10,0) NULL,
  `CostPrice2` decimal(10,0) NULL,
  `CostPrice3` decimal(10,0) NULL,
  `CostPrice4` decimal(10,0) NULL,
  `CostPrice5` decimal(10,0) NULL,
  `TotalDesMat` double NULL,
  `TotalCostPrice` double NULL,
  `TotalCost` double NULL,
  `InnerQty` int(11) NULL,
  `Width` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  `Diameter` decimal(10,0) NULL,
  `Volume` decimal(10,2) NULL,
  `Weight` decimal(10,2) NULL,
  `Notes` text NULL,
  `PriceRisk` double NULL,
  `RealPrice` double NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SampleCode` (`SampleCode`)
) TYPE=MyISAM AUTO_INCREMENT=4;

CREATE TABLE `GayaFusionAll`.`tbladmin` (
  `ID` int(2) NULL auto_increment,
  `UserName` varchar(15) NULL,
  `Passwd` varchar(10) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tbladminist_addressbook` (
  `AddressID` int(11) NULL auto_increment,
  `Company` varchar(100) NULL,
  PRIMARY KEY (`AddressID`)
) TYPE=MyISAM AUTO_INCREMENT=4;

CREATE TABLE `GayaFusionAll`.`tbladminist_addressbook_contact` (
  `ContactId` int(11) NULL auto_increment,
  `AddressID` int(11) NULL,
  `ContactName` varchar(100) NULL,
  `Email` varchar(50) NULL,
  `Address` text NULL,
  `Phone` varchar(20) NULL,
  `Fax` varchar(20) NULL,
  PRIMARY KEY (`ContactId`),
  KEY `AddressID` (`AddressID`,`ContactName`)
) TYPE=MyISAM AUTO_INCREMENT=6;

CREATE TABLE `GayaFusionAll`.`tbladminist_ar_h` (
  `AR_ID` int(11) NULL auto_increment,
  `ClientID` int(11) NULL,
  `CurrencyID` int(11) NULL,
  `DocCode` varchar(11) NULL,
  `SubTotal` decimal(20,2) NULL,
  `Discount` decimal(10,2) NULL default '0.00',
  `PackagingCost` decimal(10,2) NULL,
  `GrandTotal` decimal(20,2) NULL,
  `Deposit` decimal(10,2) NULL,
  `Balance` decimal(10,2) NULL,
  PRIMARY KEY (`AR_ID`),
  KEY `ClientID` (`ClientID`,`DocCode`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_box_d` (
  `Box_D_ID` int(20) NULL auto_increment,
  `Box_H_ID` int(11) NULL,
  `Qty` int(11) NULL,
  `Unit` varchar(15) NULL,
  `CollectID` int(11) NULL,
  `CollectCode` varchar(13) NULL,
  `Remarks` text NULL,
  PRIMARY KEY (`Box_D_ID`),
  KEY `ID_Box_H` (`Box_H_ID`,`CollectID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_box_h` (
  `Box_H_ID` int(10) NULL auto_increment,
  `BoxNumber` int(11) NULL,
  `PackingList_H_ID` int(11) NULL,
  `Length` decimal(10,0) NULL,
  `Width` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Weight` decimal(10,0) NULL,
  PRIMARY KEY (`Box_H_ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_client` (
  `ClientID` int(11) NULL auto_increment,
  `ClientCompany` varchar(100) NULL,
  PRIMARY KEY (`ClientID`)
) TYPE=MyISAM AUTO_INCREMENT=4;

CREATE TABLE `GayaFusionAll`.`tbladminist_conversion` (
  `ConversID` int(11) NULL auto_increment,
  `Currency` int(11) NULL,
  `CurrencyValue` decimal(10,0) NULL,
  `CurrencyDefaultValue` decimal(10,0) NULL,
  PRIMARY KEY (`ConversID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_currency` (
  `CurrencyID` int(11) NULL auto_increment,
  `CurrencyCode` varchar(3) NULL,
  `Currency` varchar(50) NULL,
  PRIMARY KEY (`CurrencyID`),
  UNIQUE KEY `CurrencyCode` (`CurrencyCode`)
) TYPE=InnoDB AUTO_INCREMENT=4;

CREATE TABLE `GayaFusionAll`.`tbladminist_currencydefault` (
  `CurrencyDefault` int(11) NULL
) TYPE=InnoDB;

CREATE TABLE `GayaFusionAll`.`tbladminist_deliveryterm` (
  `DeliveryTermID` int(11) NULL auto_increment,
  `DeliveryTerm` varchar(100) NULL,
  PRIMARY KEY (`DeliveryTermID`)
) TYPE=InnoDB AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tbladminist_deliverytime` (
  `DeliveryTimeID` int(20) NULL auto_increment,
  `DeliveryTime` varchar(100) NULL,
  PRIMARY KEY (`DeliveryTimeID`)
) TYPE=InnoDB AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tbladminist_invoice_d` (
  `Invoice_D_ID` int(20) NULL auto_increment,
  `Invoice_H_ID` int(11) NULL,
  `InvoicePar` varchar(50) NULL default '-',
  `Qty` int(11) NULL,
  `Unit` varchar(15) NULL,
  `CollectID` int(11) NULL,
  `CollectCode` varchar(13) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Total` decimal(10,0) NULL,
  PRIMARY KEY (`Invoice_D_ID`),
  KEY `ID_Invoice_H` (`Invoice_H_ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_invoice_h` (
  `Invoice_H_ID` int(20) NULL auto_increment,
  `Invoice_SH_ID` int(11) NULL,
  `InvoicePar` varchar(50) NULL default '-',
  `Quotation_H_ID` int(11) NULL,
  `Proforma_H_ID` int(11) NULL,
  `InvoiceDate` date NULL default '0000-00-00',
  `ClientOrderRef` varchar(50) NULL,
  `GayaOrderRef` varchar(50) NULL,
  `DeliveryTermID` int(11) NULL,
  `PaymentTermID` int(50) NULL,
  `DueDate` date NULL default '0000-00-00',
  `ClientID` int(11) NULL,
  `AddressID` int(11) NULL,
  `InvoiceContactID` int(11) NULL,
  `DeliveryContactID` int(11) NULL,
  `SubTotal` decimal(10,0) NULL,
  `Discount` decimal(10,0) NULL,
  `Packaging` decimal(10,0) NULL,
  `ShippingCost` decimal(10,0) NULL,
  `GrandTotal` decimal(10,0) NULL,
  `PaymentBankTransferred` decimal(10,0) NULL,
  `Balance` decimal(10,0) NULL,
  PRIMARY KEY (`Invoice_H_ID`),
  KEY `InvoiceNo` (`InvoicePar`),
  KEY `ClientOrderRef` (`ClientOrderRef`),
  KEY `GayaOrderRef` (`GayaOrderRef`)
) TYPE=InnoDB AUTO_INCREMENT=4;

CREATE TABLE `GayaFusionAll`.`tbladminist_invoice_sh` (
  `Invoice_SH_ID` int(11) NULL auto_increment,
  `InvoiceNo` varchar(16) NULL,
  PRIMARY KEY (`Invoice_SH_ID`),
  UNIQUE KEY `InvoiceNo_2` (`InvoiceNo`),
  KEY `InvoiceNo` (`InvoiceNo`)
) TYPE=MyISAM AUTO_INCREMENT=6;

CREATE TABLE `GayaFusionAll`.`tbladminist_packinglist_d` (
  `PackingList_D_ID` int(11) NULL auto_increment,
  `PackingList_H_ID` int(11) NULL,
  `Box_H_ID` int(11) NULL,
  PRIMARY KEY (`PackingList_D_ID`),
  KEY `ID_PackingList_H` (`PackingList_H_ID`,`Box_H_ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_packinglist_h` (
  `PackingList_H_ID` int(11) NULL auto_increment,
  `PackingListNo` varchar(15) NULL,
  `PackingListDate` date NULL default '0000-00-00',
  `Invoice_H_ID` int(11) NULL,
  `AddressID` int(11) NULL,
  `InvoiceContactID` int(11) NULL,
  `DeliveryContactID` int(11) NULL,
  `OrderRef` varchar(20) NULL,
  PRIMARY KEY (`PackingList_H_ID`),
  KEY `PackListNo` (`PackingListNo`,`OrderRef`)
) TYPE=InnoDB AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tbladminist_payment` (
  `PaymentId` int(11) NULL,
  `AR_ID` int(11) NULL,
  `DocCode` varchar(12) NULL,
  `PaymentType` int(11) NULL,
  `DatePaid` date NULL default '0000-00-00',
  `CurencyConversion` decimal(10,2) NULL,
  `AmountPaid` decimal(10,2) NULL,
  PRIMARY KEY (`PaymentId`),
  KEY `AR_ID` (`AR_ID`,`DocCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tbladminist_paymentterm` (
  `PaymentTermID` int(8) NULL auto_increment,
  `PaymentTerm` varchar(100) NULL,
  PRIMARY KEY (`PaymentTermID`)
) TYPE=InnoDB AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tbladminist_paymenttype` (
  `PaymentTypeID` tinyint(4) NULL auto_increment,
  `PaymentType` varchar(15) NULL,
  PRIMARY KEY (`PaymentTypeID`),
  KEY `PaymentType` (`PaymentType`)
) TYPE=MyISAM AUTO_INCREMENT=4;

CREATE TABLE `GayaFusionAll`.`tbladminist_prodorderlist_proforma` (
  `Prof_Pol_ID` int(11) NULL auto_increment,
  `ProformaID` int(11) NULL,
  `ProdOrderListID` int(11) NULL,
  PRIMARY KEY (`Prof_Pol_ID`),
  KEY `ProformaID` (`ProformaID`,`ProdOrderListID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_proforma_d` (
  `Proforma_D_ID` int(20) NULL auto_increment,
  `Proforma_H_ID` int(11) NULL,
  `CollectID` int(11) NULL,
  `CollectCode` varchar(13) NULL,
  `Qty` int(11) NULL,
  `Unit` varchar(15) NULL,
  `Type` int(11) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Total` decimal(10,0) NULL,
  PRIMARY KEY (`Proforma_D_ID`),
  KEY `Proforma_H_ID` (`Proforma_H_ID`)
) TYPE=InnoDB AUTO_INCREMENT=8;

CREATE TABLE `GayaFusionAll`.`tbladminist_proforma_h` (
  `Proforma_H_ID` int(11) NULL auto_increment,
  `ProformaNo` varchar(11) NULL,
  `Rev` varchar(10) NULL,
  `Validity` varchar(15) NULL,
  `ProformaDate` date NULL,
  `ClientOrderRef` varchar(50) NULL,
  `ClientID` int(11) NULL,
  `AddressID` int(11) NULL,
  `ContactID` int(11) NULL,
  `PackagingCost` decimal(10,0) NULL,
  `DeliveryTermID` int(11) NULL,
  `DeliveryTimeID` int(11) NULL,
  `PaymentTermID` int(11) NULL,
  `SpecialInstruction` text NULL,
  `PreviewDPDate` date NULL default '0000-00-00',
  `Quotation_H_ID` int(11) NULL,
  PRIMARY KEY (`Proforma_H_ID`),
  KEY `ProformaNo` (`ProformaNo`,`ClientOrderRef`),
  KEY `Quotation_H_ID` (`Quotation_H_ID`)
) TYPE=InnoDB AUTO_INCREMENT=5;

CREATE TABLE `GayaFusionAll`.`tbladminist_proformarev_d` (
  `ProformaRev_D_ID` int(11) NULL auto_increment,
  `Proforma_D_ID` int(20) NULL,
  `Proforma_H_ID` int(11) NULL,
  `CollectID` int(11) NULL,
  `CollectCode` varchar(13) NULL,
  `Qty` int(11) NULL,
  `Unit` varchar(15) NULL,
  `Type` int(11) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Total` decimal(10,0) NULL,
  PRIMARY KEY (`ProformaRev_D_ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_proformarev_h` (
  `ProformaRev_H_ID` int(11) NULL auto_increment,
  `Proforma_H_ID` int(11) NULL,
  `ProformaNo` varchar(11) NULL,
  `Rev` varchar(10) NULL,
  `Validity` varchar(15) NULL,
  `ProformaDate` date NULL,
  `ClientOrderRef` varchar(50) NULL,
  `ClientID` int(11) NULL,
  `AddressID` int(11) NULL,
  `ContactID` int(11) NULL,
  `PackagingCost` decimal(10,0) NULL,
  `DeliveryTermID` int(11) NULL,
  `DeliveryTimeID` int(11) NULL,
  `PaymentTermID` int(11) NULL,
  `SpecialInstruction` text NULL,
  `PreviewDPDate` date NULL default '0000-00-00',
  `Quotation_H_ID` int(11) NULL,
  PRIMARY KEY (`ProformaRev_H_ID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotation_d` (
  `Quotation_D_ID` int(20) NULL auto_increment,
  `Quotation_H_ID` int(11) NULL,
  `RndCode` varchar(12) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Remark` text NULL,
  PRIMARY KEY (`Quotation_D_ID`),
  KEY `ID_Quotation_H` (`Quotation_H_ID`,`RndCode`)
) TYPE=MyISAM AUTO_INCREMENT=9;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotation_h` (
  `Quotation_H_ID` int(20) NULL auto_increment,
  `QuotationNo` varchar(11) NULL,
  `Rev` varchar(10) NULL,
  `Validity` varchar(15) NULL,
  `QuotationDate` date NULL default '0000-00-00',
  `ClientOrderRef` varchar(50) NULL,
  `ClientID` int(11) NULL,
  `AddressID` int(11) NULL,
  `ContactID` int(11) NULL,
  `PackagingCost` float(10,0) NULL,
  `DeliveryTermID` int(11) NULL,
  `DeliveryTimeID` int(11) NULL,
  `PaymentTermID` int(11) NULL,
  `SpecialInstruction` text NULL,
  PRIMARY KEY (`Quotation_H_ID`),
  KEY `QuotationNo` (`QuotationNo`,`ClientOrderRef`),
  KEY `ClientID` (`ClientID`)
) TYPE=MyISAM AUTO_INCREMENT=9;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotation_proforma` (
  `ID` int(11) NULL auto_increment,
  `QuotationID` int(11) NULL,
  `ProformaID` int(11) NULL,
  PRIMARY KEY (`ID`),
  KEY `ProformaID` (`ProformaID`,`QuotationID`)
) TYPE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotationrev_d` (
  `QuotationRev_D_ID` int(11) NULL auto_increment,
  `QuotationRev_H_ID` int(11) NULL,
  `Quotation_D_ID` int(20) NULL,
  `Quotation_H_ID` int(11) NULL,
  `RndCode` varchar(12) NULL,
  `UnitPrice` decimal(10,0) NULL,
  `Remark` text NULL,
  PRIMARY KEY (`QuotationRev_D_ID`)
) TYPE=MyISAM AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tbladminist_quotationrev_h` (
  `QuotationRev_H_ID` int(11) NULL auto_increment,
  `Quotation_H_ID` int(20) NULL,
  `QuotationNo` varchar(11) NULL,
  `Rev` varchar(10) NULL,
  `Validity` varchar(15) NULL,
  `QuotationDate` date NULL default '0000-00-00',
  `ClientOrderRef` varchar(50) NULL,
  `ClientID` int(11) NULL,
  `AddressID` int(11) NULL,
  `ContactID` int(11) NULL,
  `PackagingCost` float(10,0) NULL,
  `DeliveryTermID` int(11) NULL,
  `DeliveryTimeID` int(11) NULL,
  `PaymentTermID` int(11) NULL,
  `SpecialInstruction` text NULL,
  PRIMARY KEY (`QuotationRev_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=7;

CREATE TABLE `GayaFusionAll`.`tblcasting` (
  `ID` int(11) NULL auto_increment,
  `CastingCode` varchar(10) NULL,
  `CastingDescription` varchar(100) NULL,
  `CastingDate` date NULL default '0000-00-00',
  `CastingTechDraw` varchar(50) NULL,
  `CastingPhoto1` varchar(50) NULL,
  `CastingPhoto2` varchar(50) NULL,
  `CastingPhoto3` varchar(50) NULL,
  `CastingPhoto4` varchar(50) NULL,
  `CastingNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `CastingCode` (`CastingCode`)
) TYPE=MyISAM AUTO_INCREMENT=5;

CREATE TABLE `GayaFusionAll`.`tblclay` (
  `ID` int(11) NULL auto_increment,
  `ClayCode` varchar(10) NULL,
  `ClayDescription` varchar(100) NULL,
  `ClayDate` date NULL default '0000-00-00',
  `ClayTechDraw` varchar(50) NULL,
  `ClayPhoto1` varchar(50) NULL,
  `ClayPhoto2` varchar(50) NULL,
  `ClayPhoto3` varchar(50) NULL,
  `ClayPhoto4` varchar(50) NULL,
  `ClayNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ClayCode` (`ClayCode`)
) TYPE=MyISAM AUTO_INCREMENT=5;

CREATE TABLE `GayaFusionAll`.`tblcollect_category` (
  `CategoryCode` varchar(2) NULL,
  `CategoryName` varchar(50) NULL,
  PRIMARY KEY (`CategoryCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_color` (
  `ColorCode` varchar(2) NULL,
  `ColorName` varchar(100) NULL,
  PRIMARY KEY (`ColorCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_design` (
  `DesignCode` varchar(2) NULL,
  `DesignName` varchar(100) NULL,
  PRIMARY KEY (`DesignCode`),
  KEY `DesignCode` (`DesignCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_group_det` (
  `ID` int(11) NULL auto_increment,
  `Group_H_ID` int(11) NULL,
  `CollectCode` varchar(15) NULL,
  `Qty` int(11) NULL,
  PRIMARY KEY (`ID`),
  KEY `Group_H_ID` (`Group_H_ID`)
) TYPE=MyISAM AUTO_INCREMENT=6;

CREATE TABLE `GayaFusionAll`.`tblcollect_group_h` (
  `Group_H_ID` int(11) NULL auto_increment,
  `GroupCode` varchar(12) NULL,
  `GroupDate` date NULL default '0000-00-00',
  `DesignCode` varchar(2) NULL,
  `GroupDescription` varchar(255) NULL,
  `ClientCode` varchar(50) NULL,
  `ClientDesc` varchar(255) NULL,
  `GroupPhoto` varchar(50) NULL,
  `Diameter` decimal(10,0) NULL,
  `Height` decimal(10,0) NULL,
  `Weight` decimal(10,0) NULL,
  `Length` decimal(10,0) NULL,
  PRIMARY KEY (`Group_H_ID`),
  UNIQUE KEY `Code` (`GroupCode`)
) TYPE=MyISAM AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tblcollect_master` (
  `ID` int(11) NULL auto_increment,
  `CollectCode` varchar(15) NULL,
  `DesignCode` varchar(2) NULL,
  `NameCode` varchar(2) NULL,
  `CategoryCode` varchar(2) NULL,
  `SizeCode` varchar(2) NULL,
  `TextureCode` varchar(2) NULL,
  `ColorCode` varchar(2) NULL,
  `MaterialCode` varchar(2) NULL,
  `ClientCode` varchar(20) NULL,
  `ClientDescription` varchar(50) NULL,
  `CollectDate` date NULL default '0000-00-00',
  `TechDraw` varchar(50) NULL,
  `Photo1` varchar(50) NULL,
  `Photo2` varchar(50) NULL,
  `Photo3` varchar(50) NULL,
  `Photo4` varchar(50) NULL,
  `RefID` int(11) NULL,
  `Clay` int(11) NULL,
  `ClayKG` decimal(10,0) NULL,
  `ClayNote` text NULL,
  `BuildTech` varchar(50) NULL,
  `BuildTechNote` text NULL,
  `Rim` varchar(30) NULL,
  `Feet` varchar(30) NULL,
  `Casting1` int(11) NULL,
  `Casting2` int(11) NULL,
  `Casting3` int(11) NULL,
  `Casting4` int(11) NULL,
  `CastingNote` text NULL,
  `Estruder1` int(11) NULL,
  `Estruder2` int(11) NULL,
  `Estruder3` int(11) NULL,
  `Estruder4` int(11) NULL,
  `EstruderNote` text NULL,
  `Texture1` int(11) NULL,
  `Texture2` int(11) NULL,
  `Texture3` int(11) NULL,
  `Texture4` int(11) NULL,
  `TextureNote` text NULL,
  `Tools1` int(11) NULL,
  `Tools2` int(11) NULL,
  `Tools3` int(11) NULL,
  `Tools4` int(11) NULL,
  `ToolsNote` text NULL,
  `Engobe1` int(11) NULL,
  `Engobe2` int(11) NULL,
  `Engobe3` int(11) NULL,
  `Engobe4` int(11) NULL,
  `EngobeNote` text NULL,
  `BisqueTemp` varchar(10) NULL,
  `StainOxide1` int(11) NULL,
  `StainOxide2` int(11) NULL,
  `StainOxide3` int(11) NULL,
  `StainOxide4` int(11) NULL,
  `StainOxideNote` text NULL,
  `Glaze1` int(11) NULL,
  `Glaze2` int(11) NULL,
  `Glaze3` int(11) NULL,
  `Glaze4` int(11) NULL,
  `GlazeDensity1` varchar(10) NULL,
  `GlazeDensity2` varchar(10) NULL,
  `GlazeDensity3` varchar(10) NULL,
  `GlazeDensity4` varchar(10) NULL,
  `GlazeNote` text NULL,
  `GlazeTemp` varchar(10) NULL,
  `Firing` varchar(10) NULL,
  `FiringNote` text NULL,
  `Width` decimal(10,2) NULL,
  `Height` decimal(10,2) NULL,
  `Length` decimal(10,2) NULL,
  `Diameter` decimal(10,2) NULL,
  `SampCeramicVolume` decimal(10,2) NULL default '0.00',
  `FinalSizeNote` text NULL,
  `DesignMat1` int(11) NULL,
  `DesignMat2` int(11) NULL,
  `DesignMat3` int(11) NULL,
  `DesignMat4` int(11) NULL,
  `DesignMatQty1` int(10) NULL,
  `DesignMatQty2` int(10) NULL,
  `DesignMatQty3` int(10) NULL,
  `DesignMatQty4` int(10) NULL,
  `DesignMatNote` text NULL,
  `History` text NULL,
  `ClayType` varchar(50) NULL,
  `ClayCost` double NULL,
  `ClayPreparationMinute` int(11) NULL,
  `ClayPreparationCost` double NULL,
  `WheelMinute` int(11) NULL,
  `WheelCost` double NULL,
  `SlabMinute` int(11) NULL,
  `SlabCost` double NULL,
  `CastingMinute` int(11) NULL,
  `CastingCost` int(11) NULL,
  `FinishingMinute` int(11) NULL,
  `FinishingCost` double NULL,
  `GlazingMinute` int(11) NULL,
  `GlazingCost` double NULL,
  `StandardBisqueLoading` int(11) NULL,
  `StandardBisqueCost` double NULL,
  `StandardGlazeLoading` int(11) NULL,
  `StandardGlazeCost` double NULL,
  `RakuBisqueLoading` int(11) NULL,
  `RakuBisqueCost` double NULL,
  `RakuGlazeLoading` int(11) NULL,
  `RakuGlazeCost` double NULL,
  `MovementMinute` int(11) NULL,
  `MovementCost` double NULL,
  `PackagingWorkMinute` int(11) NULL,
  `PackagingWorkCost` double NULL,
  `ClayPreparationPPH` int(11) NULL,
  `WheelPPH` int(11) NULL,
  `SlabPPH` int(11) NULL,
  `CastingPPH` int(11) NULL,
  `FinishingPPH` int(11) NULL,
  `GlazingPPH` int(11) NULL,
  `MovementPPH` int(11) NULL,
  `PackagingWorkPPH` int(11) NULL,
  `TotalAllCost` double NULL,
  `RiskPrice` double NULL,
  `HypoSellingPrice` double NULL,
  `RealSellingPrice` double NULL,
  `LastUpdate` date NULL default '0000-00-00',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `CollectCode` (`CollectCode`)
) TYPE=MyISAM AUTO_INCREMENT=37;

CREATE TABLE `GayaFusionAll`.`tblcollect_material` (
  `MaterialCode` varchar(2) NULL,
  `MaterialName` varchar(50) NULL,
  PRIMARY KEY (`MaterialCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_name` (
  `NameCode` varchar(2) NULL,
  `NameDesc` varchar(50) NULL,
  PRIMARY KEY (`NameCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_size` (
  `SizeCode` varchar(2) NULL,
  `SizeName` varchar(50) NULL,
  PRIMARY KEY (`SizeCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcollect_texture` (
  `TextureCode` varchar(2) NULL,
  `TextureName` varchar(50) NULL,
  PRIMARY KEY (`TextureCode`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcosting_casting` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  `PiecesPerHour` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_clay` (
  `ID` int(11) NULL auto_increment,
  `ClayType` varchar(50) NULL,
  `PricePerKG` double NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ClayType` (`ClayType`)
) TYPE=MyISAM AUTO_INCREMENT=7;

CREATE TABLE `GayaFusionAll`.`tblcosting_claypreparation` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  `PiecesPerHour` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_costbudgetpreview` (
  `ID` int(11) NULL auto_increment,
  `BudgetYear` int(11) NULL,
  `CostBudgetAmmount` double NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_finishing` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  `PiecesPerHour` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_glazing` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  `PiecesPerHour` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_master` (
  `ID` int(1) NULL,
  `ClayPreparationCPM` int(11) NULL,
  `ClayPreparationPPH` int(11) NULL,
  `WheelCPM` int(11) NULL,
  `WheelPPH` int(11) NULL,
  `SlabCPM` int(11) NULL,
  `SlabPPH` int(11) NULL,
  `CastingCPM` int(11) NULL,
  `CastingPPH` int(11) NULL,
  `FinishingCPM` int(11) NULL,
  `FinishingPPH` int(11) NULL,
  `GlazingCPM` int(11) NULL,
  `GlazingPPH` int(11) NULL,
  `MovementCPM` int(11) NULL,
  `MovementPPH` int(11) NULL,
  `PackagingWorkCPM` int(11) NULL,
  `PackagingWorkPPH` int(11) NULL,
  `StandardBisqueCPM` int(11) NULL,
  `StandardBisquePPH` int(11) NULL,
  `StandardGlazeCPM` int(11) NULL,
  `StandardGlazePPH` int(11) NULL,
  `RakuBisqueCPM` int(11) NULL,
  `RakuBisquePPH` int(11) NULL,
  `RakuGlazeCPM` int(11) NULL,
  `RakuGlazePPH` int(11) NULL,
  `ProductiveHourDay` decimal(10,2) NULL default '0.00',
  `ProductiveHourMonth` int(11) NULL,
  `ProductiveHourYear` int(11) NULL,
  `TrowWorker` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tblcosting_movement` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  `PiecesPerHour` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_packagingwork` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  `PiecesPerHour` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_productivehours` (
  `ID` int(11) NULL auto_increment,
  `Day` decimal(10,2) NULL default '0.00',
  `Month` int(11) NULL,
  `Year` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_rakubisque` (
  `ID` int(11) NULL auto_increment,
  `PricePerFiring` decimal(10,2) NULL default '0.00',
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_rakuglaze` (
  `ID` int(11) NULL auto_increment,
  `PricePerFiring` decimal(10,2) NULL default '0.00',
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_slab` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  `PiecesPerHour` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_standardbisque` (
  `ID` int(11) NULL auto_increment,
  `PricePerFiring` double NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_standardglaze` (
  `ID` int(1) NULL auto_increment,
  `PricePerFiring` double NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_trowworker` (
  `ID` int(11) NULL auto_increment,
  `TrowWorker` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tblcosting_wheel` (
  `ID` int(11) NULL auto_increment,
  `CostPerMinute` int(11) NULL,
  `PiecesPerHour` int(11) NULL,
  PRIMARY KEY (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=2;

CREATE TABLE `GayaFusionAll`.`tbldesignmat` (
  `DesignMatID` int(11) NULL auto_increment,
  `DesignMatCode` varchar(10) NULL,
  `DesignMatDescription` varchar(100) NULL,
  `DesignMatTechDraw` varchar(50) NULL,
  `DesignMatPhoto1` varchar(50) NULL,
  `DesignMatPhoto2` varchar(50) NULL,
  `DesignMatPhoto3` varchar(50) NULL,
  `DesignMatPhoto4` varchar(50) NULL,
  `DesignMatSupplier` int(11) NULL,
  `DesignMatUnit` varchar(2) NULL,
  `DesignMatUnitPrice` decimal(10,0) NULL,
  `DesignMatNotes` text NULL,
  `DesignMatDate` date NULL default '0000-00-00',
  PRIMARY KEY (`DesignMatID`),
  UNIQUE KEY `DesignMatCode` (`DesignMatCode`)
) TYPE=MyISAM AUTO_INCREMENT=5;

CREATE TABLE `GayaFusionAll`.`tblengobe` (
  `ID` int(11) NULL auto_increment,
  `EngobeCode` varchar(10) NULL,
  `EngobeDescription` varchar(100) NULL,
  `EngobeDate` date NULL default '0000-00-00',
  `EngobeTechDraw` varchar(50) NULL,
  `EngobePhoto1` varchar(50) NULL,
  `EngobePhoto2` varchar(50) NULL,
  `EngobePhoto3` varchar(50) NULL,
  `EngobePhoto4` varchar(50) NULL,
  `EngobeNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `EngobeCode` (`EngobeCode`)
) TYPE=MyISAM AUTO_INCREMENT=5;

CREATE TABLE `GayaFusionAll`.`tblestruder` (
  `ID` int(11) NULL auto_increment,
  `EstruderCode` varchar(10) NULL,
  `EstruderDescription` varchar(100) NULL,
  `EstruderDate` date NULL default '0000-00-00',
  `EstruderTechDraw` varchar(50) NULL,
  `EstruderPhoto1` varchar(50) NULL,
  `EstruderPhoto2` varchar(50) NULL,
  `EstruderPhoto3` varchar(50) NULL,
  `EstruderPhoto4` varchar(50) NULL,
  `EstruderNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `EstruderCode` (`EstruderCode`)
) TYPE=MyISAM AUTO_INCREMENT=5;

CREATE TABLE `GayaFusionAll`.`tblfiringplan` (
  `ID` int(11) NULL auto_increment,
  `FiringPlanCode` varchar(10) NULL,
  `FiringPlanDescription` varchar(100) NULL,
  `FiringPlanDate` date NULL default '0000-00-00',
  `FiringPlanTechDraw` varchar(50) NULL,
  `FiringPlanPhoto1` varchar(50) NULL,
  `FiringPlanPhoto2` varchar(50) NULL,
  `FiringPlanPhoto3` varchar(50) NULL,
  `FiringPlanPhoto4` varchar(50) NULL,
  `FiringPlanNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `FiringPlanCode` (`FiringPlanCode`)
) TYPE=MyISAM AUTO_INCREMENT=3;

CREATE TABLE `GayaFusionAll`.`tblglaze` (
  `ID` int(11) NULL auto_increment,
  `GlazeCode` varchar(10) NULL,
  `GlazeDescription` varchar(100) NULL,
  `GlazeDate` date NULL default '0000-00-00',
  `GlazeTechDraw` varchar(50) NULL,
  `GlazePhoto1` varchar(50) NULL,
  `GlazePhoto2` varchar(50) NULL,
  `GlazePhoto3` varchar(50) NULL,
  `GlazePhoto4` varchar(50) NULL,
  `GlazeNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `GlazeCode` (`GlazeCode`)
) TYPE=MyISAM AUTO_INCREMENT=5;

CREATE TABLE `GayaFusionAll`.`tblreference` (
  `ID` int(11) NULL auto_increment,
  `RefCode` varchar(20) NULL,
  `sID` int(11) NULL,
  `CollectID` int(11) NULL,
  `RefNote` text NULL,
  PRIMARY KEY (`ID`),
  KEY `sID` (`sID`),
  KEY `CollectID` (`CollectID`)
) TYPE=MyISAM AUTO_INCREMENT=8;

CREATE TABLE `GayaFusionAll`.`tblstainoxide` (
  `ID` int(11) NULL auto_increment,
  `StainOxideCode` varchar(10) NULL,
  `StainOxideDescription` varchar(100) NULL,
  `StainOxideDate` date NULL default '0000-00-00',
  `StainOxideTechDraw` varchar(50) NULL,
  `StainOxidePhoto1` varchar(50) NULL,
  `StainOxidePhoto2` varchar(50) NULL,
  `StainOxidePhoto3` varchar(50) NULL,
  `StainOxidePhoto4` varchar(50) NULL,
  `StainOxideNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `stainoxideCode` (`StainOxideCode`)
) TYPE=MyISAM AUTO_INCREMENT=5;

CREATE TABLE `GayaFusionAll`.`tblsupplier` (
  `ID` int(11) NULL auto_increment,
  `SupCode` varchar(15) NULL,
  `SupCompany` varchar(100) NULL,
  `SupContact` varchar(100) NULL,
  `SupAddress` varchar(200) NULL,
  `SupHP` varchar(15) NULL,
  `SupOffice` varchar(100) NULL,
  `SupFax` varchar(20) NULL,
  `SupEmail` varchar(50) NULL,
  `SupItems` varchar(100) NULL,
  `SupOtherInfo` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SupCode` (`SupCode`)
) TYPE=MyISAM AUTO_INCREMENT=5;

CREATE TABLE `GayaFusionAll`.`tbltexture` (
  `ID` int(11) NULL auto_increment,
  `TextureCode` varchar(10) NULL,
  `TextureDescription` varchar(100) NULL,
  `TextureDate` date NULL default '0000-00-00',
  `TextureTechDraw` varchar(50) NULL,
  `TexturePhoto1` varchar(50) NULL,
  `TexturePhoto2` varchar(50) NULL,
  `TexturePhoto3` varchar(50) NULL,
  `TexturePhoto4` varchar(50) NULL,
  `TextureNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `TextureCode` (`TextureCode`)
) TYPE=MyISAM AUTO_INCREMENT=5;

CREATE TABLE `GayaFusionAll`.`tbltools` (
  `ID` int(11) NULL auto_increment,
  `ToolsCode` varchar(10) NULL,
  `ToolsDescription` varchar(100) NULL,
  `ToolsDate` date NULL default '0000-00-00',
  `ToolsTechDraw` varchar(50) NULL,
  `ToolsPhoto1` varchar(50) NULL,
  `ToolsPhoto2` varchar(50) NULL,
  `ToolsPhoto3` varchar(50) NULL,
  `ToolsPhoto4` varchar(50) NULL,
  `ToolsNotes` text NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ToolsCode` (`ToolsCode`)
) TYPE=MyISAM AUTO_INCREMENT=5;

CREATE TABLE `GayaFusionAll`.`tblunit` (
  `UnitID` varchar(2) NULL,
  `UnitValue` varchar(30) NULL,
  PRIMARY KEY (`UnitID`)
) TYPE=MyISAM;

CREATE TABLE `GayaFusionAll`.`tbluser` (
  `id` int(11) NULL auto_increment,
  `UserName` varchar(15) NULL,
  `LastName` varchar(50) NULL,
  `FirstName` varchar(30) NULL,
  `Password` varchar(50) NULL,
  `Type` varchar(15) NULL,
  PRIMARY KEY (`id`)
) TYPE=MyISAM AUTO_INCREMENT=15;


# dumping data for GayaFusionAll.sampleceramic
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (2, 'SC08-001', 'CUP', 'T01', 'TAZZA', '2008-08-18', '200808180155570.wp.jpg', '200808180155570.PHO 01.jpg', '200808180155570.PHO 02.jpg', '200808180155570.PHO 03.jpg', '200808180155570.PHO 04.jpg', NULL, 1, 5, 'test clay notes', 'TROWING', 'test build technique', 'FLAT', 'ROUND', 1, NULL, NULL, NULL, 'test casting notes', 1, NULL, NULL, NULL, 'test estruder notes', 4, NULL, NULL, NULL, 'test texture notes', 1, NULL, NULL, NULL, 'test notes texture', 2, NULL, NULL, NULL, 'test engobe notes', '900', 1, NULL, NULL, NULL, 'test stain notes', 1, NULL, NULL, NULL, '1280', NULL, NULL, NULL, 'test glaze notes', '1300', 'Oxidation', 'test firing notes', NULL, 10.00, NULL, 8.00, 'test final notes', 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'test deaign material notes', 'test history', 1, 4000.00, 10, 2400.00, 5, 6000.00, 5, 6000.00, 0, 0, 0, 0, 0, 0, 500, 5000, 30, 15000, 0, 0, 0, 0, 0, 0, 0, 0, 6, 12, 12, 0, 0, 0, 0, 0, 50400, 55440, 166320.00, 100000.00);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (3, 'SC08-002', 'SAUCER', 'S01', 'TAZZA PIATO', '2008-08-18', '200808180331000.wp.jpg', '200808180331000.PHO 02.jpg', '200808180331000.PHO 03.jpg', '200808180331000.PHO 04.jpg', '200808180331000.PHO 01.jpg', NULL, 1, 3, 'test clay notes', 'TROWING', 'test build technique notes', 'ROUND', 'ROUND', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'test texture notes', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '960', 4, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '1500', NULL, NULL, NULL, 'test glaze notes', '1300', 'Oxidation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 2400.00, 5, 4800.00, 10, 2400.00, 10, 2400.00, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 6, 6, 0, 0, 0, 0, 0, 12000, 13200, 39600.00, 0.00);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (4, 'SC08-003', 'FRUIT PLATE', 'FP01', 'FRUIT PIATTO ', '0000-01-01', NULL, '200808180332270.PHO 03.jpg', '200808180332270.PHO 04.jpg', '200808180332270.PHO 01.jpg', '200808180332270.PHO 02.jpg', 3, 1, 5, NULL, NULL, 'ldflajfdsf\r\nclay notes\r\nkok ga\r\nkliatan', '40', '0.5', 0, 0, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, '960', 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1300', 'Oxidation', NULL, 5.00, 5.00, 5.00, 0.00, NULL, 1, 2, NULL, NULL, 5, 3, 0, 0, NULL, 'coba deh tes history-nya..\r\nini juga test pake enter', 6, 5000.00, 6, 3900.00, 2, 9000.00, 8, 4000.00, 5, 9600, 30, 600, 6, 4500, 50, 5000, 50, 15000, 0, 0, 0, 0, 1, 18000, 3, 9000, 10, 30, 8, 12, 2, 10, 60, 20, 83600, 91960, 275880.00, 300000.00);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (5, 'SC08-004', 'SHOW PLATE', 'PG01', 'PIATTO GRANDE', '2008-06-25', NULL, '200808180333310.PHO 04.jpg', '200808180333310.PHO 01.jpg', '200808180333310.PHO 02.jpg', '200808180333310.PHO 03.jpg', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Reduction', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 0.00);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (6, 'nam', 'enam', '', '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Oxidation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 0.00);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (7, 'tuju', 'tujuh', '', '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Oxidation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 0.00);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (8, 'lapan', 'delapan test', '', '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Oxidation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 0.00);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (9, 'so9', 'sembilan tes', 'code9', 'apa aja deh', '2008-03-13', '', '', '', '', NULL, 0, 1, 0, '', '', '', '', '', 0, 0, 0, 0, '', 0, 0, 0, 0, '', 0, 0, 0, 0, '', 0, 0, 0, 0, '', 0, 0, 0, 0, '', '', 0, 0, 0, 0, '', 0, 0, 0, 0, '', '', '', '', '', '', 'Oxidation', '', 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, 0, 0, 0, 0, 0, '', '', NULL, NULL, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 0.00);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (10, 'tes10', 'kesepulu', '', '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Oxidation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 0.00);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (11, 'ini11', 'kesebelas lho', '', '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Oxidation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 0.00);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (12, 'code12', 'tes ke12', 'cek n ricek', 'huehehehe', '2008-03-25', NULL, '20080316202755-100_5174.JPG', NULL, NULL, NULL, 0, 1, 0, '', '', '', '', '', 0, 0, 0, 0, '', 0, 0, 0, 0, '', 0, 0, 0, 0, '', 0, 0, 0, 0, '', 0, 0, 0, 0, '', '', 0, 0, 0, 0, '', 0, 0, 0, 0, '', '', '', '', '', '', 'Oxidation', '', 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, 0.00, 35, 800.00, 12, 1250.00, 0, 0.00, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 5, 0, 0, 0, 0, 0, 0, 2050, 2255, 6765.00, 3000.00);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (13, 'code13', 'tes ke 13 ni', 'client13code', '', '0000-00-00', '', '', '', '', NULL, 0, 1, 0, '', '', '', '', '', 0, 0, 0, 0, '', 0, 0, 0, 0, '', 0, 0, 0, 0, '', 0, 0, 0, 0, '', 0, 0, 0, 0, '', '', 0, 0, 0, 0, '', 0, 0, 0, 0, '', '', '', '', '', '', 'Oxidation', '', 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, 0.00, 0, 0.00, 60, 300.00, 0, 0.00, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 300, 330, 990.00, 0.00);
INSERT INTO `sampleceramic` (`sID`, `SampleCode`, `SampleDescription`, `ClientCode`, `ClientDescription`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`) VALUES (14, 'code14', 'code ke 14', '', '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Oxidation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 0.00);


# dumping data for GayaFusionAll.sampleother
INSERT INTO `sampleother` (`ID`, `SampleCode`, `Description`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `DesMat1`, `DesMat2`, `DesMat3`, `DesMat4`, `DesMat5`, `QtyDesMat1`, `QtyDesMat2`, `QtyDesMat3`, `QtyDesMat4`, `QtyDesMat5`, `TotalDesMat1`, `TotalDesMat2`, `TotalDesMat3`, `TotalDesMat4`, `TotalDesMat5`, `Supplier1`, `Supplier2`, `Supplier3`, `Supplier4`, `Supplier5`, `Material1`, `Material2`, `Material3`, `Material4`, `Material5`, `Color1`, `Color2`, `Color3`, `Color4`, `Color5`, `CostPrice1`, `CostPrice2`, `CostPrice3`, `CostPrice4`, `CostPrice5`, `TotalDesMat`, `TotalCostPrice`, `TotalCost`, `Width`, `Height`, `Length`, `Diameter`, `Volume`, `Notes`, `PriceRisk`, `RealPrice`) VALUES (1, 'SO001', 'SAMP other pertama', '0000-01-01', '20080318203957-graduation.JPG', '20080318203957-tazmania_baby.JPG', NULL, NULL, NULL, 1, 0, 0, 0, 0, 2, NULL, NULL, NULL, NULL, 9000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'mas', 'kuning', NULL, NULL, NULL, 'kuning', 'kuning', NULL, NULL, NULL, 10000, 3000, 0, 0, 0, 9000, 13000, 22000, NULL, NULL, NULL, 5, 31.40, 'coba\r\nsample\r\nothernya', NULL, NULL);


# dumping data for GayaFusionAll.samplepackaging
INSERT INTO `samplepackaging` (`ID`, `SampleCode`, `Description`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `DesMat1`, `DesMat2`, `DesMat3`, `DesMat4`, `DesMat5`, `QtyDesMat1`, `QtyDesMat2`, `QtyDesMat3`, `QtyDesMat4`, `QtyDesMat5`, `TotalDesMat1`, `TotalDesMat2`, `TotalDesMat3`, `TotalDesMat4`, `TotalDesMat5`, `Supplier1`, `Supplier2`, `Supplier3`, `Supplier4`, `Supplier5`, `Material1`, `Material2`, `Material3`, `Material4`, `Material5`, `Color1`, `Color2`, `Color3`, `Color4`, `Color5`, `CostPrice1`, `CostPrice2`, `CostPrice3`, `CostPrice4`, `CostPrice5`, `TotalDesMat`, `TotalCostPrice`, `TotalCost`, `InnerQty`, `Width`, `Height`, `Length`, `Diameter`, `Volume`, `Weight`, `Notes`, `PriceRisk`, `RealPrice`) VALUES (1, 'SP-001', 'SampPack yg pertama', '2008-07-20', NULL, NULL, NULL, NULL, NULL, 1, 3, 2, NULL, NULL, 2, 2, 2, NULL, NULL, 9000, 10000, 10000, 0, 0, 1, NULL, NULL, NULL, NULL, 'ijo ijo', NULL, NULL, NULL, NULL, 'ijo', NULL, NULL, NULL, NULL, 5000, 0, 0, 0, 0, 29000, 5000, 34000, 6, NULL, 10, NULL, 10, 628.00, 50.00, NULL, NULL, NULL);
INSERT INTO `samplepackaging` (`ID`, `SampleCode`, `Description`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `DesMat1`, `DesMat2`, `DesMat3`, `DesMat4`, `DesMat5`, `QtyDesMat1`, `QtyDesMat2`, `QtyDesMat3`, `QtyDesMat4`, `QtyDesMat5`, `TotalDesMat1`, `TotalDesMat2`, `TotalDesMat3`, `TotalDesMat4`, `TotalDesMat5`, `Supplier1`, `Supplier2`, `Supplier3`, `Supplier4`, `Supplier5`, `Material1`, `Material2`, `Material3`, `Material4`, `Material5`, `Color1`, `Color2`, `Color3`, `Color4`, `Color5`, `CostPrice1`, `CostPrice2`, `CostPrice3`, `CostPrice4`, `CostPrice5`, `TotalDesMat`, `TotalCostPrice`, `TotalCost`, `InnerQty`, `Width`, `Height`, `Length`, `Diameter`, `Volume`, `Weight`, `Notes`, `PriceRisk`, `RealPrice`) VALUES (2, 'sp-002', 'CONTOH YANG KE DuA', '0000-01-01', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, 0, 0, 0, 0, 25000, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 25000, 0, 25000, 0, 0, 0, 0, 0, 0.00, 0.00, NULL, NULL, NULL);
INSERT INTO `samplepackaging` (`ID`, `SampleCode`, `Description`, `SampleDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `DesMat1`, `DesMat2`, `DesMat3`, `DesMat4`, `DesMat5`, `QtyDesMat1`, `QtyDesMat2`, `QtyDesMat3`, `QtyDesMat4`, `QtyDesMat5`, `TotalDesMat1`, `TotalDesMat2`, `TotalDesMat3`, `TotalDesMat4`, `TotalDesMat5`, `Supplier1`, `Supplier2`, `Supplier3`, `Supplier4`, `Supplier5`, `Material1`, `Material2`, `Material3`, `Material4`, `Material5`, `Color1`, `Color2`, `Color3`, `Color4`, `Color5`, `CostPrice1`, `CostPrice2`, `CostPrice3`, `CostPrice4`, `CostPrice5`, `TotalDesMat`, `TotalCostPrice`, `TotalCost`, `InnerQty`, `Width`, `Height`, `Length`, `Diameter`, `Volume`, `Weight`, `Notes`, `PriceRisk`, `RealPrice`) VALUES (3, 'SP-003', 'Test yg ke 3 terbaru', '2008-07-23', '200807230524160.DSC00061.JPG', '200807230524160.heliconia vase_200.jpg', NULL, NULL, NULL, 2, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, NULL, 20000, 0, 0, 0, 0, 1, NULL, NULL, NULL, NULL, 'Kacang Polong', NULL, NULL, NULL, NULL, 'Merah', NULL, NULL, NULL, NULL, 5000, 0, 0, 0, 0, 20000, 5000, 25000, 5, NULL, NULL, NULL, 5, 31.40, 12.00, 'tidak\r\nda\r\nnotes', NULL, NULL);


# dumping data for GayaFusionAll.tbladmin
INSERT INTO `tbladmin` (`ID`, `UserName`, `Passwd`) VALUES (1, 'ADMIN', 'ADMIN');


# dumping data for GayaFusionAll.tbladminist_addressbook
INSERT INTO `tbladminist_addressbook` (`AddressID`, `Company`) VALUES (1, 'BULGARI HOTELS AND RESORTS BALI');
INSERT INTO `tbladminist_addressbook` (`AddressID`, `Company`) VALUES (2, 'GAYA Fusion');
INSERT INTO `tbladminist_addressbook` (`AddressID`, `Company`) VALUES (3, 'PT COBA COBA');


# dumping data for GayaFusionAll.tbladminist_addressbook_contact
INSERT INTO `tbladminist_addressbook_contact` (`ContactId`, `AddressID`, `ContactName`, `Email`, `Address`, `Phone`, `Fax`) VALUES (1, 1, 'Bapak Wayan', 'wayan@bulgariresorts.com', 'Jl. By Pass Ngurah Rai\nKuta - Bali', '678678', '876876');
INSERT INTO `tbladminist_addressbook_contact` (`ContactId`, `AddressID`, `ContactName`, `Email`, `Address`, `Phone`, `Fax`) VALUES (2, 1, 'Ibu Made', 'made@bulgariresorts.com', 'Jl. Jimbaran\nNusa Dua', '667755', '657567');
INSERT INTO `tbladminist_addressbook_contact` (`ContactId`, `AddressID`, `ContactName`, `Email`, `Address`, `Phone`, `Fax`) VALUES (3, 2, 'Marcello Massoni', 'marcello@gayafusion.com', 'Jl. Raya Sayan Ubud\nGianyar - Bali', '001002', '112113');
INSERT INTO `tbladminist_addressbook_contact` (`ContactId`, `AddressID`, `ContactName`, `Email`, `Address`, `Phone`, `Fax`) VALUES (4, 2, 'Giorgia Oronte', 'giorgia@gayafusion.com', 'Jl. Raya Kedewatan Ubud\nGianyar - Bali', '889221', '9224411');
INSERT INTO `tbladminist_addressbook_contact` (`ContactId`, `AddressID`, `ContactName`, `Email`, `Address`, `Phone`, `Fax`) VALUES (5, 3, 'Bapak Susilo Bambang', 'sby@indonesia.com', 'Jl. Merdeka\nJakarta Pusat', '987321', '123456');








# dumping data for GayaFusionAll.tbladminist_client
INSERT INTO `tbladminist_client` (`ClientID`, `ClientCompany`) VALUES (1, 'BULGARI HOTELS & RESOTS BALI');
INSERT INTO `tbladminist_client` (`ClientID`, `ClientCompany`) VALUES (2, 'GAYA Fusion');
INSERT INTO `tbladminist_client` (`ClientID`, `ClientCompany`) VALUES (3, 'PT COBA COBA');




# dumping data for GayaFusionAll.tbladminist_currency
INSERT INTO `tbladminist_currency` (`CurrencyID`, `CurrencyCode`, `Currency`) VALUES (1, 'USD', 'US Dollar');
INSERT INTO `tbladminist_currency` (`CurrencyID`, `CurrencyCode`, `Currency`) VALUES (2, 'EU', 'EURO');
INSERT INTO `tbladminist_currency` (`CurrencyID`, `CurrencyCode`, `Currency`) VALUES (3, 'Rp', 'RUPIAH');




# dumping data for GayaFusionAll.tbladminist_deliveryterm
INSERT INTO `tbladminist_deliveryterm` (`DeliveryTermID`, `DeliveryTerm`) VALUES (1, 'FOB');
INSERT INTO `tbladminist_deliveryterm` (`DeliveryTermID`, `DeliveryTerm`) VALUES (2, 'CONTAINER');


# dumping data for GayaFusionAll.tbladminist_deliverytime
INSERT INTO `tbladminist_deliverytime` (`DeliveryTimeID`, `DeliveryTime`) VALUES (1, '1 month after balance');
INSERT INTO `tbladminist_deliverytime` (`DeliveryTimeID`, `DeliveryTime`) VALUES (2, '3 month after balance');




# dumping data for GayaFusionAll.tbladminist_invoice_h
INSERT INTO `tbladminist_invoice_h` (`Invoice_H_ID`, `Invoice_SH_ID`, `InvoicePar`, `Quotation_H_ID`, `Proforma_H_ID`, `InvoiceDate`, `ClientOrderRef`, `GayaOrderRef`, `DeliveryTermID`, `PaymentTermID`, `DueDate`, `ClientID`, `AddressID`, `InvoiceContactID`, `DeliveryContactID`, `SubTotal`, `Discount`, `Packaging`, `ShippingCost`, `GrandTotal`, `PaymentBankTransferred`, `Balance`) VALUES (1, 2, 'INV20080701', 1, NULL, '2008-07-15', '', '', 1, 1, '2008-07-22', 0, 1, 2, 1, 0, NULL, 0, 0, 0, 0, 0);
INSERT INTO `tbladminist_invoice_h` (`Invoice_H_ID`, `Invoice_SH_ID`, `InvoicePar`, `Quotation_H_ID`, `Proforma_H_ID`, `InvoiceDate`, `ClientOrderRef`, `GayaOrderRef`, `DeliveryTermID`, `PaymentTermID`, `DueDate`, `ClientID`, `AddressID`, `InvoiceContactID`, `DeliveryContactID`, `SubTotal`, `Discount`, `Packaging`, `ShippingCost`, `GrandTotal`, `PaymentBankTransferred`, `Balance`) VALUES (2, 3, 'INV20080702', NULL, 2, '2008-07-15', 'gaga', 'gege', 1, 1, '2008-07-22', 0, 2, 3, 3, 0, NULL, 0, 0, 0, 0, 0);
INSERT INTO `tbladminist_invoice_h` (`Invoice_H_ID`, `Invoice_SH_ID`, `InvoicePar`, `Quotation_H_ID`, `Proforma_H_ID`, `InvoiceDate`, `ClientOrderRef`, `GayaOrderRef`, `DeliveryTermID`, `PaymentTermID`, `DueDate`, `ClientID`, `AddressID`, `InvoiceContactID`, `DeliveryContactID`, `SubTotal`, `Discount`, `Packaging`, `ShippingCost`, `GrandTotal`, `PaymentBankTransferred`, `Balance`) VALUES (3, 4, 'PAR01', 1, 2, '2008-07-15', 'fafa', 'effe', 1, 1, '2008-07-15', 0, 2, 3, 4, 0, NULL, 0, 0, 0, 0, 0);


# dumping data for GayaFusionAll.tbladminist_invoice_sh
INSERT INTO `tbladminist_invoice_sh` (`Invoice_SH_ID`, `InvoiceNo`) VALUES (2, 'INV20080801');
INSERT INTO `tbladminist_invoice_sh` (`Invoice_SH_ID`, `InvoiceNo`) VALUES (3, 'INV20080802');
INSERT INTO `tbladminist_invoice_sh` (`Invoice_SH_ID`, `InvoiceNo`) VALUES (4, 'INV20080803');
INSERT INTO `tbladminist_invoice_sh` (`Invoice_SH_ID`, `InvoiceNo`) VALUES (5, 'INV20080804');




# dumping data for GayaFusionAll.tbladminist_packinglist_h
INSERT INTO `tbladminist_packinglist_h` (`PackingList_H_ID`, `PackingListNo`, `PackingListDate`, `Invoice_H_ID`, `AddressID`, `InvoiceContactID`, `DeliveryContactID`, `OrderRef`) VALUES (1, 'PAL20080701', '2008-07-16', 2, 2, 3, 4, '5454645');




# dumping data for GayaFusionAll.tbladminist_paymentterm
INSERT INTO `tbladminist_paymentterm` (`PaymentTermID`, `PaymentTerm`) VALUES (1, '3 months after delivery');
INSERT INTO `tbladminist_paymentterm` (`PaymentTermID`, `PaymentTerm`) VALUES (2, 'cash on delivery');


# dumping data for GayaFusionAll.tbladminist_paymenttype
INSERT INTO `tbladminist_paymenttype` (`PaymentTypeID`, `PaymentType`) VALUES (1, 'Deposit');
INSERT INTO `tbladminist_paymenttype` (`PaymentTypeID`, `PaymentType`) VALUES (2, 'Balance');
INSERT INTO `tbladminist_paymenttype` (`PaymentTypeID`, `PaymentType`) VALUES (3, 'COD');




# dumping data for GayaFusionAll.tbladminist_proforma_d
INSERT INTO `tbladminist_proforma_d` (`Proforma_D_ID`, `Proforma_H_ID`, `CollectID`, `CollectCode`, `Qty`, `Unit`, `Type`, `UnitPrice`, `Total`) VALUES (1, 1, 19, 'DNBETSSMSHSMC', 2, 'm', NULL, 100000, NULL);
INSERT INTO `tbladminist_proforma_d` (`Proforma_D_ID`, `Proforma_H_ID`, `CollectID`, `CollectCode`, `Qty`, `Unit`, `Type`, `UnitPrice`, `Total`) VALUES (2, 2, 21, 'BTSETSSMSHSMC', 2, 'm', NULL, 350000, NULL);
INSERT INTO `tbladminist_proforma_d` (`Proforma_D_ID`, `Proforma_H_ID`, `CollectID`, `CollectCode`, `Qty`, `Unit`, `Type`, `UnitPrice`, `Total`) VALUES (4, 1, 21, 'BTSETSSMSHSMC', 2, 'pcs', NULL, 350000, NULL);
INSERT INTO `tbladminist_proforma_d` (`Proforma_D_ID`, `Proforma_H_ID`, `CollectID`, `CollectCode`, `Qty`, `Unit`, `Type`, `UnitPrice`, `Total`) VALUES (5, 1, 27, 'GGSETSSMSHSMC', 1, 'pcs', NULL, 100000, NULL);
INSERT INTO `tbladminist_proforma_d` (`Proforma_D_ID`, `Proforma_H_ID`, `CollectID`, `CollectCode`, `Qty`, `Unit`, `Type`, `UnitPrice`, `Total`) VALUES (6, 3, 23, 'BTBETSSMSHSMC', 1, 'pcs', NULL, 300000, NULL);
INSERT INTO `tbladminist_proforma_d` (`Proforma_D_ID`, `Proforma_H_ID`, `CollectID`, `CollectCode`, `Qty`, `Unit`, `Type`, `UnitPrice`, `Total`) VALUES (7, 4, 19, 'ACSEPLSMSHSMC', 10, 'pcs', NULL, 100000, NULL);


# dumping data for GayaFusionAll.tbladminist_proforma_h
INSERT INTO `tbladminist_proforma_h` (`Proforma_H_ID`, `ProformaNo`, `Rev`, `Validity`, `ProformaDate`, `ClientOrderRef`, `ClientID`, `AddressID`, `ContactID`, `PackagingCost`, `DeliveryTermID`, `DeliveryTimeID`, `PaymentTermID`, `SpecialInstruction`, `PreviewDPDate`, `Quotation_H_ID`) VALUES (1, 'PRO20080701', NULL, '1', '2008-07-09', 'gaagag', 1, 1, 1, 5, 1, 1, 1, 'taatatatata', '2008-07-16', 0);
INSERT INTO `tbladminist_proforma_h` (`Proforma_H_ID`, `ProformaNo`, `Rev`, `Validity`, `ProformaDate`, `ClientOrderRef`, `ClientID`, `AddressID`, `ContactID`, `PackagingCost`, `DeliveryTermID`, `DeliveryTimeID`, `PaymentTermID`, `SpecialInstruction`, `PreviewDPDate`, `Quotation_H_ID`) VALUES (2, 'PRO20080702', NULL, '1', '2008-07-15', 'gafgf', 2, 2, 4, 5, 1, 1, 1, 'hahaha', '2008-07-15', 1);
INSERT INTO `tbladminist_proforma_h` (`Proforma_H_ID`, `ProformaNo`, `Rev`, `Validity`, `ProformaDate`, `ClientOrderRef`, `ClientID`, `AddressID`, `ContactID`, `PackagingCost`, `DeliveryTermID`, `DeliveryTimeID`, `PaymentTermID`, `SpecialInstruction`, `PreviewDPDate`, `Quotation_H_ID`) VALUES (3, 'PRO20080801', NULL, '1', '2008-08-01', 'hahaha', 1, 2, 3, 5, 1, 1, 1, 'ga ada', '2008-08-30', 1);
INSERT INTO `tbladminist_proforma_h` (`Proforma_H_ID`, `ProformaNo`, `Rev`, `Validity`, `ProformaDate`, `ClientOrderRef`, `ClientID`, `AddressID`, `ContactID`, `PackagingCost`, `DeliveryTermID`, `DeliveryTimeID`, `PaymentTermID`, `SpecialInstruction`, `PreviewDPDate`, `Quotation_H_ID`) VALUES (4, 'PRO20080802', NULL, '1', '2008-08-19', 'nomor 107', 2, 2, 0, 5, 1, 2, 1, 'Ini klien joz, ga pernah ngutang', '2008-08-31', 2);






# dumping data for GayaFusionAll.tbladminist_quotation_d
INSERT INTO `tbladminist_quotation_d` (`Quotation_D_ID`, `Quotation_H_ID`, `RndCode`, `UnitPrice`, `Remark`) VALUES (3, 2, 'tes', 100000, 'seep deh');
INSERT INTO `tbladminist_quotation_d` (`Quotation_D_ID`, `Quotation_H_ID`, `RndCode`, `UnitPrice`, `Remark`) VALUES (4, 2, 'cod', 300000, 'gagag');
INSERT INTO `tbladminist_quotation_d` (`Quotation_D_ID`, `Quotation_H_ID`, `RndCode`, `UnitPrice`, `Remark`) VALUES (5, 8, 'cod', 300000, 'gaga');
INSERT INTO `tbladminist_quotation_d` (`Quotation_D_ID`, `Quotation_H_ID`, `RndCode`, `UnitPrice`, `Remark`) VALUES (6, 8, 'code12', 3000, 'gege');


# dumping data for GayaFusionAll.tbladminist_quotation_h
INSERT INTO `tbladminist_quotation_h` (`Quotation_H_ID`, `QuotationNo`, `Rev`, `Validity`, `QuotationDate`, `ClientOrderRef`, `ClientID`, `AddressID`, `ContactID`, `PackagingCost`, `DeliveryTermID`, `DeliveryTimeID`, `PaymentTermID`, `SpecialInstruction`) VALUES (2, 'QUO20080702', '', '1', '2008-07-05', 'nomor 107', 2, 2, 4, 5, 1, 2, 1, 'Ini klien joz, ga pernah ngutang');
INSERT INTO `tbladminist_quotation_h` (`Quotation_H_ID`, `QuotationNo`, `Rev`, `Validity`, `QuotationDate`, `ClientOrderRef`, `ClientID`, `AddressID`, `ContactID`, `PackagingCost`, `DeliveryTermID`, `DeliveryTimeID`, `PaymentTermID`, `SpecialInstruction`) VALUES (3, 'QUO20080703', NULL, '1', '2008-07-09', 'fsdfsd', 3, 1, 1, 5, 1, 1, 1, 'gaggdfg');
INSERT INTO `tbladminist_quotation_h` (`Quotation_H_ID`, `QuotationNo`, `Rev`, `Validity`, `QuotationDate`, `ClientOrderRef`, `ClientID`, `AddressID`, `ContactID`, `PackagingCost`, `DeliveryTermID`, `DeliveryTimeID`, `PaymentTermID`, `SpecialInstruction`) VALUES (4, 'QUO20080704', NULL, '1', '2008-07-15', 'tatata', 1, 1, 1, 5, 1, 2, 1, 'ga ada');
INSERT INTO `tbladminist_quotation_h` (`Quotation_H_ID`, `QuotationNo`, `Rev`, `Validity`, `QuotationDate`, `ClientOrderRef`, `ClientID`, `AddressID`, `ContactID`, `PackagingCost`, `DeliveryTermID`, `DeliveryTimeID`, `PaymentTermID`, `SpecialInstruction`) VALUES (5, 'QUO20080705', NULL, '1', '2008-07-15', 'hehehe', 2, 1, 2, 5, 1, 2, 1, 'hihihi');
INSERT INTO `tbladminist_quotation_h` (`Quotation_H_ID`, `QuotationNo`, `Rev`, `Validity`, `QuotationDate`, `ClientOrderRef`, `ClientID`, `AddressID`, `ContactID`, `PackagingCost`, `DeliveryTermID`, `DeliveryTimeID`, `PaymentTermID`, `SpecialInstruction`) VALUES (6, 'QUO20080706', NULL, '1', '2008-07-15', 'gerrr', 3, 3, 5, 5, 1, 2, 1, 'taraaaa');
INSERT INTO `tbladminist_quotation_h` (`Quotation_H_ID`, `QuotationNo`, `Rev`, `Validity`, `QuotationDate`, `ClientOrderRef`, `ClientID`, `AddressID`, `ContactID`, `PackagingCost`, `DeliveryTermID`, `DeliveryTimeID`, `PaymentTermID`, `SpecialInstruction`) VALUES (7, 'QUO20080707', NULL, '1', '2008-07-15', '5tey', 1, 1, 2, 5, 1, 1, 1, 'dadadadadaa');
INSERT INTO `tbladminist_quotation_h` (`Quotation_H_ID`, `QuotationNo`, `Rev`, `Validity`, `QuotationDate`, `ClientOrderRef`, `ClientID`, `AddressID`, `ContactID`, `PackagingCost`, `DeliveryTermID`, `DeliveryTimeID`, `PaymentTermID`, `SpecialInstruction`) VALUES (8, 'QUO20080708', NULL, '1', '2008-07-15', 'tutututu', 3, 3, 5, 5, 1, 1, 1, 'kikkikiki');




# dumping data for GayaFusionAll.tbladminist_quotationrev_d
INSERT INTO `tbladminist_quotationrev_d` (`QuotationRev_D_ID`, `QuotationRev_H_ID`, `Quotation_D_ID`, `Quotation_H_ID`, `RndCode`, `UnitPrice`, `Remark`) VALUES (1, 0, 2, 1, 'cod', 300000, 'coba kedua ni');
INSERT INTO `tbladminist_quotationrev_d` (`QuotationRev_D_ID`, `QuotationRev_H_ID`, `Quotation_D_ID`, `Quotation_H_ID`, `RndCode`, `UnitPrice`, `Remark`) VALUES (2, 0, 1, 1, 'code12', 3000, 'tes');


# dumping data for GayaFusionAll.tbladminist_quotationrev_h
INSERT INTO `tbladminist_quotationrev_h` (`QuotationRev_H_ID`, `Quotation_H_ID`, `QuotationNo`, `Rev`, `Validity`, `QuotationDate`, `ClientOrderRef`, `ClientID`, `AddressID`, `ContactID`, `PackagingCost`, `DeliveryTermID`, `DeliveryTimeID`, `PaymentTermID`, `SpecialInstruction`) VALUES (1, 1, 'QUO20080701', '', '1', '2008-06-23', 'dudul@ribut.com', 1, 1, 1, 5, 1, 1, 1, 'Jual segera');
INSERT INTO `tbladminist_quotationrev_h` (`QuotationRev_H_ID`, `Quotation_H_ID`, `QuotationNo`, `Rev`, `Validity`, `QuotationDate`, `ClientOrderRef`, `ClientID`, `AddressID`, `ContactID`, `PackagingCost`, `DeliveryTermID`, `DeliveryTimeID`, `PaymentTermID`, `SpecialInstruction`) VALUES (2, 1, 'QUO20080701', 'REV01', '1', '2008-06-23', 'dudul@ribut.com', 1, 1, 1, 5, 1, 1, 1, 'Jual segera');
INSERT INTO `tbladminist_quotationrev_h` (`QuotationRev_H_ID`, `Quotation_H_ID`, `QuotationNo`, `Rev`, `Validity`, `QuotationDate`, `ClientOrderRef`, `ClientID`, `AddressID`, `ContactID`, `PackagingCost`, `DeliveryTermID`, `DeliveryTimeID`, `PaymentTermID`, `SpecialInstruction`) VALUES (3, 1, 'QUO20080701', 'REV02', '1', '2008-06-23', 'dudul@ribut.com', 1, 1, 1, 5, 1, 1, 1, 'Jual segera');
INSERT INTO `tbladminist_quotationrev_h` (`QuotationRev_H_ID`, `Quotation_H_ID`, `QuotationNo`, `Rev`, `Validity`, `QuotationDate`, `ClientOrderRef`, `ClientID`, `AddressID`, `ContactID`, `PackagingCost`, `DeliveryTermID`, `DeliveryTimeID`, `PaymentTermID`, `SpecialInstruction`) VALUES (4, 1, 'QUO20080701', 'REV02', '1', '2008-06-23', 'dudul@ribut.com', 1, 1, 1, 5, 1, 1, 1, 'Jual segera');
INSERT INTO `tbladminist_quotationrev_h` (`QuotationRev_H_ID`, `Quotation_H_ID`, `QuotationNo`, `Rev`, `Validity`, `QuotationDate`, `ClientOrderRef`, `ClientID`, `AddressID`, `ContactID`, `PackagingCost`, `DeliveryTermID`, `DeliveryTimeID`, `PaymentTermID`, `SpecialInstruction`) VALUES (5, 1, 'QUO20080701', 'REV02', '1', '2008-06-23', 'dudul@ribut.com', 1, 1, 1, 5, 1, 1, 1, 'Jual segera');
INSERT INTO `tbladminist_quotationrev_h` (`QuotationRev_H_ID`, `Quotation_H_ID`, `QuotationNo`, `Rev`, `Validity`, `QuotationDate`, `ClientOrderRef`, `ClientID`, `AddressID`, `ContactID`, `PackagingCost`, `DeliveryTermID`, `DeliveryTimeID`, `PaymentTermID`, `SpecialInstruction`) VALUES (6, 1, 'QUO20080701', 'REV02', '1', '2008-06-23', 'dudul@ribut.com', 1, 1, 1, 5, 1, 1, 1, 'Jual segera');


# dumping data for GayaFusionAll.tblcasting
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (1, 'CS08-001', 'BALI BOX SMALL', '2008-03-11', NULL, NULL, NULL, NULL, NULL, 'Tes\r\naja\r\nlho\r\nhihhihi');
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (2, 'CS08-002', 'BALI BOX BIG', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (3, 'CS08-003', 'CYLINDER SHORT', '0000-01-01', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblcasting` (`ID`, `CastingCode`, `CastingDescription`, `CastingDate`, `CastingTechDraw`, `CastingPhoto1`, `CastingPhoto2`, `CastingPhoto3`, `CastingPhoto4`, `CastingNotes`) VALUES (4, 'CS08-004', 'CYLINDER TALL', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblclay
INSERT INTO `tblclay` (`ID`, `ClayCode`, `ClayDescription`, `ClayDate`, `ClayTechDraw`, `ClayPhoto1`, `ClayPhoto2`, `ClayPhoto3`, `ClayPhoto4`, `ClayNotes`) VALUES (1, 'CL08-001', 'PORCELAIN', '2008-03-05', NULL, NULL, NULL, NULL, NULL, 'tess\r\nkgkkgkg\r\nijijji\r\nokokkok\r\nljljl');
INSERT INTO `tblclay` (`ID`, `ClayCode`, `ClayDescription`, `ClayDate`, `ClayTechDraw`, `ClayPhoto1`, `ClayPhoto2`, `ClayPhoto3`, `ClayPhoto4`, `ClayNotes`) VALUES (2, 'CL08-002', 'STONEWARE', '0000-01-01', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblclay` (`ID`, `ClayCode`, `ClayDescription`, `ClayDate`, `ClayTechDraw`, `ClayPhoto1`, `ClayPhoto2`, `ClayPhoto3`, `ClayPhoto4`, `ClayNotes`) VALUES (3, 'CL08-003', 'RAKU', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblclay` (`ID`, `ClayCode`, `ClayDescription`, `ClayDate`, `ClayTechDraw`, `ClayPhoto1`, `ClayPhoto2`, `ClayPhoto3`, `ClayPhoto4`, `ClayNotes`) VALUES (4, 'CL08-004', 'STONEWARE CASTING', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblcollect_category
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('TS', 'TEA CUP SAUCER');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('TG', 'TEA CUP');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('PL', 'PLATE');
INSERT INTO `tblcollect_category` (`CategoryCode`, `CategoryName`) VALUES ('CU', 'CUP');


# dumping data for GayaFusionAll.tblcollect_color
INSERT INTO `tblcollect_color` (`ColorCode`, `ColorName`) VALUES ('SM', 'BLACK');


# dumping data for GayaFusionAll.tblcollect_design
INSERT INTO `tblcollect_design` (`DesignCode`, `DesignName`) VALUES ('AC', 'ARMANI CASA');
INSERT INTO `tblcollect_design` (`DesignCode`, `DesignName`) VALUES ('GG', 'Gudang Garam');
INSERT INTO `tblcollect_design` (`DesignCode`, `DesignName`) VALUES ('BV', 'BULGARI BALI');
INSERT INTO `tblcollect_design` (`DesignCode`, `DesignName`) VALUES ('FE', 'FEFEFEFEFE');
INSERT INTO `tblcollect_design` (`DesignCode`, `DesignName`) VALUES ('DN', 'Daniel');


# dumping data for GayaFusionAll.tblcollect_group_det
INSERT INTO `tblcollect_group_det` (`ID`, `Group_H_ID`, `CollectCode`, `Qty`) VALUES (4, 2, '23', 2);
INSERT INTO `tblcollect_group_det` (`ID`, `Group_H_ID`, `CollectCode`, `Qty`) VALUES (3, 2, '21', 2);
INSERT INTO `tblcollect_group_det` (`ID`, `Group_H_ID`, `CollectCode`, `Qty`) VALUES (5, 2, '27', 1);


# dumping data for GayaFusionAll.tblcollect_group_h
INSERT INTO `tblcollect_group_h` (`Group_H_ID`, `GroupCode`, `GroupDate`, `DesignCode`, `GroupDescription`, `ClientCode`, `ClientDesc`, `GroupPhoto`, `Diameter`, `Height`, `Weight`, `Length`) VALUES (2, 'ACGR200801', '2008-08-07', 'AC', 'SET SEIA TEA CUP + SAUCER', '0789456/333', 'SEIA BICCHIERI', '200808070317180.PHO 01.jpg', NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblcollect_master
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`, `LastUpdate`) VALUES (19, 'ACSEPLSMSHSMC', 'AC', 'SE', 'PL', 'SM', 'SH', 'SM', 'C', 'T01', 'TAZZA', '2008-08-18', '200808180155570.wp.jpg', '200808180155570.PHO 01.jpg', '200808180155570.PHO 02.jpg', '200808180155570.PHO 03.jpg', '200808180155570.PHO 04.jpg', 5, 1, 5, 'test clay notes', 'TROWING', 'test build technique', 'FLAT', 'ROUND', 1, NULL, NULL, NULL, 'test casting notes', 1, NULL, NULL, NULL, 'test estruder notes', 4, NULL, NULL, NULL, 'test texture notes', 1, NULL, NULL, NULL, 'test notes texture', 2, NULL, NULL, NULL, 'test engobe notes', '900', 1, NULL, NULL, NULL, 'test stain notes', 1, NULL, NULL, NULL, '1280', NULL, NULL, NULL, 'test glaze notes', '1300', 'Oxidation', 'test firing notes', NULL, 10.00, NULL, 8.00, 0.00, 'test final notes', 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'test deaign material notes', 'test history', '1', 4000, 10, 2400, 5, 6000, 5, 6000, 0, 0, 0, 0, 0, 0, 500, 5000, 30, 15000, 0, 0, 0, 0, 0, 0, 0, 0, 6, 12, 12, 0, 0, 0, 0, 0, 50400, 55440, 166320, 100000, '0000-01-01');
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`, `LastUpdate`) VALUES (21, 'ACSETGSMSHSMC', 'AC', 'SE', 'TG', 'SM', 'SH', 'SM', 'C', NULL, NULL, '2008-06-25', NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Reduction', NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00');
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`, `LastUpdate`) VALUES (36, 'BVSETSSMSHSMC', 'BV', 'SE', 'TS', 'SM', 'SH', 'SM', 'C', 'CTiga', 'ketiga ya', '2008-06-25', NULL, NULL, NULL, NULL, NULL, 7, NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Oxidation', NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00');
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`, `LastUpdate`) VALUES (23, 'ACSETSSMSHSMB', 'AC', 'SE', 'TS', 'SM', 'SH', 'SM', 'B', 'kode kadal', 'ini deskripsi si klien ya', '0000-00-00', NULL, '20080316202648-100_5176.jpg', NULL, NULL, '20080424043033-BPM jadul.jpg', 3, 1, 5, NULL, NULL, 'ldflajfdsf\r\nclay notes\r\nkok ga\r\nkliatan', '40', '0.5', 0, 0, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, '960°', 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, '443', '3453', '3535', '3453', NULL, '500', 'Oxidation', NULL, 5.00, 5.00, 5.00, 0.00, 0.00, NULL, 0, 0, NULL, NULL, 5, 3, 0, 0, NULL, 'coba deh tes history-nya..\r\nini juga test pake enter', '5', 2250, 3, 8000, 10, 1500, 8, 4000, 5, 9600, 30, 600, 6, 4500, 100, 5000, 5, 15000, 0, 0, 0, 0, 7, 2700, 3, 9000, 20, 6, 8, 12, 2, 10, 9, 20, 62150, 68365, 205095, 400000, '0000-00-00');
INSERT INTO `tblcollect_master` (`ID`, `CollectCode`, `DesignCode`, `NameCode`, `CategoryCode`, `SizeCode`, `TextureCode`, `ColorCode`, `MaterialCode`, `ClientCode`, `ClientDescription`, `CollectDate`, `TechDraw`, `Photo1`, `Photo2`, `Photo3`, `Photo4`, `RefID`, `Clay`, `ClayKG`, `ClayNote`, `BuildTech`, `BuildTechNote`, `Rim`, `Feet`, `Casting1`, `Casting2`, `Casting3`, `Casting4`, `CastingNote`, `Estruder1`, `Estruder2`, `Estruder3`, `Estruder4`, `EstruderNote`, `Texture1`, `Texture2`, `Texture3`, `Texture4`, `TextureNote`, `Tools1`, `Tools2`, `Tools3`, `Tools4`, `ToolsNote`, `Engobe1`, `Engobe2`, `Engobe3`, `Engobe4`, `EngobeNote`, `BisqueTemp`, `StainOxide1`, `StainOxide2`, `StainOxide3`, `StainOxide4`, `StainOxideNote`, `Glaze1`, `Glaze2`, `Glaze3`, `Glaze4`, `GlazeDensity1`, `GlazeDensity2`, `GlazeDensity3`, `GlazeDensity4`, `GlazeNote`, `GlazeTemp`, `Firing`, `FiringNote`, `Width`, `Height`, `Length`, `Diameter`, `SampCeramicVolume`, `FinalSizeNote`, `DesignMat1`, `DesignMat2`, `DesignMat3`, `DesignMat4`, `DesignMatQty1`, `DesignMatQty2`, `DesignMatQty3`, `DesignMatQty4`, `DesignMatNote`, `History`, `ClayType`, `ClayCost`, `ClayPreparationMinute`, `ClayPreparationCost`, `WheelMinute`, `WheelCost`, `SlabMinute`, `SlabCost`, `CastingMinute`, `CastingCost`, `FinishingMinute`, `FinishingCost`, `GlazingMinute`, `GlazingCost`, `StandardBisqueLoading`, `StandardBisqueCost`, `StandardGlazeLoading`, `StandardGlazeCost`, `RakuBisqueLoading`, `RakuBisqueCost`, `RakuGlazeLoading`, `RakuGlazeCost`, `MovementMinute`, `MovementCost`, `PackagingWorkMinute`, `PackagingWorkCost`, `ClayPreparationPPH`, `WheelPPH`, `SlabPPH`, `CastingPPH`, `FinishingPPH`, `GlazingPPH`, `MovementPPH`, `PackagingWorkPPH`, `TotalAllCost`, `RiskPrice`, `HypoSellingPrice`, `RealSellingPrice`, `LastUpdate`) VALUES (27, 'ACSETSSMSHSMC', 'AC', 'SE', 'TS', 'SM', 'SH', 'SM', 'C', 'hahaha', 'huehehehehehe...luthuuunaa', '2008-06-11', NULL, '200806251330240.billa1.jpg', NULL, NULL, NULL, 6, 2, 0, NULL, NULL, NULL, NULL, NULL, 1, 3, 3, 1, NULL, 1, 1, 1, 1, NULL, 1, 1, 1, 1, NULL, 1, 1, 1, 1, NULL, 2, 1, 2, 2, 'tes\r\nengobe\r\nnya\r\nya', '120', 1, 2, 2, 1, 'tes\r\nter', 1, 2, 2, 2, '1', '2', '34', '4', 'ga\r\nga\r\nga', '500', 'Oxidation', 'ga\r\nada notes', 5.00, 90.00, 11.00, NULL, 0.00, NULL, 1, 2, 3, 1, 4, 3, 2, 1, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100000, '0000-00-00');


# dumping data for GayaFusionAll.tblcollect_material
INSERT INTO `tblcollect_material` (`MaterialCode`, `MaterialName`) VALUES ('C', 'CERAMIC PORCELAIN');
INSERT INTO `tblcollect_material` (`MaterialCode`, `MaterialName`) VALUES ('B', 'CARTOON BOX');


# dumping data for GayaFusionAll.tblcollect_name
INSERT INTO `tblcollect_name` (`NameCode`, `NameDesc`) VALUES ('SE', 'SEIA');
INSERT INTO `tblcollect_name` (`NameCode`, `NameDesc`) VALUES ('BE', 'Beia');


# dumping data for GayaFusionAll.tblcollect_size
INSERT INTO `tblcollect_size` (`SizeCode`, `SizeName`) VALUES ('SM', 'SMALL');
INSERT INTO `tblcollect_size` (`SizeCode`, `SizeName`) VALUES ('SB', 'Super Besar');


# dumping data for GayaFusionAll.tblcollect_texture
INSERT INTO `tblcollect_texture` (`TextureCode`, `TextureName`) VALUES ('SH', 'SMOOTH');


# dumping data for GayaFusionAll.tblcosting_casting
INSERT INTO `tblcosting_casting` (`ID`, `CostPerMinute`, `PiecesPerHour`) VALUES (1, 400, 90);


# dumping data for GayaFusionAll.tblcosting_clay
INSERT INTO `tblcosting_clay` (`ID`, `ClayType`, `PricePerKG`) VALUES (1, 'STONEWARE', 800);
INSERT INTO `tblcosting_clay` (`ID`, `ClayType`, `PricePerKG`) VALUES (5, 'PORCELAIN', 450);
INSERT INTO `tblcosting_clay` (`ID`, `ClayType`, `PricePerKG`) VALUES (6, 'RAKU', 10000);


# dumping data for GayaFusionAll.tblcosting_claypreparation
INSERT INTO `tblcosting_claypreparation` (`ID`, `CostPerMinute`, `PiecesPerHour`) VALUES (1, 400, 3);


# dumping data for GayaFusionAll.tblcosting_costbudgetpreview
INSERT INTO `tblcosting_costbudgetpreview` (`ID`, `BudgetYear`, `CostBudgetAmmount`) VALUES (1, 2008, 1500000000);


# dumping data for GayaFusionAll.tblcosting_finishing
INSERT INTO `tblcosting_finishing` (`ID`, `CostPerMinute`, `PiecesPerHour`) VALUES (1, 400, 70);


# dumping data for GayaFusionAll.tblcosting_glazing
INSERT INTO `tblcosting_glazing` (`ID`, `CostPerMinute`, `PiecesPerHour`) VALUES (1, 400, 8);


# dumping data for GayaFusionAll.tblcosting_master
INSERT INTO `tblcosting_master` (`ID`, `ClayPreparationCPM`, `ClayPreparationPPH`, `WheelCPM`, `WheelPPH`, `SlabCPM`, `SlabPPH`, `CastingCPM`, `CastingPPH`, `FinishingCPM`, `FinishingPPH`, `GlazingCPM`, `GlazingPPH`, `MovementCPM`, `MovementPPH`, `PackagingWorkCPM`, `PackagingWorkPPH`, `StandardBisqueCPM`, `StandardBisquePPH`, `StandardGlazeCPM`, `StandardGlazePPH`, `RakuBisqueCPM`, `RakuBisquePPH`, `RakuGlazeCPM`, `RakuGlazePPH`, `ProductiveHourDay`, `ProductiveHourMonth`, `ProductiveHourYear`, `TrowWorker`) VALUES (0, 0, 0, 0, 0, 0, 0, 0, 0, 500, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.00, 0, 0, 0);


# dumping data for GayaFusionAll.tblcosting_movement
INSERT INTO `tblcosting_movement` (`ID`, `CostPerMinute`, `PiecesPerHour`) VALUES (1, 300, 5);


# dumping data for GayaFusionAll.tblcosting_packagingwork
INSERT INTO `tblcosting_packagingwork` (`ID`, `CostPerMinute`, `PiecesPerHour`) VALUES (1, 400, 5);


# dumping data for GayaFusionAll.tblcosting_productivehours
INSERT INTO `tblcosting_productivehours` (`ID`, `Day`, `Month`, `Year`) VALUES (1, 5.00, 25, 12);


# dumping data for GayaFusionAll.tblcosting_rakubisque
INSERT INTO `tblcosting_rakubisque` (`ID`, `PricePerFiring`) VALUES (1, 1250.00);


# dumping data for GayaFusionAll.tblcosting_rakuglaze
INSERT INTO `tblcosting_rakuglaze` (`ID`, `PricePerFiring`) VALUES (1, 1500.00);


# dumping data for GayaFusionAll.tblcosting_slab
INSERT INTO `tblcosting_slab` (`ID`, `CostPerMinute`, `PiecesPerHour`) VALUES (1, 400, 10);


# dumping data for GayaFusionAll.tblcosting_standardbisque
INSERT INTO `tblcosting_standardbisque` (`ID`, `PricePerFiring`) VALUES (1, 1000);


# dumping data for GayaFusionAll.tblcosting_standardglaze
INSERT INTO `tblcosting_standardglaze` (`ID`, `PricePerFiring`) VALUES (1, 3000);


# dumping data for GayaFusionAll.tblcosting_trowworker
INSERT INTO `tblcosting_trowworker` (`ID`, `TrowWorker`) VALUES (1, 3);


# dumping data for GayaFusionAll.tblcosting_wheel
INSERT INTO `tblcosting_wheel` (`ID`, `CostPerMinute`, `PiecesPerHour`) VALUES (1, 400, 6);


# dumping data for GayaFusionAll.tbldesignmat
INSERT INTO `tbldesignmat` (`DesignMatID`, `DesignMatCode`, `DesignMatDescription`, `DesignMatTechDraw`, `DesignMatPhoto1`, `DesignMatPhoto2`, `DesignMatPhoto3`, `DesignMatPhoto4`, `DesignMatSupplier`, `DesignMatUnit`, `DesignMatUnitPrice`, `DesignMatNotes`, `DesignMatDate`) VALUES (1, 'DM08-001', 'SILVER', NULL, NULL, NULL, NULL, NULL, 1, 'B', 12000, 'TES\r\nNOTES\r\nDESIGN\r\nMATERIAL', '2008-03-16');
INSERT INTO `tbldesignmat` (`DesignMatID`, `DesignMatCode`, `DesignMatDescription`, `DesignMatTechDraw`, `DesignMatPhoto1`, `DesignMatPhoto2`, `DesignMatPhoto3`, `DesignMatPhoto4`, `DesignMatSupplier`, `DesignMatUnit`, `DesignMatUnitPrice`, `DesignMatNotes`, `DesignMatDate`) VALUES (2, 'DM08-002', 'SMALL CARTOON DECORATION', NULL, NULL, NULL, NULL, NULL, 2, 'A', 5000, NULL, '0000-01-01');
INSERT INTO `tbldesignmat` (`DesignMatID`, `DesignMatCode`, `DesignMatDescription`, `DesignMatTechDraw`, `DesignMatPhoto1`, `DesignMatPhoto2`, `DesignMatPhoto3`, `DesignMatPhoto4`, `DesignMatSupplier`, `DesignMatUnit`, `DesignMatUnitPrice`, `DesignMatNotes`, `DesignMatDate`) VALUES (3, 'DM08-003', 'COASTER', NULL, NULL, NULL, NULL, NULL, 3, 'C', 5000, NULL, '0000-01-01');
INSERT INTO `tbldesignmat` (`DesignMatID`, `DesignMatCode`, `DesignMatDescription`, `DesignMatTechDraw`, `DesignMatPhoto1`, `DesignMatPhoto2`, `DesignMatPhoto3`, `DesignMatPhoto4`, `DesignMatSupplier`, `DesignMatUnit`, `DesignMatUnitPrice`, `DesignMatNotes`, `DesignMatDate`) VALUES (4, 'DM08-004', 'NAPKIN', NULL, NULL, NULL, NULL, NULL, 4, 'A', 7500, NULL, '2008-07-26');


# dumping data for GayaFusionAll.tblengobe
INSERT INTO `tblengobe` (`ID`, `EngobeCode`, `EngobeDescription`, `EngobeDate`, `EngobeTechDraw`, `EngobePhoto1`, `EngobePhoto2`, `EngobePhoto3`, `EngobePhoto4`, `EngobeNotes`) VALUES (1, 'EN08-001', 'GREEN ENGOBE', '2008-03-06', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblengobe` (`ID`, `EngobeCode`, `EngobeDescription`, `EngobeDate`, `EngobeTechDraw`, `EngobePhoto1`, `EngobePhoto2`, `EngobePhoto3`, `EngobePhoto4`, `EngobeNotes`) VALUES (2, 'EN08-002', 'BLUE ENGOBE', '0000-01-01', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblengobe` (`ID`, `EngobeCode`, `EngobeDescription`, `EngobeDate`, `EngobeTechDraw`, `EngobePhoto1`, `EngobePhoto2`, `EngobePhoto3`, `EngobePhoto4`, `EngobeNotes`) VALUES (4, 'EN08-004', '70% SAND + 30% PORCELAIN', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblengobe` (`ID`, `EngobeCode`, `EngobeDescription`, `EngobeDate`, `EngobeTechDraw`, `EngobePhoto1`, `EngobePhoto2`, `EngobePhoto3`, `EngobePhoto4`, `EngobeNotes`) VALUES (3, 'EN08-003', '50% SAND + 50% PORCELAIN', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblestruder
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (1, 'ES08-001', 'PIPE', '0000-01-01', NULL, NULL, NULL, NULL, NULL, 'Testing\r\nhaha');
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (2, 'ES08-002', 'TUBE', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (3, 'ES08-003', 'OUVAL', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblestruder` (`ID`, `EstruderCode`, `EstruderDescription`, `EstruderDate`, `EstruderTechDraw`, `EstruderPhoto1`, `EstruderPhoto2`, `EstruderPhoto3`, `EstruderPhoto4`, `EstruderNotes`) VALUES (4, 'ES08-004', 'RECTANGLE', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblfiringplan
INSERT INTO `tblfiringplan` (`ID`, `FiringPlanCode`, `FiringPlanDescription`, `FiringPlanDate`, `FiringPlanTechDraw`, `FiringPlanPhoto1`, `FiringPlanPhoto2`, `FiringPlanPhoto3`, `FiringPlanPhoto4`, `FiringPlanNotes`) VALUES (1, 'FP08-001', 'BISQUE', '2008-03-09', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblfiringplan` (`ID`, `FiringPlanCode`, `FiringPlanDescription`, `FiringPlanDate`, `FiringPlanTechDraw`, `FiringPlanPhoto1`, `FiringPlanPhoto2`, `FiringPlanPhoto3`, `FiringPlanPhoto4`, `FiringPlanNotes`) VALUES (2, 'FP08-002', 'GLAZE OXIDATION', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblglaze
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (1, 'GZ08-001', 'UNGLAZED', '2008-06-09', NULL, NULL, NULL, NULL, NULL, 'Ini isinya notesnya..\r\nbisa pake enter ga ya??');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (2, 'GL08-002', 'WHITE TRANSPARENT', '2008-03-15', NULL, NULL, NULL, NULL, NULL, 'tes dulu yak :D');
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (3, 'GL08-003', 'DARK BLUE SHINING', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblglaze` (`ID`, `GlazeCode`, `GlazeDescription`, `GlazeDate`, `GlazeTechDraw`, `GlazePhoto1`, `GlazePhoto2`, `GlazePhoto3`, `GlazePhoto4`, `GlazeNotes`) VALUES (4, 'GL08-004', 'WHITE MAT', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblreference
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (1, '20080729045226', 5, 21, NULL);
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (2, '20080729050200', 5, 22, NULL);
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (3, '20080729052729', 5, 23, NULL);
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (4, '20080729062619', 0, 0, NULL);
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (5, '20080729115002', 2, 19, 'Ini coba notesnya yak..');
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (6, '20080729133303', 2, 27, NULL);
INSERT INTO `tblreference` (`ID`, `RefCode`, `sID`, `CollectID`, `RefNote`) VALUES (7, '2008087033237', 3, 36, NULL);


# dumping data for GayaFusionAll.tblstainoxide
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (1, 'SX08-001', 'RED STAIN', '2008-03-10', NULL, NULL, NULL, NULL, NULL, 'hahaha\r\nlucu kali yee');
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (2, 'SX08-002', 'BLACK STAIN', '0000-01-01', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (3, 'SX08-003', 'IRON OXIDE', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblstainoxide` (`ID`, `StainOxideCode`, `StainOxideDescription`, `StainOxideDate`, `StainOxideTechDraw`, `StainOxidePhoto1`, `StainOxidePhoto2`, `StainOxidePhoto3`, `StainOxidePhoto4`, `StainOxideNotes`) VALUES (4, 'SX08-004', 'COPPER OXIDE', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblsupplier
INSERT INTO `tblsupplier` (`ID`, `SupCode`, `SupCompany`, `SupContact`, `SupAddress`, `SupHP`, `SupOffice`, `SupFax`, `SupEmail`, `SupItems`, `SupOtherInfo`) VALUES (1, 'SU08-001', 'ARTHA SILVER', 'Pak Artha', 'Celuk', '0818098765432', '123456', '7896987', 'artha@silver.com', 'SILVER', NULL);
INSERT INTO `tblsupplier` (`ID`, `SupCode`, `SupCompany`, `SupContact`, `SupAddress`, `SupHP`, `SupOffice`, `SupFax`, `SupEmail`, `SupItems`, `SupOtherInfo`) VALUES (2, 'SU08-002', 'RIDWAN BOX', 'Pak Ridwan', 'Penatih', '098589345', '460608', '978798', 'ridwanbox@telkom.net', 'BOX', 'there\'s no info');
INSERT INTO `tblsupplier` (`ID`, `SupCode`, `SupCompany`, `SupContact`, `SupAddress`, `SupHP`, `SupOffice`, `SupFax`, `SupEmail`, `SupItems`, `SupOtherInfo`) VALUES (3, 'SU08-003', 'WAWAN TAILOR', 'Wawan', 'Petulu', '081546789', '245687', '251499', 'wawan@gmail.com', 'TAILOR', NULL);
INSERT INTO `tblsupplier` (`ID`, `SupCode`, `SupCompany`, `SupContact`, `SupAddress`, `SupHP`, `SupOffice`, `SupFax`, `SupEmail`, `SupItems`, `SupOtherInfo`) VALUES (4, 'SU08-004', 'BADRA', 'Pak Badra', NULL, NULL, NULL, NULL, NULL, 'BEADS', NULL);


# dumping data for GayaFusionAll.tbltexture
INSERT INTO `tbltexture` (`ID`, `TextureCode`, `TextureDescription`, `TextureDate`, `TextureTechDraw`, `TexturePhoto1`, `TexturePhoto2`, `TexturePhoto3`, `TexturePhoto4`, `TextureNotes`) VALUES (1, 'TX08-001', 'HORIZONTAL LINE', '2008-06-11', NULL, NULL, NULL, NULL, NULL, 'tes');
INSERT INTO `tbltexture` (`ID`, `TextureCode`, `TextureDescription`, `TextureDate`, `TextureTechDraw`, `TexturePhoto1`, `TexturePhoto2`, `TexturePhoto3`, `TexturePhoto4`, `TextureNotes`) VALUES (2, 'TX08-002', 'VERTICAL LINE', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbltexture` (`ID`, `TextureCode`, `TextureDescription`, `TextureDate`, `TextureTechDraw`, `TexturePhoto1`, `TexturePhoto2`, `TexturePhoto3`, `TexturePhoto4`, `TextureNotes`) VALUES (3, 'TX08-003', 'HAMMERED', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbltexture` (`ID`, `TextureCode`, `TextureDescription`, `TextureDate`, `TextureTechDraw`, `TexturePhoto1`, `TexturePhoto2`, `TexturePhoto3`, `TexturePhoto4`, `TextureNotes`) VALUES (4, 'TX08-004', 'SMOOTH', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tbltools
INSERT INTO `tbltools` (`ID`, `ToolsCode`, `ToolsDescription`, `ToolsDate`, `ToolsTechDraw`, `ToolsPhoto1`, `ToolsPhoto2`, `ToolsPhoto3`, `ToolsPhoto4`, `ToolsNotes`) VALUES (1, 'TL08-001', 'CUTTER', '2008-06-27', NULL, NULL, NULL, NULL, NULL, 'hahaha\r\ngda');
INSERT INTO `tbltools` (`ID`, `ToolsCode`, `ToolsDescription`, `ToolsDate`, `ToolsTechDraw`, `ToolsPhoto1`, `ToolsPhoto2`, `ToolsPhoto3`, `ToolsPhoto4`, `ToolsNotes`) VALUES (2, 'TL08-002', 'KNIFE', '0000-01-01', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbltools` (`ID`, `ToolsCode`, `ToolsDescription`, `ToolsDate`, `ToolsTechDraw`, `ToolsPhoto1`, `ToolsPhoto2`, `ToolsPhoto3`, `ToolsPhoto4`, `ToolsNotes`) VALUES (3, 'TL08-003', 'RUBBER', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbltools` (`ID`, `ToolsCode`, `ToolsDescription`, `ToolsDate`, `ToolsTechDraw`, `ToolsPhoto1`, `ToolsPhoto2`, `ToolsPhoto3`, `ToolsPhoto4`, `ToolsNotes`) VALUES (4, 'TL08-004', 'PENCIL', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL);


# dumping data for GayaFusionAll.tblunit
INSERT INTO `tblunit` (`UnitID`, `UnitValue`) VALUES ('A', 'PCS');
INSERT INTO `tblunit` (`UnitID`, `UnitValue`) VALUES ('B', 'GR');
INSERT INTO `tblunit` (`UnitID`, `UnitValue`) VALUES ('C', 'M');


# dumping data for GayaFusionAll.tbluser
INSERT INTO `tbluser` (`id`, `UserName`, `LastName`, `FirstName`, `Password`, `Type`) VALUES (12, 'costing', 'costingan', 'costing', '80ae4cae7c034951fd3194bfffed7d4f', 'Costing');
INSERT INTO `tbluser` (`id`, `UserName`, `LastName`, `FirstName`, `Password`, `Type`) VALUES (13, 'admin', 'boongan', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin');
INSERT INTO `tbluser` (`id`, `UserName`, `LastName`, `FirstName`, `Password`, `Type`) VALUES (14, 'Rnd', 'Rnd', 'Orang', '577c2406e417ed786986e6a6cfd55317', 'RnD');


